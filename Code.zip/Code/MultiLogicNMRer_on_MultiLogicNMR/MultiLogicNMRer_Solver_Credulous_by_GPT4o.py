"""
针对非单调推理的神经符号方法的实现
"""
import copy
import random
import sys
import re
import httpx
import requests
import torch
sys.path.append('../../../Dataset')
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ["NCCL_P2P_DISABLE"] = "1"
os.environ["NCCL_IB_DISABLE"] = "0"
os.environ['WANDB_MODE'] = 'dryrun'
from unsloth import FastLanguageModel
max_seq_length = 2048
import difflib
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
import json


import torch
from trl import SFTTrainer, DataCollatorForCompletionOnlyLM
from transformers import TrainingArguments
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
import json
max_seq_length = 2048
Reasoning_Mode = 'credulous' # [credulous, skeptical]
Dataset_Name = 'MultiLogicNMR'
Dataset_Category = 'test' # ['train', 'dev', 'test']
Zero_or_Few_Shot = 'Zero_Shot' # ['Zero_Shot','Few_Shot']
Reasoning_With_Similarity = False # 用于指示是否是基于相似度进行对问题在回答集上推理还是直接使用大模型对问题进行推理
OOD_Flag = False
OOD_Data_Path = "OOD_Datasets" if OOD_Flag == True else ''
OOD_read_filename = "_ood" if OOD_Flag == True else ''
OOD_write_filename = "ood_" if OOD_Flag == True else ''
Max_Answer_Set_Number = 5

read_file_path = None
read_file_path = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Datasets/' + OOD_Data_Path + '/' if OOD_Flag == True else '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Datasets/' + Reasoning_Mode + '/'

write_file_path = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Experimens/LLMs_Results/'
ASP_extension_number_Min, ASP_extension_number_Max = 1,5 #用于对回答集进行过滤
if OOD_Flag == True:
    ASP_extension_number_Min, ASP_extension_number_Max = 6,16

LLMs_Models_Choise = "GPT4o" #['LLAMA31','DeepSeek_R1','GPT3.5','GPT4o','Claude','Gemma2_9B','Mistral_7B']
Read_Data_file = read_file_path + Reasoning_Mode + '_multiNMR_'+ Dataset_Category +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + OOD_read_filename + '.json'
Write_file_path02 = write_file_path + 'MultiLogicNMRer_' + LLMs_Models_Choise + '_result_on_' + Dataset_Name + '_' + OOD_write_filename + Reasoning_Mode + '_'+ Dataset_Category +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + '.json'
import warnings
warnings.filterwarnings("ignore")


import numpy as np
def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


# 设置随机数种子
setup_seed(20)

Label_Dict = {'F':[0],'T':[1],'M':[2]}

# 提示用于获取实例化规则中的结论。
Grounded_Prompt_Instrunction = 'Task Description: \n Given a set of facts and a rule, you need to instantiate the rules based on given facts. Instantiation requires the replacement of pronouns in rules with individuals from the fact.  \n The input format is: The facts are:''. \n The rule is:''. \n The output format is: The grounded rule is:''  \n For example 1: The input facts are: Godwin is not sour. Godwin is short. Godwin is scared. Godwin is wild. Godwin is expensive. Godwin is not bad. Godwin is not straightforward. Godwin is anxious. Godwin is not stubborn. Godwin is not zany. Godwin laugh Connor.Godwin esteem Connor. Godwin is not immediate. Godwin is persistent. \n  The rule is: If someoneA laugh someoneB and he is not stubborn then he is old, unless he is not poor. \n The grounded rule is: If Godwin laugh Connor and Godwin is not stubborn then Godwin is old, unless Godwin is not poor.  \n Note that you only need to output the instantiation rules. Don\'t output your reasoning or thinking process.'
# 通过提示获取规则中的所有原子
All_Atomes_Prompt_Instruction = "Task Description: \n  Given a set of facts and a rule, you need to extract all instantiated facts in the rule. \n The input format is: The rule is:''. \n The output format is: The extracted facts are:'... ###'.\n  For example 1: The rule is: If Godwin laugh Connor and Godwin is not stubborn then Godwin is old, unless Godwin is not poor or Godwin is unhappy.  \n The extracted facts are: Godwin laugh Connor. Godwin is not stubborn. Godwin is old. Godwin is not poor. Godwin is unhappy.###  \n Note that you only need to output all extracted facts in the rule, Don\'t output your reasoning or thinking process."
# 对规则进行约间的提示
Iterative_Reduction_Prompt = "Task Description: \n Given facts and rules, you need to reduce the rules. \n The rule is: If A then B, unless C. The A is the prerequisite, the B is the conclusion, and the C is the justification.  If the prerequisite A of the rule is in fact and the justification C is not in fact, then rules can be reduced and you should output the reduced rule: 'If A then B. '; \n If the justification C of the rule is in fact, then the rule cannot be reduced and you should output: None###;  \n The input format is: The fact are:''. The rule is:''. \n The output format is: The reduced rule is:''###. \n For example 1: The facts are: Godwin is not sour. Godwin is short. Godwin is scared. Godwin is wild. Godwin is expensive. Godwin is not bad. Godwin is not straightforward. Godwin is anxious. Godwin is not stubborn. Godwin is not zany. Godwin laugh Connor. Godwin esteem Connor. Godwin is not poor. Godwin is persistent. \n The rule is: If Godwin laugh Connor and Godwin is not stubborn then Godwin is old, unless Godwin is not poor or Godwin is happy. \n The reduced rule is: None.### \n  For example 2: Facts are: Cara is loving. Cara is not straightforward. Cara is fearless. Cara is not zany. Cara is not combative. Cara is several. Cara is hollow. Cara is emotional. Cara is poor. Cara is granite. Cara does not laugh Lewis. Cara is not southern. Cara is not cheap. \n The rule is: If Cara is poor and emotional then Cara is able, unless Cara is dry or Cara is not supportive. \n The reduced rule is: If Cara is poor and emotional then Cara is able.### \n Note that you only need to output the reduced rule. Don\'t output your reasoning or thinking process."
# 基于相似性的方法对规则进行约简，
Iterative_Split_Rule_Prompt = "Task Description:  \n Given a rule, The rule format is: If A then B, unless C. The A is the prerequisite, the B is the conclusion, and the C is the justification.  You need to output all prerequisite, conclusions, and justifications in this rule. The input format is: The rule is:''. \n The output format is: The output is: prerequisite:'', conclusion:'', justification:''###.  \n For example 1: The rule is: If Brice is emotional then Brice is beige, unless Brice is sufficient.  \n  The output is: prerequisite: 'Brice is emotional. ', conclusion:'Brice is beige. ', justification:'Brice is sufficient. '. \n  For example 2: The rule is: If Cadman is historical and Cadman is emotional then Cadman is swift, unless Cadman is smart or Cadman is happy. \n  The output is: prerequisite: 'Cadman is historical. Cadman is emotional.', conclusion:'Cadman is swift. '; justification:'Cadman is smart. Cadman is happy.'###.  \n Note that you only need to output the prerequisite, conclusions, and justifications in the rules. Don\'t output your reasoning or thinking process."
# 封闭蕴含推理，即在给定事实列表和规则条件下，当给出的事实列表能够满足前提条件，同时也满足一致性条件时，就可以得出结论事实
Iterative_Conclusion_Reasoning_Prompt = "Task Description: \n Given facts and a rule. You need output the conclusion of the rules based on facts.\n The rule format is: If A then B. The A is the prerequisite fact, the B is the conclusion. If the prerequisite fact A is in the given facts, you can deduce the conclusion B. If the prerequisite fact A is not in the given facts, then you can not deduce the conclusion B, so your should output: None.###  \n The input format is: The facts are:''. \n The rule is:''. \n The output format is: The conclusion is:''. ### \n  Example 1: The facts are: Godwin is expensive. Godwin is not bad. Godwin is not sour. Godwin is not zany. Godwin is immediate. \n The rule is: If Godwin is not sour and immediate then Godwin is not lovely. \n The conclusion is: Godwin is not lovely.  ### \n  For example 1: The facts are: Juliana is giant. Juliana is comfortable. Juliana is not southern. Juliana is not technical. Juliana is low. \n The rule is: If Juliana is not short then Juliana is persistent.  \n The conclusion is: None. ### \n Note that you only need to output the conclusion of the rule. Don\'t output your reasoning or thinking process."
# 选择下一个事实模块的提示
Choose_fact_Prompt = "Task Description: \n Given fact set 1, fact set 2 and a question list, you need to generate a fact that is in fact set 2 but not in fact set 1, and at the same time, the generated fact is required to be closest to the question. If all facts in fact set 2 appear in fact set 1, then your output is: None. \n The input format is: The facts set 1 are:''. The facts set 2 are:''. \n The output format is: The choosed fact is:''. \n  For example 1: The facts set 1 are: Orson and Leroy is misjudge. Orson is hot. Orson and Leroy is laugh. Orson is emotional. Orson is amused. Orson is jolly. Orson and Leroy is honour. The facts set 2 are: Orson is amused. Orson is jolly. Orson and Leroy is honour.Orson is attractive. Orson is giant. Orson is melodic. Orson and Leroy is like. Questions are: Orson is happy. Orson is not attractive. Orson is attractive. \n  The choosed fact is: Orson is attractive. \n  For example 2: The facts set 1 are: Kirby is cool. Kirby is cloudy. Kirby is hurt. Kirby is nice. Kirby is sensible. Kirby is lively. Kirby is sweet. The facts set 2 are: Kirby is cool. Kirby is cloudy. Kirby is lively. Kirby is sweet. Kirby is hurt. Kirby is nice. Kirby is sensible. Questions are: Kirby is  nice. Kirby is not nice.  \n The choosed fact is: None. \n Note that you only need to output the fact that is in fact set 2 but not in fact set 1. Don\'t output your reasoning or thinking process. "
# 在谨慎推理模式下的提示
Credulous_Reasoning_Prompt= 'Dask Description: \n Given the extensions and question, and each extension consists of facts. you need to answer the questions according to the given extensions. \n If the question can be inferred based on a certain extension, the answer label of the question is "True"; \n If the negation of the question can be inferred based on a certain extension, the answer label of the question is "False"; \n If the question and the negation of the question both cannot be deduced under all extensions, the answer label of the question is "Unknown".  \n The input format is: The extension 1 are:''. The extension 2 are:''.\n The question is:".  \n The output format is: The answer is:".###  \n For example:  The extension 1 are: "Magnus and Malcolm is spurn. Magnus is difficult. Magnus is arrogant. Magnus is nasty. Magnus is dangerous. Magnus is important. Magnus is vast. Magnus is handsome.".  The extension 2 are: "Magnus is not important. Magnus is vast. Magnus is dramatic. Magnus is not handsome. Magnus is poor. Magnus is sensitive.". \n The question is: "Magnus is happiness.". \n The answer is: "Unknown"###. \n The question is: "Magnus is important". \n The answer is: "True"###. \n The question is: "Magnus is not dramatic. ". \n The answer is: "False"###. \n Note that you only need to generate the answer label for the question. Don\'t output your reasoning or thinking process. Please read all extensions carefully and answer the question.'
# 可怀疑推理模式，让大模型基于可怀疑推理模式的打标签方式进行推理
Skeptical_Reasoning_Prompt = 'Dask Description: \n Given the extensions and question, and each extension consists of facts. you need to answer the questions according to the given extensions. \n If the question can be inferred under all extensions, the answer label of the question is: "True". \n If the negation of the question can be inferred under all extensions, the answer label of the question is: "False". \n If the question and the negation of the question cannot be deduced under a certain extension, the answer label of the question is: "Unknown". \n The input format is: The extension 1 are:''. The extension 2 are:''. \n The question is:". \n The output format is: The answer is:"###.  \n For example :  The extension 1 are: "Magnus and Malcolm is spurn. Magnus is difficult. Magnus is arrogant. Magnus is nasty. Magnus is dangerous. Magnus is important. Magnus is vast. Magnus is not handsome.".  The extension 2 are: "Magnus is not important. Magnus is vast. Magnus is dramatic. Magnus is not handsome. Magnus is poor. Magnus is sensitive.". \n The question is: "Magnus is not important". \n The answer is: "Unknown"###. \n The question is: "Magnus is vast". \n The answer is: "True"###. \n The question is: "Magnus is handsome.". The answer is: "False"###. \n Note that you only need to generate the answer label for the question. Don\'t output your reasoning or thinking process. Please read all extensions carefully and answer the question.'

Yeliang_API_Key = "sk-n7IWXtrI2d0JsnbuDa6dD8F090444fEaAaF1C101D899Fa3b" # "sk-wYnDOGnqs7X62a2DEcFa8094B6384f2aAf12AfD88d1dC649", "sk-n7IWXtrI2d0JsnbuDa6dD8F090444fEaAaF1C101D899Fa3b"
Base_URL =  "https://35.aigcbest.top/v1" #  "https://api.nhyun.top" #"https://35.aigcbest.top/v1"

Answer_Set_List = []
Soft_Answer_Set_List =[] # 存储下界大于上界时的回答集，如果严格条件下求出的答案集为空，则将松弛条件下的答案集作为最终答案集
Prerequisite_Conclusion_Consistent_Facts_Dict ={} # 用于存储每个样本的
Each_Example_chatgpt_Number = 0 # 用于记录每个样本调用大模型的次数
Slove_Iternumber = 3 # 用于指示搜索迭代的深度
llama3_8B_model, llama3_model_tokenizer = None, None


def GPT4o_Solver_with_API(instructions, context):
    global Each_Example_chatgpt_Number
    Each_Example_chatgpt_Number = Each_Example_chatgpt_Number + 1
    print('Each_Example_chatgpt_Number={}'.format(Each_Example_chatgpt_Number))
    client = OpenAI(base_url=Base_URL,
                    api_key=Yeliang_API_Key,
                    http_client=httpx.Client(base_url=Base_URL,follow_redirects=True,
                                             ),
                    )
    while_count01 = 0
    while while_count01 < 10:
        try:
            rsp = client.chat.completions.create(
              model="gpt-4o-mini", # gpt-3.5-turbo
              messages=[
                    {"role": "system", "content": instructions},
                    {"role": "user", "content": context }
                ],
              temperature=0
            )
            result = rsp.choices[0].message.content
            return result
        except Exception as e:
            print(f"llm_send报错 {while_count01 + 1}次尝试: {e}")
            while_count01 += 1
    return ""


Iterative_Base_Model = None
Atoms_Output_Pattern,Reduction_Output_Pattern, Grounded_Output_Pattern, Reasoning_Output_Pattern,Choose_Output_Pattern = None, None, None,None,None
Extracted_LLM_Answer_Pattern = None
if LLMs_Models_Choise =='GPT4o':
    Iterative_Base_Model = GPT4o_Solver_with_API
    Grounded_Output_Pattern = "(?<=grounded rule is:).*?(?=\.|Note|#|Instruction|Instantiation|\.|1```1|Instantiated)"  # 用于提取LLAMA3的输出结果
    Atoms_Output_Pattern = "(?<=extracted facts are:).*?(?=Note|#|Instruction|1```1)"  # 用于提取LLAMA3的输出结果
    Reduction_Output_Pattern = "(?<=output is:).*?(?=Note|#|Instruction|1```1)"  # 用于提取LLAMA3的输出结果
    Reasoning_Output_Pattern = "(?<=conclusion is:).*?(?=Note|#|Instruction|1```1|Final Answer|\.)"  # 用于提取LLAMA3的输出结果 # Final Answer:
    Choose_Output_Pattern = "(?<=choosed fact is:).*?(?=Note|#|Instruction|1```1)"  # 用于提取LLAMA3的输出结果
    Extracted_LLM_Answer_Pattern = "(?<=answer is:).*?(?=Note|#|Instruction|1```1)"  # 用于提取LLAMA3的输出结果

import difflib
import torch
from transformers import TrainingArguments, AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig,AutoTokenizer, AutoModel

from sentence_transformers import SentenceTransformer, util
Similarity_Value = 0.96
# 创建模型，这里使用了distilbert-base-nli-stsb-mean-tokens模型
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
embedding_tokenizer = AutoTokenizer.from_pretrained('/home/yeliangxiu/Projects/Pre_trained_Models/distilbert-base-nli-stsb-mean-tokens')
embedding_model = AutoModel.from_pretrained('/home/yeliangxiu/Projects/Pre_trained_Models/distilbert-base-nli-stsb-mean-tokens').to(device)

def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output[0] #First element of model_output contains all token embeddings
    input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

# 定义一个基于embedding来计算相似性的函数
def similarity(str1, str2):

    encoded_input01 = embedding_tokenizer(str1, padding=True, truncation=True, return_tensors='pt').to(device)
    # Compute token embeddings
    with torch.no_grad():
        model_output01 = embedding_model(**encoded_input01)
    # Perform pooling. In this case, max pooling.
    sentence_embeddings01 = mean_pooling(model_output01, encoded_input01['attention_mask'])

    encoded_input02 = embedding_tokenizer(str2, padding=True, truncation=True, return_tensors='pt').to(device)
    # Compute token embeddings
    with torch.no_grad():
        model_output02 = embedding_model(**encoded_input02)
    # Perform pooling. In this case, max pooling.
    sentence_embeddings02 = mean_pooling(model_output02, encoded_input02['attention_mask'])
    cosine_similarity = util.cos_sim(sentence_embeddings01, sentence_embeddings02)

    return cosine_similarity

# 定义事实集合的等价性判断函数
def equation(fact_list01, fact_list02):
    # 遍历集合1中的事实
    fact_list_similarity01, fact_list_similarity02 = "True", "True"

    fact_similarity = similarity(fact_list01, fact_list02)
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_fact_similarity01 = torch.max(fact_similarity, dim=1) # 求相似矩阵中的每一行的最大值
    min_max_fact_similarity01 = torch.min(max_fact_similarity01.values)
    if min_max_fact_similarity01 < Similarity_Value:
        fact_list_similarity01 = "False"

    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_fact_similarity02 = torch.max(fact_similarity, dim=0)  # 求相似矩阵中的每一列的最大值
    min_max_fact_similarity02 = torch.min(max_fact_similarity02.values)
    if min_max_fact_similarity02 < Similarity_Value:
        fact_list_similarity02 = "False"

    if fact_list_similarity01 == "True" and fact_list_similarity02 == "True":
        return "True"
    else:
        return "False"


# 定义一个函数，用于判断事实1是否包含在事实列表2中
def Include(fact_list01, fact_list02):
    # 遍历集合1中的事实
    fact_list_similarity01 = "True"
    fact_similarity = similarity(fact_list01, fact_list02)
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_fact_similarity01 = torch.max(fact_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
    min_max_fact_similarity = torch.min(max_fact_similarity01.values)
    # 同时计算出事实1集合中存在不包含在事实集合2 中的事实数量
    different_fact_number = 0
    if min_max_fact_similarity < Similarity_Value:
        different_fact_number = different_fact_number + 1

        fact_list_similarity01 = "False"

    return fact_list_similarity01, different_fact_number

# 定义一个函数，用于求二个事实集合的并
def fact_union(fact_list01, fact_list02):
    fact_union_list = copy.deepcopy(fact_list02)
    fact_similarity = similarity(fact_list01, fact_list02)
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_fact_similarity01 = torch.max(fact_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
    # 如果事实1集合中的事实与事实2集合中的事实相似性小于0.9, 则将事实1添加到事实2中
    for key01 in range(len(fact_list01)):
        if max_fact_similarity01.values[key01] < Similarity_Value:
            fact_union_list.append(fact_list01[key01])

    return fact_union_list

# 定义一个函数，用于求二个事实集合的交
def fact_intersection(fact_list01, fact_list02):
    fact_intersection = []
    fact_similarity = similarity(fact_list01, fact_list02)
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_fact_similarity01 = torch.max(fact_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
    # 如果事实1集合中的事实与事实2集合中的事实相似性小于0.9, 则将事实1添加到事实2中
    for key01 in range(len(fact_list01)):
        if max_fact_similarity01.values[key01] > Similarity_Value: # 最大相似度大于0.9， 则说明二个集合中都包含相同的事实
            fact_intersection.append(fact_list01[key01])

    return fact_intersection

# 定义一个函数用于对事实列表进行去重
def Remove_Same_Fact(fact_list01):
    remain_fact_list = []
    for key01 in range(len(fact_list01)):
        if len(fact_list01[key01])<10:
            continue
        fact01 = fact_list01[key01]
        if key01 ==0:
            remain_fact_list.append(fact01)
        else:
            # 需要判断fact01是否在remain_fact_list列表中
            fact_similarity = similarity(fact01, remain_fact_list)
            # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
            max_similarity = torch.max(fact_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
            if max_similarity.values[0] < Similarity_Value:
                remain_fact_list.append(fact01)
    return remain_fact_list


# 定义一个函数，用于从事实列表中删除一个事实
def Remove(fact, fact_list01):
    # 找到相似度最大匹配的那个事实进行删除
    Remove_List = []

    fact_similarity = similarity(fact, fact_list01)
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_fact_similarity01 = torch.max(fact_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
    for fact_key in range(len(fact_list01)):
        if fact_similarity[0][fact_key] < max_fact_similarity01.values[0]:
            Remove_List.append(fact_list01[fact_key])
    return Remove_List

# 定义一个函数，用于从事实2中删除事实1中的事实
def Remove_Fact(fact_list01, Answer_Set_Facts):
    # 找到相似度最大匹配的那个事实进行删除
    Remain_List = []

    fact_similarity = similarity(Answer_Set_Facts, fact_list01)
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_fact_similarity01 = torch.max(fact_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
    for fact_key in range(len(Answer_Set_Facts)):
        if max_fact_similarity01.values[0] < Similarity_Value:
            Remain_List.append(Answer_Set_Facts[fact_key])
    return Remain_List

# 定义一个函数，用于调用工具继续实例化 基于Spacy的进行指代消解
import spacy


# 定义一个函数，用于调用大模型进行实例化

def Grounded_Reasoning_based_LLMs(NL_Origin_Facts, Total_Rule_Strings,rule_key01 ):
    global Output_Grounded_Pattern
    grounded_rule_result = ''
    while_count01 = 0
    while True:
        if while_count01>10: # 如果超过10次，则使用原始规则作为实例化后的规则。
            break
        # 调用大模型对每个规则进行实例化，
        gounded_rule_context = 'The facts are:' + NL_Origin_Facts + ' \n ' +  'The rule is: ' + Total_Rule_Strings
        grounded_rule_origin_result = Iterative_Base_Model(Grounded_Prompt_Instrunction, gounded_rule_context)
        if not isinstance(grounded_rule_origin_result, str):
            while_count01 = while_count01 + 1
            print("大模型返回结果不是字符串类型，需要重新获取。")
            continue
        grounded_rule_result = grounded_rule_origin_result.replace('\n', '')
        # grounded_rule_result = grounded_rule_result[:200]
        # if grounded_rule_result[:20].find('grounded rule is') == False or grounded_rule_result[:20].find('grounded rule is') == -1:
        #     grounded_rule_result = 'The grounded rule is: ' + grounded_rule_result
        while_count01 = while_count01 + 1
        grounded_rule_string = ''
        grounded_rule_result = grounded_rule_result.replace('\n', '').replace('The output is', 'The grounded rule is')
        if 'grounded rule is:' in grounded_rule_result:
            grounded_rule = re.findall(Grounded_Output_Pattern, grounded_rule_result)
            if len(grounded_rule) == 0:
                grounded_rule_result = Total_Rule_Strings
                continue
            grounded_rule_string = grounded_rule[0]
            if len(grounded_rule_string) < 5:
                grounded_rule_result = Total_Rule_Strings
                continue
            if ' he ' in grounded_rule_string or ' someoneA ' in grounded_rule_string or ' someoneB ' in grounded_rule_string:
                grounded_rule_result = grounded_rule_string
                print('实例化后的规则中包含特殊字符，需要重新实例化。grounded_rule_string={}'.format(grounded_rule_string))
                continue
            if ' then ' not in grounded_rule_string or ' If ' not in grounded_rule_string or 'unless ' not in grounded_rule_string:
                grounded_rule_result = grounded_rule_string
                print('实例化后的规则中不包含then，需要重新实例化。grounded_rule_string={}'.format(grounded_rule_string))
                continue
            # 计算实例化的句子与原始句子之间的语义相似性
            grounded_rule_string01 = grounded_rule_string if grounded_rule_string[-1]!='.' else grounded_rule_string
            Total_Rule_Strings01 = Total_Rule_Strings.replace('. ','.')
            grounded_rule_similarity = similarity(grounded_rule_string01, Total_Rule_Strings01)
            if grounded_rule_similarity > 0.45:
                grounded_rule_result = grounded_rule_string
                break
            else:
                grounded_rule_result = grounded_rule_string
                print('实例化后的规则与原始规则语义不匹配！grounded_rule_similarity={},grounded_rule_string={},grounded_rule_origin_result={}'.format(grounded_rule_similarity,grounded_rule_string, Total_Rule_Strings))
                continue
        else:
            grounded_rule_result = Total_Rule_Strings
            print('实例化的规则格式错误。grounded_rule_ result={}'.format(grounded_rule_result))
            continue
    print("利用大模型实例化上下文：rule_key01={}, \n grounded_rule_result={},\n grounded_rule_origin_result={}".format(rule_key01,grounded_rule_result, Total_Rule_Strings))

    return grounded_rule_result


# 定义一个函数，用于根据大模型对规划划分后的前提条件、一致性条件和结论进行约简
# 输入为事实列表和上下文
# 约简规则：只要事实中出现在一致性条件中的事实出现在事实中，就不能进行约简
def Iterative_Split_Reduction_Prompt_Based_Similarity(TA_facts_list, FA_facts_list, TA_conclusion, FA_conclusion, context, rule_number):
    TA_Reduction_Result, FA_Reduction_Result = '', ''
    TA_facts_list02, FA_facts_list02 = copy.deepcopy(TA_facts_list), copy.deepcopy(FA_facts_list)
    # 在迭代遍历规则进行约简和推理时，需要将之前规则推出的结论对上下界进行更新
    # if 'None' not in TA_conclusion and TA_conclusion not in TA_facts_list02:
    #     TA_facts_list02.append(TA_conclusion)
    # if 'None' not in FA_conclusion and FA_conclusion not in FA_facts_list02:
    #     FA_facts_list02.append(FA_conclusion)
    # 调用大模型对规则进行划分，分别产生前提条件、一致性条件和结论事实列表
    global Prerequisite_Conclusion_Consistent_Facts_Dict
    prerequisites_list, consistencys_list, conclusions_list = [], [], []
    if rule_number not in Prerequisite_Conclusion_Consistent_Facts_Dict.keys():
        Prerequisite_Conclusion_Consistent_Facts_Dict[
            rule_number] = {}  # 用于存储每个样本的每个规则的前提条件、一致性条件和结论，关键字为前提条件、一致性条件和结论，值为对应的事实列表
        while_count01 = 0
        while True:
            if while_count01 > 10:
                break
            prerequisites_list, consistencys_list, conclusions_list = [], [], []
            Iterative_Split_Rule_Result = Iterative_Base_Model(Iterative_Split_Rule_Prompt, context)
            if not isinstance(Iterative_Split_Rule_Result, str):
                while_count01 = while_count01 + 1
                print("大模型返回结果不是字符串类型，需要重新获取。")
                continue
            if Iterative_Split_Rule_Result.find('output is') == -1:
                Iterative_Split_Rule_Result = 'The output is:' + Iterative_Split_Rule_Result
            Iterative_Split_Rule_Result = Iterative_Split_Rule_Result.replace('\n', '')
            while_count01 = while_count01 + 1
            # print('Iterative_Split_Rule_Result={}'.format(Iterative_Split_Rule_Result))
            if 'output' in Iterative_Split_Rule_Result and ':' in Iterative_Split_Rule_Result and 'prerequisite' in Iterative_Split_Rule_Result and 'justification' in Iterative_Split_Rule_Result and 'conclusion' in Iterative_Split_Rule_Result:
                if '#' not in Iterative_Split_Rule_Result:
                    Iterative_Split_Rule_Result = Iterative_Split_Rule_Result + '#'
                prerequisites = re.findall(r".*prerequisite:(.*)conclusion", Iterative_Split_Rule_Result)
                conclusion = re.findall(r".*conclusion:(.*)justification", Iterative_Split_Rule_Result)
                justifications = re.findall(r".*justification:(.*)#", Iterative_Split_Rule_Result) # "(?<=justification).*?(?=#)"

                # 遍历前提条件
                if len(prerequisites) != 0:
                    prerequisites_list01 = prerequisites[0].split('.')
                    for key01 in range(len(prerequisites_list01)):
                        if len(prerequisites_list01[key01]) > 5:
                            prerequisites_list01[key01] = prerequisites_list01[key01].replace('\'', '') 
                            prerequisites_list.append(prerequisites_list01[key01])
                # 遍历结论
                if len(conclusion) != 0:
                    conclusion_list01 = conclusion[0].split('.')
                    for key03 in range(len(conclusion_list01)):
                        if len(conclusion_list01[key03]) > 5:
                            conclusion_list01[key03] = conclusion_list01[key03].replace('\'', '') 
                            conclusions_list.append(conclusion_list01[key03])
                # 遍历一致性条件
                if len(justifications) != 0:
                    justifications_list01 = justifications[0].replace('#','').split('.')
                    for key02 in range(len(justifications_list01)):
                        if len(justifications_list01[key02]) > 5:
                            justifications_list01[key02] = justifications_list01[key02].replace('\'', '') 
                            consistencys_list.append(justifications_list01[key02])
                # 如果一致性条件、前提条件和结论为空，则重新抽取
                if len(consistencys_list) == 0 or len(prerequisites_list) == 0 or len(conclusions_list) == 0:
                    while_count01 = while_count01 + 1
                    print("抽取的前提条件或一致性条件或者结论为空！")
                    continue
                # 如果一致性条件、前提条件和结论为空，则重新抽取
                if len(consistencys_list) == 0 or len(prerequisites_list) == 0 or len(conclusions_list) == 0:
                    while_count01 = while_count01 + 1
                    print("抽取的前提条件或一致性条件或者结论为空！")
                    continue
                # 如果前提条件、一致性条件和结论的个数大于3，则重新抽取
                if len(prerequisites_list) > 3 or len(conclusions_list) > 2 or len(consistencys_list) > 3:
                    while_count01 = while_count01 + 1
                    print("大模型抽取的规则过于复杂，需要重新抽取。prerequisites_list={}, conclusions_list={}, consistencys_list={}".format(prerequisites_list, conclusions_list, consistencys_list))
                    continue
                
                break
            else:
                print("生成的约简格式错误。Iterative_Split_Rule_Result={}".format(Iterative_Split_Rule_Result))
                continue

        Prerequisite_Conclusion_Consistent_Facts_Dict[rule_number]['prerequisites'] = prerequisites_list
        Prerequisite_Conclusion_Consistent_Facts_Dict[rule_number]['consistencys'] = consistencys_list
        Prerequisite_Conclusion_Consistent_Facts_Dict[rule_number]['conclusions'] = conclusions_list
        print('大模型产生的约简结果：len(prerequisites)={}, prerequisites:={}, len(conclusion)={}, conclusion={}, len(justifications)={}, justifications={}'.format(len(prerequisites_list), prerequisites_list, len(conclusions_list), conclusions_list,len(consistencys_list), consistencys_list))

    else:
        prerequisites_list = Prerequisite_Conclusion_Consistent_Facts_Dict[rule_number]['prerequisites']
        consistencys_list = Prerequisite_Conclusion_Consistent_Facts_Dict[rule_number]['consistencys']
        conclusions_list = Prerequisite_Conclusion_Consistent_Facts_Dict[rule_number]['conclusions']
        print('使用存储好的规则约简结果：len(prerequisites)={}, prerequisites:={}, len(conclusion)={}, conclusion={}, len(justifications)={}, justifications={}'.format(len(prerequisites_list), prerequisites_list, len(conclusions_list), conclusions_list,len(consistencys_list), consistencys_list))

    # 然后根据相似度判断是否需要进行约减
    # 如果前提条件都在事实中，即相似度都大于0.95，且一致性条件都不在事实中，则进行TA事实集合下的约减
    TA_Total_Prerequisite_Flag, TA_Total_Consistency_Flag, TA_Total_Conclusion_Flag = 'False', 'False', 'False'
    TA_Prerequisite_Flag_list, TA_Consistency_Flag_list, TA_Conclusion_Flag_list = [], [], []

    # 遍历一致性条件

    consistency_TA_similarity = similarity(consistencys_list, TA_facts_list02) if len(consistencys_list) > 0 else torch.tensor([[0]])
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_consistency_TA_similarity = torch.max(consistency_TA_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
    for key01 in range(len(consistencys_list)):
        if max_consistency_TA_similarity.values[key01] > Similarity_Value:
            TA_Consistency_Flag_list.append('True')
        else:
            TA_Consistency_Flag_list.append('False')

    TA_Total_Consistency_Flag = 'True' if 'True' in TA_Consistency_Flag_list else 'False'
    prerequisites_string = ''
    for key01 in range(len(prerequisites_list)):
        prerequisites_string = prerequisites_list[key01] + ' ' if int(key01) == 0 else prerequisites_string + ' and ' + prerequisites_list[key01] + ' '

    # 如果一致性条件出现在事实中，即相似度都大于0.95，且一致性条件都不在事实中，则进行约减
    # 下界约简用于更新上届，只需选择下界约简后规则的结论在上界中是否存在，如果不存在则不需要进行约简 and TA_Total_Conclusion_Flag == 'True'
    if TA_Total_Consistency_Flag == 'False' and len(conclusions_list) > 0:
        TA_Reduction_Result = 'If ' + prerequisites_string + ' then ' + conclusions_list[0] + '. '
    else:
        TA_Reduction_Result = 'Inconsistent'
    
    # 在FA事实集合下进行约减
    FA_Total_Prerequisite_Flag, FA_Total_Consistency_Flag, FA_Total_Conclusion_Flag = 'False', 'False', 'False'
    FA_Prerequisite_Flag_list, FA_Consistency_Flag_list, FA_Conclusion_Flag_list = [], [], []

    # 遍历一致性条件
    consistency_FA_similarity = similarity(consistencys_list, FA_facts_list02) if len(consistencys_list) > 0 else torch.tensor([[0]])
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_consistency_FA_similarity = torch.max(consistency_FA_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
    for key01 in range(len(consistencys_list)):
        if max_consistency_FA_similarity.values[key01] > Similarity_Value:
            FA_Consistency_Flag_list.append('True')
        else:
            FA_Consistency_Flag_list.append('False')

    FA_Total_Consistency_Flag = 'True' if 'True' in FA_Consistency_Flag_list else 'False'
    prerequisites_string = ''
    for key01 in range(len(prerequisites_list)):
        prerequisites_string = prerequisites_list[key01] + ' ' if int(key01) == 0 else prerequisites_string + ' and ' + prerequisites_list[key01] + ' '

    # 如果前提条件都在事实中，即相似度都大于0.9，且一致性条件都不在事实中，则进行约减 and FA_Total_Conclusion_Flag=='False'
    if FA_Total_Consistency_Flag == 'False' and len(conclusions_list) > 0:
        FA_Reduction_Result = 'If ' + prerequisites_string + ' then ' + conclusions_list[0] + '. '
    else:
        FA_Reduction_Result = 'Inconsistent'
    TA_conclusion02, FA_conclusion02 = '', ''
    FA_List_String02 = ''
    for key01 in range(len(FA_facts_list02)):
        FA_List_String02 = FA_List_String02 + FA_facts_list02[key01]
    if "None" not in FA_conclusion and len(FA_conclusion)>10: # 如果之前规则在上界事实产生的结论不为空，且长度大于10，则将结论添加到事实中用于推理
        FA_List_String02 = FA_List_String02 + FA_conclusion 
        FA_List_String02 = FA_List_String02 + '.' if FA_List_String02[-1] != '.' else FA_List_String02
    FA_List_String02 = FA_List_String02.replace('..', '.').replace('. .', '. ')  # 避免出现连续的句点

    TA_List_String02 = ''
    for key02 in range(len(TA_facts_list02)):
        TA_List_String02 = TA_List_String02 + TA_facts_list02[key02] + ' '
    if "None" not in TA_conclusion and len(TA_conclusion)>10: # 如果之前规则在下界事实产生的结论不为空，且长度大于10，则将结论添加到事实中用于推理
        TA_List_String02 = TA_List_String02 + TA_conclusion 
        TA_List_String02 = TA_List_String02 + '.' if TA_List_String02[-1] != '.' else TA_List_String02
    TA_List_String02 = TA_List_String02.replace('..', '.').replace('. .', '. ')  # 避免出现连续的句点

    # 然后迭代的对约间结果进行推理
    # 推理步骤进一步分为二步，第一步进行约间，第二步进行推理Concluson操作推理
    if 'Inconsistent' not in FA_Reduction_Result:
        TA_FA_Flag = 'FA'  # 用于指示是在下界还是上界进行推理
        FA_conclusion02 = Iterative_Reasoning_Prompt_Based_LLMs(TA_FA_Flag, FA_List_String02, FA_Reduction_Result,rule_number)
    else:
        FA_conclusion02 = 'None'

    if 'Inconsistent' not in TA_Reduction_Result:
        TA_FA_Flag = 'TA'  # 用于指示是在下界还是上界进行推理
        TA_conclusion02 = Iterative_Reasoning_Prompt_Based_LLMs(TA_FA_Flag, TA_List_String02, TA_Reduction_Result,rule_number)
    else:
        TA_conclusion02 = 'None'

    print('Reduction and Reasoning: rule_number={},FA_Reduction_Result={}, FA_conclusion02={}, TA_Reduction_Result={}, TA_conclusion02={}'.format(rule_number, FA_Reduction_Result, FA_conclusion02, TA_Reduction_Result, TA_conclusion02))

    return TA_conclusion02, FA_conclusion02,consistencys_list

# 定义一个函数，直接调用大模型进行约简
def Iterative_Reduction_and_Reasoning_Prompt_Based_LLMs(TA_Fact_Lists,FA_Fact_Lists, TA_conclusion, FA_conclusion, Rule_string, Rule_key):
    TA_Fact_Lists02, FA_Fact_Lists02= copy.deepcopy(TA_Fact_Lists), copy.deepcopy(FA_Fact_Lists)
    # 在迭代遍历规则进行约简和推理时，需要将之前规则推出的结论对上下界进行更新
 
    # 在迭代遍历规则进行约简和推理时，需要将之前规则推出的结论对上下界进行更新
    # if 'None' not in TA_conclusion and TA_conclusion not in TA_Fact_Lists02:
    #     TA_Fact_Lists02.append(TA_conclusion)
    
    # 根据相似性选择约简的事实
    similarity_maxtrix = similarity(TA_Fact_Lists02, [Rule_string])
    # 基于相似性矩阵选择分数最高的5个事实
    # 获取相似性分数最高的5个事实
    # 获取相似性分数最高的5个事实
    top_k = len(TA_Fact_Lists02)  # 选择前5个相似度最高的事实
    # 将相似性矩阵转换为一维数组
    similarity_scores = similarity_maxtrix.squeeze(1)  # 将K*1的矩阵转换为K维向量
    
    # 获取排序后的索引（降序）
    _, indices = torch.sort(similarity_scores, descending=False)
    
    # 选择前top_k个索引（如果事实总数少于top_k，则取所有事实）
    selected_indices = indices[:min(top_k, len(TA_Fact_Lists02))]
    
    # 根据选择的索引获取对应的事实
    selected_facts = [TA_Fact_Lists02[idx.item()] for idx in selected_indices]
    
    # 将选择的事实组合成字符串
    TA_Fact_Lists02 = '. '.join(selected_facts) + '.'
    TA_Fact_Lists02 = TA_Fact_Lists02.replace('..', '.')  # 避免出现连续的句点

    # 将事实列表转换为字符串
    TA_Fact_List_String02, FA_Fact_List_String02 = '',''
    for key01 in range(len(TA_Fact_Lists02)):
        TA_Fact_List_String02 = TA_Fact_List_String02 + TA_Fact_Lists02[key01] + ' '
    
    TA_rule_reduction_result, FA_rule_reduction_result,TA_reduction_rule_string = '','',''
    while_count = 1
    while True:
        if while_count > 10:
            TA_rule_reduction_result= TA_reduction_rule_string
            break
        TA_reduction_context = 'The facts are: ' + TA_Fact_List_String02 + ' \n ' + Rule_string
        TA_reduction_result = Iterative_Base_Model(Iterative_Reduction_Prompt, TA_reduction_context)
        # 检查返回结果是否为字符串类型，如果不是则重新生成
        if not isinstance(TA_reduction_result, str):
            print("推理结果不是字符串类型，重新生成")
            continue
        TA_reduction_result = TA_reduction_result.replace('\n', '')
        while_count = while_count + 1

        if ':' in TA_reduction_result and 'reduced rule is' in TA_reduction_result and '#' in TA_reduction_result:
            TA_reduction_rule = re.findall(Reduction_Output_Pattern, TA_reduction_result)
            if len(TA_reduction_rule)==0:
                continue
            else:
                TA_reduction_rule_string = TA_reduction_rule[0] + '. '
            if 'None' in TA_reduction_rule_string or 'none' in TA_reduction_rule_string:
                TA_rule_reduction_result = 'None'
                break
            else:
                TA_reduction_rule_string = TA_reduction_rule_string[1:] if TA_reduction_rule_string[0] == ' ' else TA_reduction_rule_string
                TA_rule_reduction_result = TA_reduction_rule_string
                break
        else:
            TA_reduction_rule_string = 'None'
            continue
    print('在TA事实集合下进行约简: rule_key = {}, while_count={}, TA_reduction_result={}, TA_reduction_context={}'.format(Rule_key, while_count, TA_rule_reduction_result, TA_reduction_context))

        
    # if 'None' not in FA_conclusion and FA_conclusion not in FA_Fact_Lists02:
    #     FA_Fact_Lists02.append(FA_conclusion)

    # 根据相似性选择约简的事实
    similarity_maxtrix = similarity(FA_Fact_Lists02, [Rule_string])
    # 基于相似性矩阵选择分数最高的5个事实
    # 获取相似性分数最高的5个事实
    # 获取相似性分数最高的5个事实
    top_k = len(FA_Fact_Lists02)  # 选择前5个相似度最高的事实
    # 将相似性矩阵转换为一维数组
    similarity_scores = similarity_maxtrix.squeeze(1)  # 将K*1的矩阵转换为K维向量
    
    # 获取排序后的索引升序
    _, indices = torch.sort(similarity_scores, descending=False)
    
    # 选择前top_k个索引（如果事实总数少于top_k，则取所有事实）
    selected_indices = indices[:min(top_k, len(TA_Fact_Lists02))]
    
    # 根据选择的索引获取对应的事实
    selected_facts = [TA_Fact_Lists02[idx.item()] for idx in selected_indices]
    
    # 将选择的事实组合成字符串
    TA_Fact_Lists02 = '. '.join(selected_facts) + '.'
    FA_Fact_Lists02 = FA_Fact_Lists02.replace('..', '.')  # 避免出现连续的句点


    for key01 in range(len(FA_Fact_Lists02)):
        FA_Fact_List_String02 = FA_Fact_List_String02 + FA_Fact_Lists02[key01] + ' '

    while_count = 1
    FA_rule_reduction_result, FA_reduction_rule_string = '',''
    while True:
        if while_count > 10:
            FA_rule_reduction_result = FA_reduction_rule_string
            break
        FA_reduction_context = 'The facts are: ' + FA_Fact_List_String02 + ' \n ' + Rule_string
        FA_reduction_result = Iterative_Base_Model(Iterative_Reduction_Prompt, FA_reduction_context)
        # 检查返回结果是否为字符串类型，如果不是则重新生成
        if not isinstance(FA_reduction_result, str):
            print("推理结果不是字符串类型，重新生成")
            continue
        FA_reduction_result = FA_reduction_result.replace('\n', '')
        while_count = while_count + 1

        if ':' in FA_reduction_result and 'reduced rule is' in FA_reduction_result and '#' in FA_reduction_result:
            FA_reduction_rule = re.findall(Reduction_Output_Pattern, FA_reduction_result)
            if len(FA_reduction_rule)==0:   
                continue
            else:
                FA_reduction_rule_string = FA_reduction_rule[0] + '. '
            if 'None' in FA_reduction_rule_string or 'none' in FA_reduction_rule_string:
                FA_rule_reduction_result = 'None'
                break
            else:   
                FA_reduction_rule_string = FA_reduction_rule_string[1:] if FA_reduction_rule_string[0] == ' ' else FA_reduction_rule_string
                FA_rule_reduction_result = FA_reduction_rule_string
                break
        else:
            FA_reduction_rule_string = 'None'
            continue
    print('在TA事实集合下进行约简: rule_key = {}, while_count={}, TA_reduction_result={}, TA_reduction_context={}'.format(Rule_key, while_count, FA_rule_reduction_result, FA_reduction_context))


    # 然后迭代的对约间结果进行推理
    # 推理步骤进一步分为二步，第一步进行约间，第二步进行推理Concluson操作推理
    if 'None' not in FA_rule_reduction_result:
        TA_FA_Flag = 'FA'  # 用于指示是在下界还是上界进行推理
        FA_conclusion02 = Iterative_Reasoning_Prompt_Based_LLMs(TA_FA_Flag, FA_Fact_List_String02, FA_rule_reduction_result,Rule_key)
    else:
        FA_conclusion02 = 'None'

    if 'None' not in TA_rule_reduction_result:
        TA_FA_Flag = 'TA'  # 用于指示是在下界还是上界进行推理
        TA_conclusion02 = Iterative_Reasoning_Prompt_Based_LLMs(TA_FA_Flag, TA_Fact_List_String02, TA_rule_reduction_result,Rule_key)
    else:
        TA_conclusion02 = 'None'

    print('Reduction and Reasoning: rule_number={},FA_Reduction_Result={}, FA_conclusion02={}, TA_Reduction_Result={}, TA_conclusion02={}'.format(Rule_key, FA_rule_reduction_result, FA_conclusion02, TA_rule_reduction_result, TA_conclusion02))

    return TA_conclusion02, FA_conclusion02


# 定义一个函数，用于实现对基于大模型的推理
def Iterative_Reasoning_Prompt_Based_LLMs(TA_FA_Flag, Facts_String02, Reduction_Rule, rule_number):
    reasoning_result = ''
    while_count02 = 1
    global Reasoning_Output_Pattern
    Reduction_Rule = Reduction_Rule.replace('  ',' ')

    # 推理之前基于相似性先进行前提选择
    Origin_Fact_Lists=[]
    Origin_Fact_Lists01 = Facts_String02.split('.')
    for key01 in range(len(Origin_Fact_Lists01)):
        if len(Origin_Fact_Lists01[key01].strip()) < 5:
            continue
        else:
            Origin_Fact_Lists.append(Origin_Fact_Lists01[key01].strip())
    # 基于相似性选择前提
    similarity_maxtrix = similarity(Origin_Fact_Lists, [Reduction_Rule])
    # 基于相似性矩阵，对所有前提事实 ，按照相似性从小到大重新排序。
    top_k = len(Origin_Fact_Lists)  # 
    # 将相似性矩阵转换为一维数组
    similarity_scores = similarity_maxtrix.squeeze(1)  # 将K*1的矩阵转换为K维向量
    
    # 获取排序后的索引（升序，从小到大）
    _, indices = torch.sort(similarity_scores, descending=False)
    
    # 选择前top_k个索引（如果事实总数少于top_k，则取所有事实）
    selected_indices = indices[:min(top_k, len(Origin_Fact_Lists))]
    
    # 根据选择的索引获取对应的事实
    selected_facts = [Origin_Fact_Lists[idx.item()] for idx in selected_indices]
    
    # 将选择的事实组合成字符串
    Facts_String02 = '. '.join(selected_facts) + '.'
    Facts_String02 = Facts_String02.replace('..', '.')  # 避免出现连续的句点
    
    FA_conclusion01_string,reasoning_result = '',''
    while True:
        if while_count02>10:
            break
        # 推理之前基于相似性先进行前提选择

        FA_Conclusion_Reasoning_Context = ' The facts are: ' + Facts_String02 + ' \n '+' The rule is: ' + Reduction_Rule
        FA_conclusion_result = Iterative_Base_Model(Iterative_Conclusion_Reasoning_Prompt, FA_Conclusion_Reasoning_Context)
        while_count02 = while_count02 + 1

        # 检查返回结果是否为字符串类型，如果不是则重新生成
        if not isinstance(FA_conclusion_result, str):
            print("推理结果不是字符串类型，重新生成")
            continue
        FA_conclusion_result = FA_conclusion_result.replace('\n', '')

        # FA_conclusion_result = FA_conclusion_result[:50]
        # if FA_conclusion_result[:30].find('conclusion is') == -1:
        #     FA_conclusion_result = 'The conclusion is:' + FA_conclusion_result
        if 'None' in FA_conclusion_result or 'none' in FA_conclusion_result:
            reasoning_result = 'None'
            break
        if ':' in FA_conclusion_result and 'conclusion is' in FA_conclusion_result:
            FA_conclusion_result = FA_conclusion_result.replace('\n', '')
            FA_conclusion01 = re.findall(Reasoning_Output_Pattern, FA_conclusion_result)
            if len(FA_conclusion01)==0:
                FA_conclusion01_string = 'None'
                print("推理结果抽取错误！conclusion={}".format(FA_conclusion_result))
                continue
            else:
                FA_conclusion01_string = FA_conclusion01[0]
            
            
            if len(FA_conclusion01_string) < 10 or len(FA_conclusion01_string) > 80:
                reasoning_result = 'None'
                print("推理结果长度错误！conclusion={}".format(FA_conclusion_result))
                continue
            FA_conclusion02 = FA_conclusion01_string
            reasoning_result = FA_conclusion02.replace('"', '') + '. '
            # 计算产生的结论与原始规则之间的相似性，如果相似性过低，说明推理结果不可信，需要重新推理
            Conclusion_in_Reduction_Rule = Reduction_Rule.split(' then ')[-1] if ' then ' in Reduction_Rule else Reduction_Rule
            similarity_score = similarity([reasoning_result], [Conclusion_in_Reduction_Rule])
            similarity_score = similarity_score.item()
            if similarity_score < 0.6:
                print("推理结果相似性错误！similarity_score ={}, conclusion={}, rule={}".format(similarity_score, reasoning_result, Reduction_Rule))
                continue
            else:   
                break
        else:
            reasoning_result = 'None'
            print("推理生成结果格式错误reasoning_result={}".format(FA_conclusion_result))
            continue
    print('在{}事实集合下进行推理key={}, while_count02 = {}, conclusion_result={}, Conclusion_Reasoning_Context={}'.format(TA_FA_Flag, rule_number, while_count02, reasoning_result, FA_Conclusion_Reasoning_Context))

    return reasoning_result



# 定义一个调用大模型进行选择下一个事实的函数
def choose_fact_Based_LLMs(fact_list01, fact_list02, Origin_Question_Text_Lists):
    TA_fact_string01, FA_fact_string01 = '', ''
    for key in range(len(fact_list01)):
        fact01 = fact_list01[key] + '. '
        fact01 = fact01.replace('\'', '').replace('..', '. ').replace('. .', '. ')
        TA_fact_string01 = TA_fact_string01 + fact01
    for key in range(len(fact_list02)):
        fact02 = fact_list02[key] + '. '
        fact02 = fact02.replace('\'', '').replace('..', '. ').replace('. .', '. ')
        FA_fact_string01 = FA_fact_string01 + fact02
    Question_Text_String = ''
    for question_key in range(len(Origin_Question_Text_Lists)):
        question_text = Origin_Question_Text_Lists[question_key]
        neg_question_text = question_text.replace(' is not ',' is ') if ' not ' in question_text else question_text.replace(' is ', ' is not ')
        Question_Text_String = Question_Text_String + question_text
        Question_Text_String = Question_Text_String + neg_question_text

    # 调用大模型随机从FA事实列表中选择一个添加到TA中
    # 设置一定的启发式函数，尽量选择跟问题、问题的非相似性最大的事实
    # 即要求选择在事实集合2中却不在事实集合1中，并且跟问题、问题的非相似性最大的事实加入。
    choose_context = 'The facts set 1 are: ' + TA_fact_string01 + 'The facts set 2 are: ' + FA_fact_string01 + '\n'+ ' The question are: ' + Question_Text_String
    choose_fact_result_string = ''
    while True:
        choose_fact_result = Iterative_Base_Model(Choose_fact_Prompt, choose_context)
        if not isinstance(choose_fact_result, str):
            continue
        if len(choose_fact_result)<10:
            continue
        choose_fact_result = choose_fact_result.replace('\n', '')
        print('choose_fact_result={}, choose_context={}'.format(choose_fact_result, choose_context))
        # 如果不能选出事实

        if 'choosed fact is' not in choose_fact_result or ':' not in choose_fact_result:
            continue
        elif 'choosed fact is' in choose_fact_result and ':' in choose_fact_result:
            choose_fact_result = choose_fact_result.replace('\n', '')
            choose_fact_result = re.findall(Choose_Output_Pattern, choose_fact_result)
            choose_fact_string = choose_fact_result[0]
            if 'None' in choose_fact_string or 'none' in choose_fact_string:
                choose_fact_result_string = 'None'
                break
            if len(choose_fact_string) < 5:
                continue
            else:
                choose_fact_result_string = choose_fact_string
                break
    return choose_fact_result_string

# # 定义一个函数用于从事实集合二种选择一个不在事实集合1中的事实
def choose_fact_Based_Similarity(fact_list01, fact_list02, Origin_Question_Text_Lists):
    # 返回一个在集合2中但是不在集合1中的事实
    # 遍历集合2中事实与集合1中相似性最小那个事实
    fact_similarity = similarity(fact_list02, fact_list01)
    # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
    max_fact_similarity01 = torch.max(fact_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
    # 第一步根据相似度找出在事实集合2中但是不在事实集合1中的事实
    Remain_Fact_Lists = [] # 用于存储在事实集合2中但是不在事实集合1中的事实集合
    for key01 in range(len(fact_list02)):
        fact02 = fact_list02[key01]
        fact_similarity = max_fact_similarity01.values[key01]
        if fact_similarity < Similarity_Value:
            Remain_Fact_Lists.append(fact02)

    choose_fact = ''
    if len(Remain_Fact_Lists)>0:
        # 第二步 从剩余的事实中选择跟问题相似性最大那个事实
        # 获取问题和问题非的列表事实集合
        All_Question_Lists = []
        for question_Key in range(len(Origin_Question_Text_Lists)):
            All_Question_Lists.append(Origin_Question_Text_Lists[question_Key])
            question_neg = Origin_Question_Text_Lists[question_Key].replace('is not ',' is ') if ' not ' in Origin_Question_Text_Lists[question_Key] else Origin_Question_Text_Lists[question_Key].replace(' is ',' is not ')
            All_Question_Lists.append(question_neg)
        remain_fact_question_similarity = similarity(Remain_Fact_Lists, All_Question_Lists)
        # 计算出剩余事实中跟问题的最大匹配度
        max_fact_question_similarity01 = torch.max(remain_fact_question_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
        fact_question_similarity = 0
        for key in range(len(Remain_Fact_Lists)):
            if max_fact_question_similarity01.values[key] > fact_question_similarity:
                fact_question_similarity = max_fact_question_similarity01.values[key]
                choose_fact = Remain_Fact_Lists[key]
            else:
                continue
    else:
        choose_fact = 'None'

    return choose_fact


# 根据生成的回答集利用相似性进行打标签
def Skeptical_Credulous_Reasoning_based_Similarity(NL_Origin_Facts, NL_Origin_Question_Text):
    global Answer_Set_List, Soft_Answer_Set_List
    # 如果Answer_Set_List为空，但是soft_Answer_Set_List不为空， 则将Soft_Answer_Set_List赋值给Answer_Set_List
    Answer_Set_List = copy.deepcopy(Answer_Set_List) if len(Answer_Set_List)!=0 else copy.deepcopy(Soft_Answer_Set_List)
    print('NL_Origin_Question_Text:={}, Answer_Set_List ={}'.format(NL_Origin_Question_Text, Answer_Set_List))
    Explain_Set_Fact_Dict = {} # 用于存储预测问题标签的解释，关键字为问题的序号【1、2、3】，值为解释
    # 去除答案集中的事实，只保留回答集中的结论事实
    facts_list01 = NL_Origin_Facts.split('.')
    Fact_List = []
    for fact_Key01 in range(len(facts_list01)):
        if len(facts_list01[fact_Key01]) < 5:
            continue
        else:
            fact_string = facts_list01[fact_Key01] + '.'
            Fact_List.append(fact_string)

    Question_Label = ''
    neg_question_fact = ''
    Skeptical_LLMs_Generted_Label_List, Credulous_LLMs_Generted_Label_List= [], []

    for question_key in range(len(NL_Origin_Question_Text)):
        if question_key not in Explain_Set_Fact_Dict.keys():
            Explain_Set_Fact_Dict[question_key] = {}
        question_fact = NL_Origin_Question_Text[question_key]
        if 'not' in question_fact:
            neg_question_fact = question_fact.replace(' not ',' ')
        else:
            if ' is ' in question_fact:
                neg_question_fact = question_fact.replace(' is ', ' is not ')
        Answer_set_List02 = copy.deepcopy(Answer_Set_List)
        question_answer_label=[]
        negquestion_answer_label = []
        Skeptical_Explan_q_list =[]
        Skeptical_Explan_neg_q_list = []
        Skeptical_Explan_none_q_list = []
        Credulous_Explan_q_list = []
        Credulous_Explan_neg_q_list = []
        Credulous_Explan_none_q_list = []
        if Reasoning_Mode =='skeptical':
            for answer_key in range(len(Answer_Set_List)):
                # 获取去除事实集合中的结论事实
                Explain_fact_list = Remove_Fact(Fact_List, Answer_Set_List[answer_key])

                # 计算问题与回答集合中的事实的相似性
                question_answer_similarity = similarity([question_fact], Answer_Set_List[answer_key])
                # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
                max_question_answer_similarity01 = torch.max(question_answer_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
                # 计算问题否定与回答集合中的事实的相似性
                neg_question_answer_similarity = similarity([neg_question_fact], Answer_Set_List[answer_key])
                # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
                max_neg_question_answer_similarity01 = torch.max(neg_question_answer_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
                if max_question_answer_similarity01.values >= Similarity_Value and max_question_answer_similarity01.values > max_neg_question_answer_similarity01.values:
                    question_answer_label.append('True')
                    Skeptical_Explan_q_list.append(Explain_fact_list)
                else:
                    question_answer_label.append('False')
                if max_neg_question_answer_similarity01.values >= Similarity_Value and max_neg_question_answer_similarity01.values > max_question_answer_similarity01.values:
                    negquestion_answer_label.append('True')
                    Skeptical_Explan_neg_q_list.append(Explain_fact_list)
                else:
                    negquestion_answer_label.append('False')
                if max_question_answer_similarity01.values < Similarity_Value or max_neg_question_answer_similarity01.values < Similarity_Value:
                    Skeptical_Explan_none_q_list.append(Explain_fact_list)
            # 如果问题原子相似性匹配结果中不存在False,则说明都是True; 问题原子非的相似性匹配结果中不存在True, 则说明该问题可以在可怀疑推理模式下为True.
            if 'False' not in question_answer_label and 'True' not in negquestion_answer_label:
                Question_Label = 'T'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Skeptical_Explan_q_list
            elif 'True' not in question_answer_label and 'False' not in negquestion_answer_label:
                Question_Label = 'F'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Skeptical_Explan_neg_q_list
            elif 'False' in question_answer_label and 'False' in negquestion_answer_label:
                Question_Label = 'M'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Skeptical_Explan_none_q_list
            else:
                Question_Label = 'M'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Skeptical_Explan_none_q_list

        elif Reasoning_Mode == 'credulous':

            for answer_key in range(len(Answer_Set_List)):
                # 获取去除事实集合中的结论事实
                Explain_fact_list = Remove_Fact(Fact_List, Answer_Set_List[answer_key])
                # 计算问题与回答集合中的事实的相似性
                question_answer_similarity = similarity([question_fact], Answer_Set_List[answer_key])
                # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
                max_question_answer_similarity01 = torch.max(question_answer_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
                # 计算问题否定与回答集合中的事实的相似性
                neg_question_answer_similarity = similarity([neg_question_fact], Answer_Set_List[answer_key])
                # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
                max_neg_question_answer_similarity01 = torch.max(neg_question_answer_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
                if max_question_answer_similarity01.values >= Similarity_Value and max_question_answer_similarity01.values > max_neg_question_answer_similarity01.values:
                    question_answer_label.append('True')
                    Credulous_Explan_q_list.append(Explain_fact_list)
                else:
                    question_answer_label.append('False')
                if max_neg_question_answer_similarity01.values >= Similarity_Value and max_neg_question_answer_similarity01.values > max_question_answer_similarity01.values:
                    negquestion_answer_label.append('True')
                    Credulous_Explan_neg_q_list.append(Explain_fact_list)
                else:
                    negquestion_answer_label.append('False')
                if max_question_answer_similarity01.values < Similarity_Value and max_neg_question_answer_similarity01.values < Similarity_Value:
                    Credulous_Explan_none_q_list.append(Explain_fact_list)


            if 'True' in question_answer_label:
                Question_Label = 'T'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Credulous_Explan_q_list
            elif 'True' in negquestion_answer_label:
                Question_Label = 'F'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Credulous_Explan_neg_q_list
            elif 'True' not in question_answer_label and 'True' not in negquestion_answer_label:
                Question_Label = 'M'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Credulous_Explan_none_q_list
            else:
                Question_Label = 'M'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Credulous_Explan_none_q_list

        # 对生成的结果进行分析
        Skeptical_LLMs_Generted_Label_List.append([Question_Label])
        Credulous_LLMs_Generted_Label_List.append([Question_Label])

    return Skeptical_LLMs_Generted_Label_List, Credulous_LLMs_Generted_Label_List, Explain_Set_Fact_Dict

# 根据生成的回答集利用相似性进行打标签
def Skeptical_Credulous_Reasoning_based_Similarity(NL_Origin_Facts, NL_Origin_Question_Text):
    global Answer_Set_List, Soft_Answer_Set_List
    # 如果Answer_Set_List为空，但是soft_Answer_Set_List不为空， 则将Soft_Answer_Set_List赋值给Answer_Set_List
    Answer_Set_List = copy.deepcopy(Answer_Set_List) if len(Answer_Set_List)!=0 else copy.deepcopy(Soft_Answer_Set_List)
    print('NL_Origin_Question_Text:={}, Answer_Set_List ={}'.format(NL_Origin_Question_Text, Answer_Set_List))
    Explain_Set_Fact_Dict = {} # 用于存储预测问题标签的解释，关键字为问题的序号【1、2、3】，值为解释
    # 去除答案集中的事实，只保留回答集中的结论事实
    facts_list01 = NL_Origin_Facts.split('.')
    Fact_List = []
    for fact_Key01 in range(len(facts_list01)):
        if len(facts_list01[fact_Key01]) < 5:
            continue
        else:
            fact_string = facts_list01[fact_Key01] + '.'
            Fact_List.append(fact_string)

    Question_Label = ''
    neg_question_fact = ''
    Skeptical_LLMs_Generted_Label_List, Credulous_LLMs_Generted_Label_List= [], []

    for question_key in range(len(NL_Origin_Question_Text)):
        if question_key not in Explain_Set_Fact_Dict.keys():
            Explain_Set_Fact_Dict[question_key] = {}
        question_fact = NL_Origin_Question_Text[question_key]
        if 'not' in question_fact:
            neg_question_fact = question_fact.replace(' not ',' ')
        else:
            if ' is ' in question_fact:
                neg_question_fact = question_fact.replace(' is ', ' is not ')
        Answer_set_List02 = copy.deepcopy(Answer_Set_List)
        question_answer_label=[]
        negquestion_answer_label = []
        Skeptical_Explan_q_list =[]
        Skeptical_Explan_neg_q_list = []
        Skeptical_Explan_none_q_list = []
        Credulous_Explan_q_list = []
        Credulous_Explan_neg_q_list = []
        Credulous_Explan_none_q_list = []
        if Reasoning_Mode =='skeptical':
            for answer_key in range(len(Answer_Set_List)):
                # 获取去除事实集合中的结论事实
                Explain_fact_list = Remove_Fact(Fact_List, Answer_Set_List[answer_key])

                # 计算问题与回答集合中的事实的相似性
                question_answer_similarity = similarity([question_fact], Answer_Set_List[answer_key])
                # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
                max_question_answer_similarity01 = torch.max(question_answer_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
                # 计算问题否定与回答集合中的事实的相似性
                neg_question_answer_similarity = similarity([neg_question_fact], Answer_Set_List[answer_key])
                # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
                max_neg_question_answer_similarity01 = torch.max(neg_question_answer_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
                if max_question_answer_similarity01.values >= Similarity_Value and max_question_answer_similarity01.values > max_neg_question_answer_similarity01.values:
                    question_answer_label.append('True')
                    Skeptical_Explan_q_list.append(Explain_fact_list)
                else:
                    question_answer_label.append('False')
                if max_neg_question_answer_similarity01.values >= Similarity_Value and max_neg_question_answer_similarity01.values > max_question_answer_similarity01.values:
                    negquestion_answer_label.append('True')
                    Skeptical_Explan_neg_q_list.append(Explain_fact_list)
                else:
                    negquestion_answer_label.append('False')
                if max_question_answer_similarity01.values < Similarity_Value or max_neg_question_answer_similarity01.values < Similarity_Value:
                    Skeptical_Explan_none_q_list.append(Explain_fact_list)
            # 如果问题原子相似性匹配结果中不存在False,则说明都是True; 问题原子非的相似性匹配结果中不存在True, 则说明该问题可以在可怀疑推理模式下为True.
            if 'False' not in question_answer_label and 'True' not in negquestion_answer_label:
                Question_Label = 'T'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Skeptical_Explan_q_list
            elif 'True' not in question_answer_label and 'False' not in negquestion_answer_label:
                Question_Label = 'F'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Skeptical_Explan_neg_q_list
            elif 'False' in question_answer_label and 'False' in negquestion_answer_label:
                Question_Label = 'M'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Skeptical_Explan_none_q_list
            else:
                Question_Label = 'M'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Skeptical_Explan_none_q_list

        elif Reasoning_Mode == 'credulous':

            for answer_key in range(len(Answer_Set_List)):
                # 获取去除事实集合中的结论事实
                Explain_fact_list = Remove_Fact(Fact_List, Answer_Set_List[answer_key])
                # 计算问题与回答集合中的事实的相似性
                question_answer_similarity = similarity([question_fact], Answer_Set_List[answer_key])
                # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
                max_question_answer_similarity01 = torch.max(question_answer_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
                # 计算问题否定与回答集合中的事实的相似性
                neg_question_answer_similarity = similarity([neg_question_fact], Answer_Set_List[answer_key])
                # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
                max_neg_question_answer_similarity01 = torch.max(neg_question_answer_similarity, dim=1)  # 求相似矩阵中的每一行的最大值
                if max_question_answer_similarity01.values >= Similarity_Value and max_question_answer_similarity01.values > max_neg_question_answer_similarity01.values:
                    question_answer_label.append('True')
                    Credulous_Explan_q_list.append(Explain_fact_list)
                else:
                    question_answer_label.append('False')
                if max_neg_question_answer_similarity01.values >= Similarity_Value and max_neg_question_answer_similarity01.values > max_question_answer_similarity01.values:
                    negquestion_answer_label.append('True')
                    Credulous_Explan_neg_q_list.append(Explain_fact_list)
                else:
                    negquestion_answer_label.append('False')
                if max_question_answer_similarity01.values < Similarity_Value and max_neg_question_answer_similarity01.values < Similarity_Value:
                    Credulous_Explan_none_q_list.append(Explain_fact_list)


            if 'True' in question_answer_label:
                Question_Label = 'T'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Credulous_Explan_q_list
            elif 'True' in negquestion_answer_label:
                Question_Label = 'F'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Credulous_Explan_neg_q_list
            elif 'True' not in question_answer_label and 'True' not in negquestion_answer_label:
                Question_Label = 'M'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Credulous_Explan_none_q_list
            else:
                Question_Label = 'M'
                if Question_Label not in Explain_Set_Fact_Dict[question_key].keys():
                    Explain_Set_Fact_Dict[question_key][Question_Label] = Credulous_Explan_none_q_list

        # 对生成的结果进行分析
        Skeptical_LLMs_Generted_Label_List.append([Question_Label])
        Credulous_LLMs_Generted_Label_List.append([Question_Label])

    return Skeptical_LLMs_Generted_Label_List, Credulous_LLMs_Generted_Label_List, Explain_Set_Fact_Dict

# 定义一个函数，用于基于大模型对问题在生成的回答集上进行打标签
Label_Reasoning_Prompt = 'Dask Description: \n Given a extension and question, and the extension consists of facts. you need to answer the questions according to the given extension. \n If the question can be inferred based on the given extension, the answer label of the question is "True"; \n If the negation of the question can be inferred based on the extension, the answer label of the question is "False"; \n If the question and the negation of the question both cannot be deduced according to the extension, the answer label of the question is "Unknown".  \n The input format is: The extension are:''. \n The question is:".  \n The output format is: The answer is:".###  \n For example:  The extension are: "Magnus and Malcolm is spurn. Magnus is difficult. Magnus is arrogant. Magnus is nasty. Magnus is dramatic. Magnus is dangerous. Magnus is important. Magnus is vast. Magnus is handsome.".  \n The question is: "Magnus is happiness.". \n The answer is: "Unknown"###. \n The question is: "Magnus is important". \n The answer is: "True"###. \n The question is: "Magnus is not dramatic. ". \n The answer is: "False"###. \n Note that you only need to generate the answer label for the question. Don\'t output your reasoning or thinking process. Please read all extensions carefully and answer the question.'

def Skeptical_Credulous_Reasoning_based_LLMs(NL_Origin_Facts, NL_Origin_Question_Text):

    # 可能存在多个回答集，将每个回答集转换成字符串的形式。
    # 如果Answer_Set_List为空，但是soft_Answer_Set_List不为空， 则将Soft_Answer_Set_List赋值给Answer_Set_List
    global Answer_Set_List, Soft_Answer_Set_List
    Answer_Set_List = copy.deepcopy(Answer_Set_List) if len(Answer_Set_List)!=0 else copy.deepcopy(Soft_Answer_Set_List) 
    # 去除答案集中的事实，只保留回答集中的结论事实    

    # 将回答集列表转换成字符串
    Answer_Set_String_List = []
    for key01 in range(len(Answer_Set_List)):
        # 去除回答集中的事实
        # answer_set = Remove_Fact(Fact_List, Answer_Set_List[key01])
        answer_set = Answer_Set_List[key01]
        answer_set_string = ''
        for key02 in range(len(answer_set)):
            answer_set_string = answer_set_string + answer_set[key02]
        Answer_Set_String_List.append(answer_set_string)

    # 遍历Answer_Set_String_List，构建提示内容
    answer_set_string_prompt = ''
    # for key03 in range(len(Answer_Set_String_List)):
    #     answer_set_string_prompt = answer_set_string_prompt + 'The extension ' + str(int(key03)+1) + ' are: ' + Answer_Set_String_List[key03]
    Reasoning_Instruction= Label_Reasoning_Prompt


    Question_Text_String = ''
    skeptical_question_answer_result = ''
    Skeptical_LLMs_Generted_Label_List, Credulous_LLMs_Generted_Label_List= [], []
    for question_key in range(len(NL_Origin_Question_Text)):
        neg_question_fact = ''
        question_fact = NL_Origin_Question_Text[question_key]
        if 'not' in question_fact:
            neg_question_fact = question_fact.replace(' not ', ' ')
        else:
            if ' is ' in question_fact:
                neg_question_fact = question_fact.replace(' is ', ' is not ')
            elif ' has ' in question_fact:
                neg_question_fact = question_fact.replace(' has ', ' has not ')
            elif ' might ' in question_fact:
                neg_question_fact = question_fact.replace(' might ', ' might not ')
            elif ' may ' in question_fact:
                neg_question_fact = question_fact.replace(' may ', ' may not ')
            elif ' lacks ' in question_fact:
                neg_question_fact = question_fact.replace(' lacks ', ' does not lacks ')
            elif ' does lack ' in question_fact:
                neg_question_fact = question_fact.replace(' does lack ', ' does not lacks ')
            elif ' feels ' in question_fact:
                neg_question_fact = question_fact.replace(' feels ', ' does not feels ')
            elif ' maintains ' in question_fact:
                neg_question_fact = question_fact.replace(' maintains ', ' does not maintains ')
            elif ' exhibits ' in question_fact:
                neg_question_fact = question_fact.replace(' exhibits ', ' does not exhibits ')
            elif ' refrains ' in question_fact:
                neg_question_fact = question_fact.replace(' refrains ', ' does not refrains ')
            elif ' experiences ' in question_fact:
                neg_question_fact = question_fact.replace(' experiences ', ' does not experiences ')
            elif ' appears ' in question_fact:
                neg_question_fact = question_fact.replace(' appears ', ' does not appears ')
            elif ' possesses ' in question_fact:
                neg_question_fact = question_fact.replace(' possesses ', ' does not possesses ')
            elif ' tends ' in question_fact:
                neg_question_fact = question_fact.replace(' tends ', ' does not tends ')
            elif ' represents ' in question_fact:
                neg_question_fact = question_fact.replace(' represents ', ' does not represents ')
            else:
                question_fact = question_fact.strip()
                question_fact = question_fact + '.'
                question_fact_parts = question_fact.split(' ', 1)
                neg_question_fact = question_fact_parts[0] + ' does not ' + question_fact_parts[1]

        question_text = ' The question is: ' + NL_Origin_Question_Text[question_key]
        neg_question_text = ' The question is: ' + neg_question_fact
        # 调用大模型预测
        question_answer_result = ''
        question_answer_result_on_Extension_list = [] # 用于存储在所有扩展下大模型推理问题产生的结果
        neg_question_answer_result_on_Extension_list = [] # 用于存储在所有扩展下大模型推理问题否定产生的结果
        # 便历每一个回答集，
        for answer_key in range(len(Answer_Set_String_List)):
            answer_set_string_prompt = 'The extensions are: ' + Answer_Set_String_List[answer_key] + '\n'+  question_text

            # 基于大模型判断扩展是否包含问题事实
            while_count03 = 0
            while True:
                if while_count03 > 10:
                    skeptical_question_answer_result = 'Unknown'
                    break
                while_count03 = while_count03 + 1
                origin_skeptical_question_answer_result = Iterative_Base_Model(Reasoning_Instruction, answer_set_string_prompt)
                if 'unknown' not in origin_skeptical_question_answer_result and 'Unknown' not in origin_skeptical_question_answer_result and 'true' not in origin_skeptical_question_answer_result and 'True' not in origin_skeptical_question_answer_result and 'false' not in origin_skeptical_question_answer_result and 'False' not in origin_skeptical_question_answer_result:
                    print("推理结果内容错误 skeptical_question_answer_result={}".format(origin_skeptical_question_answer_result))
                    while_count03 = while_count03 + 1
                    continue
                if len(origin_skeptical_question_answer_result) < 4:
                    print("推理结果内容错误 skeptical_question_answer_result={}".format(origin_skeptical_question_answer_result))
                    while_count03 = while_count03 + 1
                    continue
                while_count03 = while_count03 + 1
                
                if '#' not in origin_skeptical_question_answer_result:
                    origin_skeptical_question_answer_result = origin_skeptical_question_answer_result + '###'
                if 'answer is:' in origin_skeptical_question_answer_result:
                    skeptical_question_answer_result = re.findall(Extracted_LLM_Answer_Pattern, origin_skeptical_question_answer_result)
                    if len(skeptical_question_answer_result) == 0:
                        print("推理结果为空 skeptical_question_answer_result={}".format(skeptical_question_answer_result))
                        continue
                    else:
                        skeptical_question_answer_result = skeptical_question_answer_result[0]
                        break
                else:
                    print("推理结果不符合格式 skeptical_question_answer_result={}".format(origin_skeptical_question_answer_result))
                    continue
            predict_label_on_Extension, neg_predicate_label_on_Extension = None, None
            if 'true' in skeptical_question_answer_result or 'True' in skeptical_question_answer_result:
                predict_label_on_Extension = 'true'
            elif 'false' in skeptical_question_answer_result or 'False' in skeptical_question_answer_result:
                predict_label_on_Extension = 'false'
            elif 'unknown' in skeptical_question_answer_result or 'Unknown' in skeptical_question_answer_result:
                predict_label_on_Extension = 'unknown'
            else:
                predict_label_on_Extension = 'unknown'
            question_answer_result_on_Extension_list.append(predict_label_on_Extension)

            # 基于大模型判断扩展是否包含问题事实
            answer_set_string_prompt02 = 'The extensions are: ' + Answer_Set_String_List[answer_key] + '\n'+  neg_question_text

            while_count03 = 0
            while True:
                if while_count03 > 10:
                    skeptical_question_answer_result = 'Unknown'
                    break
                while_count03 = while_count03 + 1
                origin_skeptical_question_answer_result = Iterative_Base_Model(Reasoning_Instruction, answer_set_string_prompt02)
                if 'unknown' not in origin_skeptical_question_answer_result and 'Unknown' not in origin_skeptical_question_answer_result and 'true' not in origin_skeptical_question_answer_result and 'True' not in origin_skeptical_question_answer_result and 'false' not in origin_skeptical_question_answer_result and 'False' not in origin_skeptical_question_answer_result:
                    print("推理结果内容错误 skeptical_question_answer_result={}".format(
                        origin_skeptical_question_answer_result))
                    while_count03 = while_count03 + 1
                    continue
                if len(origin_skeptical_question_answer_result) < 4:
                    print("推理结果内容错误 skeptical_question_answer_result={}".format(
                        origin_skeptical_question_answer_result))
                    while_count03 = while_count03 + 1
                    continue
                while_count03 = while_count03 + 1

                if '#' not in origin_skeptical_question_answer_result:
                    origin_skeptical_question_answer_result = origin_skeptical_question_answer_result + '###'
                if 'answer is:' in origin_skeptical_question_answer_result:
                    skeptical_question_answer_result = re.findall(Extracted_LLM_Answer_Pattern,
                                                                  origin_skeptical_question_answer_result)
                    if len(skeptical_question_answer_result) == 0:
                        print(
                            "推理结果为空 skeptical_question_answer_result={}".format(skeptical_question_answer_result))
                        continue
                    else:
                        skeptical_question_answer_result = skeptical_question_answer_result[0]
                        break
                else:
                    print("推理结果不符合格式 skeptical_question_answer_result={}".format(
                        origin_skeptical_question_answer_result))
                    continue
            predict_label_on_Extension, neg_predicate_label_on_Extension = None, None
            if 'true' in skeptical_question_answer_result or 'True' in skeptical_question_answer_result:
                predict_label_on_Extension = 'true'
            elif 'false' in skeptical_question_answer_result or 'False' in skeptical_question_answer_result:
                predict_label_on_Extension = 'false'
            elif 'unknown' in skeptical_question_answer_result or 'Unknown' in skeptical_question_answer_result:
                predict_label_on_Extension = 'unknown'
            else:
                predict_label_on_Extension = 'unknown'
            neg_question_answer_result_on_Extension_list.append(predict_label_on_Extension)

        credulous_predict_label, skeptical_predict_label = None, None
        # credulous推理模式
        if 'true' in question_answer_result_on_Extension_list:
            credulous_predict_label = 'T'
        elif 'true' in neg_question_answer_result_on_Extension_list:
            credulous_predict_label = 'F'
        else:
            credulous_predict_label = 'M'

        # skeptical推理模式
        if 'false' not in question_answer_result_on_Extension_list and 'unknown' not in question_answer_result_on_Extension_list and 'true' not in neg_question_answer_result_on_Extension_list:
            skeptical_predict_label = 'T'
        elif 'true' not in question_answer_result_on_Extension_list and 'false' not in neg_question_answer_result_on_Extension_list and 'unknown' not in neg_question_answer_result_on_Extension_list:
            skeptical_predict_label = 'F'
        else:
            skeptical_predict_label = 'M'

        # true_count_in_skeptical_list = question_answer_result_on_Extension_list.count('true') + question_answer_result_on_Extension_list.count('True')
        # false_count_in_skeptical_list = question_answer_result_on_Extension_list.count('false') + question_answer_result_on_Extension_list.count('False')
        # if true_count_in_skeptical_list > len(question_answer_result_on_Extension_list) / 2:  # 如果超过一半的扩展都支持该问题为真
        #     skeptical_predict_label = 'T'  # 则skeptical预测标签为真
        # elif false_count_in_skeptical_list > len(question_answer_result_on_Extension_list) / 2:  # 如果超过一半的扩展都支持该问题为假
        #     skeptical_predict_label = 'F'
        # else:
        #     skeptical_predict_label = 'M'

        print('question_text:{}, question_answer_result_on_Extension_list:{}, neg_question_answer_result_on_Extension_list:{}, skeptical_predict_label:{},credulous_predict_label:{}'.format(question_text, question_answer_result_on_Extension_list,neg_question_answer_result_on_Extension_list, skeptical_predict_label,credulous_predict_label))

        # 对生成的结果进行分析
        Skeptical_LLMs_Generted_Label_List.append([skeptical_predict_label])
        Credulous_LLMs_Generted_Label_List.append([credulous_predict_label])

    return Skeptical_LLMs_Generted_Label_List, Credulous_LLMs_Generted_Label_List, Answer_Set_String_List



# 用于存储未探索的事实，下界和上界, 主要是用于存储当选择的事实更新上界之后，需要基于更新后的上界重新搜索扩展。
UnExpore_Fact_List, UnExpore_TA_List, UnExpore_FA_List = [],[],[]


# 定义扩展函数expand
def Expand_p(Fact_List01, TA_List, FA_List, Rule_List01):

    TA_List01, FA_List01 = copy.deepcopy(TA_List), copy.deepcopy(FA_List)

    global Prerequisite_Conclusion_Consistent_Facts_Dict
    while_count01 = 0
    Facts_TA_conclusion_list = []
    # 由于是逐步进行推理，如果在某个规则在下界能得出结论，则对于后续能推理出结论的规则不能违反前面推出结论规则的一致性条件。即后续规则推出的结论不能是之前推出结论规则中的一致性事实。
    TA_conclusion2consistency_List, FA_conclusion2consistency_List  = [],[]

    while True:
        # TA_List01-》L; FA_List01-》U; TA_List02-》L'; FA_List02-》U'
        TA_List02 , FA_List02 = copy.deepcopy(TA_List01), copy.deepcopy(FA_List01)
        # 遍历所有规则，通过正结论推理神经网络模块Cn(P^{FA})和负结论神经网络推理模块
        # 调用大模型来判断是根据下界事实集合是否能够将规则中的结论加入回答集下界集合中，、
        # 调用大模型去实现Cn(P^{FA})，即正结论推理神经网络模块，如果在FA_List事实列表下能推出结论，则将该结论事实加入TA中， L<- L' U Cn(P^{FA})
        # 调用大模型去实现Cn(P^{TA}),即负结论推理神经网络模块， U <- U' /\ Cn(P^TA)
        # 将事实列表转换成事实字符串


        TA_conclusion_list, FA_conclusion_list = [], [] # U原子上程序的结论集合
        TA_conclusion, FA_conclusion = 'None', 'None' # U原子上程序的结论集合
        rule_string = ''
        for rule_key in range(len(Rule_List01)): # 获取所有的规则字符串
            rule_string = rule_string + Rule_List01[rule_key] + '. '
        # 推理步骤进一步分为二步，第一步进行约间，第二步进行
        # 调用大模型分别实现在TA和FA事实下对程序规则进行约减
        # TA_Reduction_Rule_List存储的是在TA原子约减产生的规则集合。 FA_Reduction_Rule_List存储的是在FA原子约减后产生的规则集合
        # TA_Reduction_Rule_List->P^L'; FA_Reduction_Rule_List->P^U'
        TA_Reduction_Rule_List, FA_Reduction_Rule_List = [],[] #用于存储约减之后的规则列表
        Rule_String = ''
        for rule_key in range(len(Rule_List01)):
            rule_number = int(rule_key)
            Rule_String = Rule_List01[rule_key] + '. '
            while_count = 1
            reduction_rule = 'The rule is: ' + Rule_String
            # 基于相似性计算下界和上界下的约简,Rule_consistencys_list表示该规则的一致性条件
            TA_conclusion02, FA_conclusion02, Rule_consistencys_list = Iterative_Split_Reduction_Prompt_Based_Similarity(TA_List02, FA_List02, TA_conclusion, FA_conclusion, reduction_rule, rule_number)

            if 'None' not in TA_conclusion02 and len(TA_conclusion02)>10:
                TA_conclusion_list.append(TA_conclusion02)
                TA_conclusion = TA_conclusion02

            if 'None' not in FA_conclusion02 and len(FA_conclusion02)>10:
                FA_conclusion_list.append(FA_conclusion02)
                FA_conclusion = FA_conclusion02
                # FA_List02 = fact_union(FA_List02, [FA_conclusion02]) if len(FA_List02) != 0 else FA_List02

        print('一轮迭代产生的结论事实集合：TA_conclusion_list={}, FA_conclusion_list={}'.format(TA_conclusion_list, FA_conclusion_list))
        # FA_conclusion_list表示的是P^U', 需要将所有事实加入P^U'中，U' =FA_List02 然后再做处理。
        #  TA_List01-> L; TA_List02->L'; FA_conclusion_list->P^U'  L = L' U P^U'
        TA_List01 = fact_union(TA_List02, FA_conclusion_list) if len(FA_conclusion_list)!=0 else TA_List02
        # TA_List01 = Remove_Same_Fact(TA_List01)
        print('L\' U P^U\'|L={}, len(TA_List02|L\')={}, len(FA_conclusion_list|P^U\')= {}'.format(len(TA_List01), len(TA_List02), len(FA_conclusion_list)))
        # TA_conclusion_list表示的是P^L', 需要将所有事实加入P^L‘中，L‘ = TA_List02然后再做处理。
        # TA_conclusion_list= fact_union(TA_conclusion_list, Fact_List01) # TA_conclusion_list表示的是P^L', 需要将所有事实加入P^L‘中，然后再做处理。, 这里先交，在将事实添加进去。
        # 调用求交函数进行交操作
        if while_count01 == 0:
            # 第一步计算Cn(P^{L′} )
            Facts_TA_conclusion_list = fact_union(TA_List02, TA_conclusion_list) if len(TA_conclusion_list)!=0 else TA_List02 # Fact_List01 # 将下界集合产生的结论事实与原始事实合并
            # 第二步计算U = U ′ ∩ Cn(P L′ ); FA_List02->U';Facts_TA_conclusion_list->Cn(P^L')
            FA_List01 = fact_intersection(FA_List02, Facts_TA_conclusion_list) # 在于上界事实集合求交
        else:
            # 第二次重新迭代计算L和U时的更新策略
            # Cn(P^L') = L'+P^L'
            Facts_TA_conclusion_list = fact_union(Facts_TA_conclusion_list, TA_conclusion_list) if len(TA_conclusion_list)!=0 else Facts_TA_conclusion_list# 将下界集合产生的结论事实与原始事实合并
            # 因为上界推出的结论需要加入到下界事实列表中，所以需要将上界推理的结果添加到上界事实列表中
            Facts_TA_conclusion_list = fact_union(Facts_TA_conclusion_list, FA_conclusion_list) if len(FA_conclusion_list)!=0 else Facts_TA_conclusion_list # 将下界集合产生的结论事实与原始事实合并

            # 首先需要对FA_List02进行更新，需要将当前轮迭代产生的FA_conclusion_list加入到FA_List02中，否则会出现下界中不包含在上界中的事实
            FA_List02 = fact_union(FA_List02, FA_conclusion_list) if len(FA_conclusion_list)!=0 else FA_List02
            #if Reasoning_Mode == 'credulous':
            FA_List02 = fact_union(FA_List02, TA_conclusion_list) if len(TA_conclusion_list)!=0 else FA_List02
            # 第二步计算U = U ′ ∩ Cn(P L′ )
            FA_List01 = fact_intersection(FA_List02, Facts_TA_conclusion_list) # 在于上界事实集合求交

        print('FA 交 P^L={}, len(FA_List02)={}, len(TA_conclusion_list)= {}'.format(len(FA_List01), len(FA_List02), len(TA_conclusion_list)))

        # 判断L跟L‘是否相等
        equal_result01 = equation(TA_List01, TA_List02)
        print("equal_result01={}, TA_List01={}, TA_List02={}".format(equal_result01, TA_List01, TA_List02))
        # 判断U跟U‘是否相等
        # equal_result02 = equation(FA_List01, FA_List02) # 判断L与U是否等价
        # print('equal_result02={}, FA_List01={},FA_List02 ={} '.format(equal_result02,FA_List01, FA_List02))
        # 应该是循环结束后，当L和U稳定之后再判断L是否是U的子集
        subset_result03, different_fact_number = Include(TA_List01, FA_List01) # 判断L是否是U的子集
        print("subset_result03={}, len(TA_List01)={}, len(FA_List01)={}".format(subset_result03, len(TA_List01), len(FA_List01)))

        if while_count01 >= 1:
            if "False" in subset_result03 or 'false' in subset_result03 : # L不属于U
                print('len(TA_List01)={}, len(FA_List01)={}'.format(len(TA_List01), len(FA_List01)))
                print('Expand_p函数中下界L不属于U, 退出下界和上界迭代循环！')
                break
        if "True" in equal_result01 and while_count01!=0:# and "True" in equal_result02: # 如果上界和下界都没有发生变化，则推出循环 ( L/TA_List01= L'/TA_List02  and U/FA_List01= U'/FA_List02)
            print('下界和上界稳定， 退出下界和上界迭代循环。 回答集迭代扩展完成，Expand Successfully!')
            break
        if len(FA_List01) <= len(TA_List01): 
            print('上界事实集合小于等于下界')
            break

        while_count01 = while_count01 + 1
        if while_count01 >= 6:
            print('下界和上界迭代次数超过4次，退出循环！')
            break

    return TA_List01, FA_List01, subset_result03, different_fact_number


# 调用Solve_P函数求解所有回答集
def Slove_P(Fact_List, TA_List, FA_List, Rule_List01,slove_iternumber, NL_Origin_Question_Text):
    global Answer_Set_List, Soft_Answer_Set_List, Each_Example_chatgpt_Number
    subset_result01, different_fact_number01 = Include(TA_List, FA_List)  # 判断L是否是U的子集

    print('当前回答集数量len(Answer_Set_List)={}, len(Soft_Answer_Set_List)={}'.format(len(Answer_Set_List), len(Soft_Answer_Set_List)))
    # 如果下界大于上界，且相差小于2，则直接返回下界作为回答集
    if len(TA_List) > len(FA_List) and len(TA_List)-len(FA_List)<=1: # 如果下界和上界相差小于2，则直接返回下界作为回答集
        Soft_Answer_Set_List.append(FA_List)
        print("下界TA_List={}高于上界FA_List={}，将回答集加入Soft_Answer_Set_List中，不需要进一步推理。".format(len(TA_List), len(FA_List)))
        print('当前回答集数量len(Answer_Set_List)={}, len(Soft_Answer_Set_List)={}'.format(len(Answer_Set_List),len(Soft_Answer_Set_List)))

        # 如果未探索的事实列表不为空，则对未探索的第一个事实、上界、下界进行探索。
        if len(UnExpore_Fact_List) > 0 and len(UnExpore_TA_List) > 0 and len(UnExpore_FA_List) > 0 and len(Answer_Set_List) < Max_Answer_Set_Number:
            # 对未探索的第一个事实、上界、下界进行探索。
            Fact_List01 = copy.deepcopy(UnExpore_Fact_List[0])
            TA_List02 = copy.deepcopy(UnExpore_TA_List[0])
            FA_List01 = copy.deepcopy(UnExpore_FA_List[0])
            slove_iternumber01 = 0
            # 删除未探索的事实列表中的第一个事实
            UnExpore_Fact_List.pop(0)
            UnExpore_TA_List.pop(0)
            UnExpore_FA_List.pop(0)
            print('未探索的事实列表不为空，对未探索的第一个事实、上界、下界进行探索。')
            Slove_P(Fact_List01, TA_List02, FA_List01, Rule_List01, slove_iternumber01, NL_Origin_Question_Text)

            
    elif len(Answer_Set_List) + len(Soft_Answer_Set_List) >= Max_Answer_Set_Number:
        print('回答集数量超过20个，跳出循环！')
    elif "True" not in subset_result01: # 下界不包含在上界中
        print('下界不包含在上界中，跳出循环！')
        # 如果未探索的事实列表不为空，则对未探索的第一个事实、上界、下界进行探索。
        if len(UnExpore_Fact_List) > 0 and len(UnExpore_TA_List) > 0 and len(UnExpore_FA_List) > 0 and len(Answer_Set_List) < Max_Answer_Set_Number:
            # 对未探索的第一个事实、上界、下界进行探索。
            Fact_List01 = copy.deepcopy(UnExpore_Fact_List[0])
            TA_List02 = copy.deepcopy(UnExpore_TA_List[0])
            FA_List01 = copy.deepcopy(UnExpore_FA_List[0])
            slove_iternumber01 = 0
            # 删除未探索的事实列表中的第一个事实
            UnExpore_Fact_List.pop(0)
            UnExpore_TA_List.pop(0)
            UnExpore_FA_List.pop(0)
            print('未探索的事实列表不为空，对未探索的第一个事实、上界、下界进行探索。')
            Slove_P(Fact_List01, TA_List02, FA_List01, Rule_List01, slove_iternumber01, NL_Origin_Question_Text)

    else:
        Fact_List01 = copy.deepcopy(Fact_List)
        TA_List01, FA_List01, Include_subset_flag, different_fact_number = Expand_p(Fact_List01, TA_List, FA_List, Rule_List01)
        slove_iternumber = slove_iternumber + 1
        print('slove_iternumber={}'.format(slove_iternumber))

        subset_result01 = Include_subset_flag # Include(TA_List01, FA_List01)
        equal_result01 = equation(TA_List01, FA_List01) # 判断L与U是否等价
        # 如果L与U等价，且L属于U，则将L作为回答集
        if "True" in equal_result01 and 'True' in subset_result01:  # 如果说明找到了一个回答集
            Answer_Set_List.append(TA_List01)
            print('搜索成功，找到了一个回答集TA_List01 = {}, len(Answer_Set_List)={}, Answer_Set_List={}'.format(TA_List01, len(Answer_Set_List), Answer_Set_List))
            print('当前回答集数量len(Answer_Set_List)={}, len(Soft_Answer_Set_List)={}'.format(len(Answer_Set_List),len(Soft_Answer_Set_List)))

            # 如果未探索的事实列表不为空，则对未探索的第一个事实、上界、下界进行探索。
            if len(UnExpore_Fact_List) > 0 and len(UnExpore_TA_List) > 0 and len(UnExpore_FA_List) > 0 and len(Answer_Set_List) < Max_Answer_Set_Number:
                # 对未探索的第一个事实、上界、下界进行探索。
                print('未探索的事实列表不为空，对未探索的第一个事实、上界、下界进行探索。')

                Fact_List01 = copy.deepcopy(UnExpore_Fact_List[0])
                TA_List02 = copy.deepcopy(UnExpore_TA_List[0])
                FA_List01 = copy.deepcopy(UnExpore_FA_List[0])
                slove_iternumber01 = 0
                # 删除未探索的事实列表中的第一个事实
                UnExpore_Fact_List.pop(0)
                UnExpore_TA_List.pop(0)
                UnExpore_FA_List.pop(0)
                Slove_P(Fact_List01, TA_List02, FA_List01, Rule_List01, slove_iternumber01, NL_Origin_Question_Text)

        elif len(TA_List01) > len(FA_List01) and len(TA_List01)-len(FA_List01)<=1:  # 如果下界大于等于上界，相差小于2，则直接返回上界作为回答集
            Soft_Answer_Set_List.append(FA_List01)
            print("下界TA_List={}高于上界FA_List={}，将上界作为回答集加入Soft_Answer_Set_List中，不需要进一步推理。".format(len(TA_List01), len(FA_List01)))
            print('当前回答集数量len(Answer_Set_List)={}, len(Soft_Answer_Set_List)={}'.format(len(Answer_Set_List), len(Soft_Answer_Set_List)))

            # 如果未探索的事实列表不为空，则对未探索的第一个事实、上界、下界进行探索。
            if len(UnExpore_Fact_List) > 0 and len(UnExpore_TA_List) > 0 and len(UnExpore_FA_List) > 0 and len(Answer_Set_List) < Max_Answer_Set_Number:
                # 对未探索的第一个事实、上界、下界进行探索。
                print('未探索的事实列表不为空，对未探索的第一个事实、上界、下界进行探索。')

                Fact_List01 = copy.deepcopy(UnExpore_Fact_List[0])
                TA_List02 = copy.deepcopy(UnExpore_TA_List[0])
                FA_List01 = copy.deepcopy(UnExpore_FA_List[0])
                slove_iternumber01 = 0
                # 删除未探索的事实列表中的第一个事实
                UnExpore_Fact_List.pop(0)
                UnExpore_TA_List.pop(0)
                UnExpore_FA_List.pop(0)
                Slove_P(Fact_List01, TA_List02, FA_List01, Rule_List01, slove_iternumber01, NL_Origin_Question_Text)

        elif "False" in subset_result01:  # L不属于U 说明搜搜失败，返回目前的回答集
            # 考虑下界比上届小的情况，并且下界没有包含在上届中。
            if len(Answer_Set_List)==0 and len(Soft_Answer_Set_List)==0 and different_fact_number <=1 and len(FA_List01)-len(TA_List01)<=1:
                Soft_Answer_Set_List.append(TA_List01)
                print("L不属于U,搜索失败len(TA_List01)={},len(FA_List01)={}".format(len(TA_List01),len(FA_List01)))
                print('当前回答集数量len(Answer_Set_List)={}, len(Soft_Answer_Set_List)={}'.format(len(Answer_Set_List),len(Soft_Answer_Set_List)))
            else:
                print("L不属于U,搜索失败len(TA_List01)={},len(FA_List01)={}".format(len(TA_List01),len(FA_List01)))
                # 如果未探索的事实列表不为空，则对未探索的第一个事实、上界、下界进行探索。
            # 查看是否还有为探索的上界和下界
            if len(UnExpore_Fact_List) > 0 and len(UnExpore_TA_List) > 0 and len(UnExpore_FA_List) > 0 and len(Answer_Set_List) < Max_Answer_Set_Number:
                # 对未探索的第一个事实、上界、下界进行探索。
                print('未探索的事实列表不为空，对未探索的第一个事实、上界、下界进行探索。')

                Fact_List01 = copy.deepcopy(UnExpore_Fact_List[0])
                TA_List02 = copy.deepcopy(UnExpore_TA_List[0])
                FA_List01 = copy.deepcopy(UnExpore_FA_List[0])
                slove_iternumber01 = 0
                # 删除未探索的事实列表中的第一个事实
                UnExpore_Fact_List.pop(0)
                UnExpore_TA_List.pop(0)
                UnExpore_FA_List.pop(0)
                Slove_P(Fact_List01, TA_List02, FA_List01, Rule_List01, slove_iternumber01, NL_Origin_Question_Text)


        else: # 否则从U中添加一个到L中
            # 遍历u,找出不在L中得事实集合, 应该要求选择的事实属于规则的结论。 ， 需要定制策略来选择合适的事实
            print('随机从上界中选择一个事实中添加一个到下界中！len(TA_List01)={}, len(FA_List01)={}'.format(len(TA_List01), len(FA_List01)))
            # 第一种选择方法：基于大模型的进行选择下一个事实加入到下界中。
            # 随机从Other_Lists中选择一个事实添加到TA_List01
            #choose_fact_string = choose_fact_Based_LLMs(TA_List01, FA_List01, NL_Origin_Question_Text)

            # 第二种： 基于相似度计算的选择事实的方法
            choose_fact_string = choose_fact_Based_Similarity(TA_List01, FA_List01, NL_Origin_Question_Text)
            print('choose_fact_string={}'.format(choose_fact_string))
            choose_None = True if 'None' not in choose_fact_string else False

            if choose_None == True:
                TA_List02 = copy.deepcopy(TA_List01)
                origin_TA_List02 = copy.deepcopy(TA_List02) # 未添加选择的事实
                TA_List02.append(choose_fact_string) # 将选择到的事实加入下届
                print("1. 选择的事实choose_fact_string={}加入下界，重新调用Slove_P函数寻找下一个扩展".format(choose_fact_string))

                slove_iternumber01=0
                FA_List03 = copy.deepcopy(FA_List01)
                FA_List04 = Remove(choose_fact_string, FA_List03)
                print("2. 从上界中删除事实choose_fact_string={}, 删除前FA_List03={}， 删除后FA_List04={}".format(choose_fact_string, FA_List03, FA_List04))

                # 将未探索的事实加入到未探索的事实列表中
                TA_List_02 = copy.deepcopy(origin_TA_List02)
                FA_List_04 = copy.deepcopy(FA_List04)
                UnExpore_Fact_List.append(Fact_List01)
                UnExpore_TA_List.append(TA_List_02)
                UnExpore_FA_List.append(FA_List_04)
                Slove_P(Fact_List01, TA_List02, FA_List01, Rule_List01, slove_iternumber01, NL_Origin_Question_Text)

                # Slove_P(Fact_List01, TA_List01, FA_List04, Rule_List01, slove_iternumber02, NL_Origin_Question_Text)
            else: # U/L中没有选出新的事实
                Answer_Set_List.append(TA_List01)
                print('由于U\L中不再有额外的事实，将此时的下界作为回答集TA_List01 = {}, len(Answer_Set_List)={}, Answer_Set_List={}'.format(TA_List01,len(Answer_Set_List), Answer_Set_List))


# 调用神经符号求解器，输入为事实和规则结合，输出为所有的回答集，然后根据输出的回答集来回答问题。
def NeSy_NMR_Solver(NL_Origin_Facts, NL_Defalut_Rules, NL_Origin_Question_Text):
    TA_List = [] # 用于存储回答集的下限，
    FA_List = [] # 用于存储回答集的上限
    Facts_List = []
    # 初始化回答集的上限和下限
    # 初始化回答集下限
    facts_list01 = NL_Origin_Facts.split('.')
    for fact_Key01 in range(len(facts_list01)):
        if len(facts_list01[fact_Key01])<5:
            continue
        else:
            fact_string = facts_list01[fact_Key01] + '.'
            TA_List.append(fact_string)
            Facts_List.append(fact_string)
    # 初始化回答集上限
    Grounded_Rule_List01 = [] # 存储所有实例化后的规则的列表
    rules_lists01 = NL_Defalut_Rules.split('.')
    Total_Rule_Strings = ''
    for rule_key01 in range(len(rules_lists01)): # 遍历每一个规则，对所有规则进行实例化。
        if len(rules_lists01[rule_key01])<5:
            continue
        else:
            Total_Rule_Strings = rules_lists01[rule_key01] + '. '
            pass
        # 调用大模型对每个规则进行实例化，一次性实例化出所有的
        grounded_rule_result = Grounded_Reasoning_based_LLMs(NL_Origin_Facts, Total_Rule_Strings, rule_key01)
        Grounded_Rule_List01.append(grounded_rule_result)

    # 遍历所有的规则，然后调用大模型获取规则中实例化后的结论
    fact01 = TA_List[0]
    Grounded_conclusion_Context = ''
    Grounded_conclusion_Context = 'The facts are: '
    # 遍历所有事实列表
    for fact_key in range(len(TA_List)):
        Grounded_conclusion_Context = Grounded_conclusion_Context +TA_List[fact_key] +'. '

    Grounded_conclusion_Context = Grounded_conclusion_Context + 'The rules are: '
    FA_List = []  # 用于存储回答集的上限
    for rule_key02 in range(len(Grounded_Rule_List01)):
        rule_string01 = Grounded_Rule_List01[rule_key02]
        Grounded_conclusion_Context =  rule_string01 + '.'
        Grounded_conclusion_Context = Grounded_conclusion_Context.replace('..','.').replace('  ',' ')
        grounded_conclusion_result = ''
        Grounded_conclusion_Context = '\n' + 'The rule is:' + Grounded_conclusion_Context
        while_count01 =0
        Last_FA_List = [] #多次训练，求最佳的FA集合
        while True:
            if while_count01>12:
                break
            result = Iterative_Base_Model(All_Atomes_Prompt_Instruction, Grounded_conclusion_Context)
            while_count01 = while_count01 + 1
            # 判断result是否为字符串，如果不是，则返回
            if not isinstance(result, str):
                continue
            if len(result)<10:
                continue
            result = result.replace('\n','')
            
            if 'extracted facts are' not in result and '#' not in result:
                while_count01 = while_count01 + 1
                continue
            # if result.find('extracted facts are') == -1:
            #     result = 'The extracted facts are:' + result
            # if '#' not in result:
            #     result = result + '#'
            grounded_conclusion_result_string = ''
            grounded_conclusion_result_list = []
            
            if ':' in result and 'extracted facts are' in result:
                grounded_conclusion_result_string = re.findall(Atoms_Output_Pattern, result)
                if len(grounded_conclusion_result_string) == 0:
                    continue
                result = grounded_conclusion_result_string[0]
                if len(result) < 5:
                    while_count01 = while_count01 + 1
                    continue
                if while_count01 >= 10:
                    result = result.replace('\'', '').replace('  ', ' ').replace('..', '.').replace('-','').replace('The output is:','')
                grounded_conclusion_result_list = []
                grounded_conclusion_result_list01 = result.split('.')
                for grounded_fact_Key in range(len(grounded_conclusion_result_list01)):
                    if len(grounded_conclusion_result_list01[grounded_fact_Key])<5:
                        continue
                    else:
                        grounded_fact01 = grounded_conclusion_result_list01[grounded_fact_Key]
                        grounded_fact01 = grounded_fact01.replace('\'', '').replace('  ', ' ').replace('..', '.').replace('-','')
                        grounded_conclusion_result_list.append(grounded_fact01)

                if len(grounded_conclusion_result_list)==0:
                    continue
                FA_List = [grounded_conclusion_result_list[0]+'.'] if len(FA_List)==0 and len(grounded_conclusion_result_list)>0 else FA_List
                fact_similarity = similarity(grounded_conclusion_result_list, FA_List)
                # 如果每个事实最大相似性中的最小值都大于0.9， 则说明所有的事实都找到了对应的事实
                Max_Similarity_grounded_fact = torch.max(fact_similarity, dim=1)  # 求相似矩阵中的每一行的最大值

                for gounded_fact_key02 in range(len(grounded_conclusion_result_list)):
                    if Max_Similarity_grounded_fact.values[gounded_fact_key02]<Similarity_Value and len(grounded_conclusion_result_list[gounded_fact_key02]) > 3 and len(grounded_conclusion_result_list[gounded_fact_key02]) < 40:
                        grounded_fact = grounded_conclusion_result_list[gounded_fact_key02] + '. '
                        grounded_fact = grounded_fact.replace('\'','').replace('  ',' ').replace('..','.')
                        if grounded_fact[0] == ' ':
                            grounded_fact = grounded_fact[1:]
                        FA_List.append(grounded_fact)

                break
            else:
                while_count01 = while_count01 + 1
                continue
        print('抽取原子事实： rule_key02={}, while_count01={}, result={}, rule_string01={}'.format(rule_key02, while_count01, result, Grounded_conclusion_Context))

    # 去重
    FA_List = fact_union(FA_List, TA_List)
    FA_List = Remove_Same_Fact(FA_List)
    print('获取U事实集合的结果len(FA_List)={}, FA_List={}：'.format(len(FA_List), FA_List))
    # 然后调用函数Solve_p来计算所有得回答集。
    slove_iternumber = 0 # 用于限制深度搜索深度 大于等于3就停止搜索，将此时的下界作为回答集返回。
    print('最初的下界len(TA_List) = {}, 上界(FA_List) ={}, TA_List = {}, FA_List = {}'.format(len(TA_List), len(FA_List), TA_List, FA_List))
    Slove_P(Facts_List, TA_List, FA_List, Grounded_Rule_List01, slove_iternumber, NL_Origin_Question_Text)

def Main():
    # 打开读取和写入文件
    with open(Read_Data_file, 'r') as f0, open(Write_file_path02, 'a', encoding='utf-8') as f1:
        Total_Question_label_List = []  # 存储所有问题的标签
        Total_LLMs_Generted_Label_List = []  # 存储生成的标签
        Total_count01 = 1  # 计数器
        Test_Extension_Example_Dict = {}  # 存储扩展示例的字典
        Test_Extension_Example_Dict01 = {2: 40, 1: 40, 4: 40, 3: 40, 5: 40}  # 每个扩展数量的样本测试限制

        for line in f0:
            global Answer_Set_List, Soft_Answer_Set_List, Prerequisite_Conclusion_Consistent_Facts_Dict
            global Each_Example_chatgpt_Number
            Each_Example_chatgpt_Number = 0  # 重置每个示例的计数
            global UnExpore_Fact_List, UnExpore_TA_List, UnExpore_FA_List
            UnExpore_Fact_List = copy.deepcopy([])
            UnExpore_TA_List = copy.deepcopy([])
            UnExpore_FA_List = copy.deepcopy([])
            Write_Dict = {}  # 用于存储需要写入的样本字典
            LLMs_Generted_Label_List = []  # 存储生成的标签
            LLMs_Generted_Answer_Set_Explanation_List = []  # 存储生成的答案集解释

            # 解析JSON行
            js = json.loads(line.strip())
            Sample_number = js['Sample_number']  # 样本编号
            Origin_Facts = js['Origin_Facts']  # 原始事实
            Facts_number = js['Facts_number']  # 计算缺省理论中事实的个数
            Defalut_Rules = js['Defalut_Rules']  # 缺省规则
            NL_Origin_Facts = js['NL_Origin_Facts']  # 自然语言原始事实
            NL_Defalut_Rules = js['NL_Defalut_Rules']  # 自然语言缺省规则
            Origin_ASP_extension_number = js['Origin_ASP_extension_number']  # 原始ASP扩展数量
            Origin_Question_Text_Lists = js['Origin_Question_Text_Lists']  # 原始问题文本列表
            NL_Origin_Question_Text = js['NL_Origin_Question_Text']  # 自然语言问题文本
            Origin_Question_Label_Lists = js['Origin_Question_Label_Lists']  # 原始问题标签列表
            Origin_Question_proof_List = js['Origin_Question_proof_List']  # 原始问题证明列表
            NL_Origin_Question_proof_Text = js['NL_Origin_Question_proof_Text']  # 自然语言问题证明文本

            if Total_count01<-1:
                Total_count01 = Total_count01 + 1
                continue

            # 控制每个扩展数量的样本测试
            if Origin_ASP_extension_number not in Test_Extension_Example_Dict.keys():
                Test_Extension_Example_Dict[Origin_ASP_extension_number] = 1
                if Test_Extension_Example_Dict[Origin_ASP_extension_number] <= Test_Extension_Example_Dict01[Origin_ASP_extension_number]:
                    continue
            else:
                if Test_Extension_Example_Dict[Origin_ASP_extension_number] >= 100:
                    continue
                else:
                    Test_Extension_Example_Dict[Origin_ASP_extension_number] += 1
                    if Test_Extension_Example_Dict[Origin_ASP_extension_number] <= Test_Extension_Example_Dict01[Origin_ASP_extension_number]:
                        continue

            # 初始化答案集
            Answer_Set_List, Soft_Answer_Set_List = [], []
            Prerequisite_Conclusion_Consistent_Facts_Dict = copy.deepcopy({})  # 深拷贝字典

            # 调用NeSy_NMR_Solver进行推理
            NeSy_NMR_Solver(NL_Origin_Facts, NL_Defalut_Rules, NL_Origin_Question_Text)

            # 基于神经符号方法的结果进行推理
            Skeptical_LLMs_Generted_Label_List_with_Similarity, Credulous_LLMs_Generted_Label_List_with_Similarity, Skeptical_LLMs_Generted_Label_List_with_LLM, Credulous_LLMs_Generted_Label_List_with_LLM = None, None, None, None
            
            # 使用相似性推理
            Skeptical_LLMs_Generted_Label_List_with_Similarity, Credulous_LLMs_Generted_Label_List_with_Similarity, Explain_Set_String_List_with_Similarity = Skeptical_Credulous_Reasoning_based_Similarity(NL_Origin_Facts, NL_Origin_Question_Text)
            # 使用大模型进行推理
            Skeptical_LLMs_Generted_Label_List_with_LLM, Credulous_LLMs_Generted_Label_List_with_LLM, Explain_Set_String_List_with_LM = Skeptical_Credulous_Reasoning_based_LLMs(NL_Origin_Facts,NL_Origin_Question_Text)
        
            if Reasoning_Mode == 'credulous':
                print('Total_count01={}, True_Label_Lists = {}, Credulous_LLMs_Generted_Label_List_with_Similarity={}, Credulous_LLMs_Generted_Label_List_with_LLM={}'.format(Total_count01, Origin_Question_Label_Lists,Credulous_LLMs_Generted_Label_List_with_Similarity, Credulous_LLMs_Generted_Label_List_with_LLM))
            else:
                print('Total_count01={}, True_Label_Lists = {}, Skeptical_LLMs_Generted_Label_List_with_Similarity={}, Skeptical_LLMs_Generted_Label_List_with_LLM={}'.format(Total_count01, Origin_Question_Label_Lists,Skeptical_LLMs_Generted_Label_List_with_Similarity, Skeptical_LLMs_Generted_Label_List_with_LLM))

            Total_count01 += 1  # 更新计数器

            # 准备写入字典
            Write_Dict['Sample_number'] = Sample_number  # 样本个数
            Write_Dict['Origin_ASP_extension_number'] = Origin_ASP_extension_number
            Write_Dict['NL_Origin_Question_Text'] = NL_Origin_Question_Text
            Write_Dict['Origin_Question_Label_Lists'] = Origin_Question_Label_Lists
            Write_Dict['LLMs_Generated_Question_Label_Lists_with_Similarity'] = Credulous_LLMs_Generted_Label_List_with_Similarity
            Write_Dict['LLMs_Generated_Question_Label_Lists_with_LLM'] = Credulous_LLMs_Generted_Label_List_with_LLM
            Write_Dict['Origin_Question_proof_List'] = Origin_Question_proof_List
            Write_Dict['NL_Origin_Question_proof_Text'] = NL_Origin_Question_proof_Text
            Write_Dict['LLMs_Generated_Question_Explanation_Lists'] = Explain_Set_String_List_with_LM
            Write_Dict['Question_Explanation_Lists_with_Similarity'] = Explain_Set_String_List_with_Similarity
            Write_Dict['Answer_Set_List'] = Answer_Set_List
            Write_Dict['Each_Example_chatgpt_Number'] = Each_Example_chatgpt_Number


            # 将字典转换为JSON格式并写入文件
            Write_Dict = json.dumps(Write_Dict, ensure_ascii=False)
            f1.write(Write_Dict + '\n')

        # 计算准确率和F1分数
        accuracy = accuracy_score(Total_Question_label_List, Total_LLMs_Generted_Label_List)  # 计算准确率
        F1 = f1_score(Total_Question_label_List, Total_LLMs_Generted_Label_List, average='macro')  # 计算F1分数
        print('accuracy={}, F1={}'.format(accuracy, F1))

if __name__ == '__main__':
    Main()