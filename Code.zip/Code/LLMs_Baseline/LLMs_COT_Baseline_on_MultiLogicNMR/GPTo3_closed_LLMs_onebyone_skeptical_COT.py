"""
新提出的评估指标方法，利用语言模型对证明树进行打分，
"""
import copy
import sys
import re
import httpx
# import torch
sys.path.append('../../Dataset')
import difflib
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
import json
Reasoning_Mode = 'skeptical' # [credulous, skeptical]
Dataset_Name = 'MultiLogicNMR'

Dataset_Category = 'test' # ['train', 'dev', 'test']
Zero_or_Few_Shot = 'Few_Shot_Symolic_COT' # ['Zero_Shot','Few_Shot', 'Zero_Shot_Symolic_COT', 'Few_Shot_Symolic_COT']
OOD_Flag = False
LLMs_Generate = True

OOD_Data_Path = "OOD_Datasets" if OOD_Flag == True else ''
OOD_read_filename = "_ood" if OOD_Flag == True else ''
OOD_write_filename = "ood_" if OOD_Flag == True else ''
read_file_path = None
LLMs_Generate_Datasets = 'GPT4_LLMs_Generated_' if LLMs_Generate == True else ''
if OOD_Flag == True:
    read_file_path = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Datasets/' + OOD_Data_Path + '/'
elif LLMs_Generate == True:
    read_file_path = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/LLMs_Generate_Datasets/' + Reasoning_Mode + '/'
else:
    read_file_path = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Datasets/' + Reasoning_Mode + '/'

write_file_path = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Experimens/LLMs_Results/'
ASP_extension_number_Min, ASP_extension_number_Max = 1,5 #用于对回答集进行过滤
if OOD_Flag == True:
    ASP_extension_number_Min, ASP_extension_number_Max = 6,16
LLMs_Models_Choise = "GPTo3-mini" #['GPTo3-mini','GPT4','Claude','Gemma_7B','Mistral_7B']
Read_Data_file = read_file_path + LLMs_Generate_Datasets + Reasoning_Mode + '_multiNMR_'+ Dataset_Category +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + OOD_read_filename + '.json'
Write_file_path02 = write_file_path + Zero_or_Few_Shot + '_' + LLMs_Models_Choise + '_result_on_' + Dataset_Name + '_' + OOD_write_filename + LLMs_Generate_Datasets + Reasoning_Mode + '_'+ Dataset_Category +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + '.json'


Label_Dict = {'F':[0],'T':[1],'M':[2]}
# 提示要求同时回答多个问题。
# Zero_Shot_Skeptical_Instruction = 'You are an expert in non-monotonic reasoning and are asked to generate answer labels and answer set explanations for questions in a given context. The answers to the questions are labeled "True", "False" and "Unknown". The answer set explanations are all intermediate conclusions generated under a certain reasoning path based on context, where intermediate conclusions are the conclusions generated when applying rules for reasoning. The set of intermediate conclusions generated under a certain reasoning path cannot contradict each other. Since there may be many different paths of reasoning, there may be multiple answer set explanations. If the question can be inferred under all reasoning paths based on the context, and the negation of the question cannot be inferred under all reasoning paths based on the context, the answer label of the question is "True", and needs to generate all answer set explanations that contain the question; if the negation of the question can be inferred under all reasoning path based on the context, and the question cannot be inferred under all reasoning path based on the context, the answer label of the question is "False", and needs to generate all answer set explanations that contain the negation of question; If the question and the negation of the question cannot be deduced under a certain reasoning path based on the context, the answer label of the question is "Unknown", and needs to generate all the answer set explanations than cannot contain the question and all the answer set explanations that cannot contain the negation of the question. Each context has three questions, and the input format is Context: ". Question 1:". Question 2:". Question 3:". You must generate answer labels and answer set explanations for each question. The output format is: The answer label of question 1 is:", The answer set explanations of question 1 is: explanation 1:''.,...,. Explanation n:''. The answer label of question 2 is:", The answer set explanations of question 2 is: Explanation 1:''.,...,. Explanation n:''. The answer label of question 3 is:", The answer set explanations of question 3 is: Explanation 1:''.,...,. Explanation n:''. Please read the context carefully and answer the questions. '
# Zero_Shot_Credulous_Instruction = 'You are an expert in non-monotonic reasoning and are asked to generate answer labels and answer set explanations for questions in a given context. The answers to the questions are labeled "True", "False" and "Unknown". The answer set explanations are all intermediate conclusions generated under a certain reasoning path based on context, where intermediate conclusions are the conclusions generated when applying rules for reasoning. The set of intermediate conclusions generated under a certain reasoning path cannot contradict each other. Since there may be many different paths of reasoning, there may be multiple answer set explanations. If the question can be inferred under a certain reasoning path based on the context, the answer label of the question is "True" and needs to generate all answer set explanations that contain the question; if the negation of the question can be inferred under a certain reasoning path based on the context, the answer label of the question is "False", and needs to generate all answer set explanations that contain the negation of question; If the question and the negation of the question both cannot be deduced under all reasoning path based on the context, the answer label of the question is "Unknown". It needs to generate all the answer set explanations that can not contain the question and all the answer set explanations that can not contain the negation of the question. Each context has three questions, and the input format is Context: ", question 1:", question 2:", question 3:". Please read the context carefully and answer the questions. You must generate answer labels and answer set explanations for each question. The output format is: The answer label of question 1 is:", The answer set explanations of question 1 is: Explanation 1:''.,...,. Explanation n:''. The answer label of question 2 is:". The answer set explanations of question 2 is: Explanation 1:''.,...,. Explanation n:''. The answer label of question 3 is:". The answer set explanations of question 3 is: Explanation 1:''.,...,. Explanation n:''.'

# 提示要求逐个回答问题。
Zero_Shot_COT_Extensions_Skeptical_Instruction = 'Task Description: \n Given contexts and question, and the context consists of facts and default rules. You need first to generate all extensions based on the given context and then to answer the question according to the extensions. \n An extension is a set of non-contradictory facts and conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to find all the extensions. \n Next, the answer to the question is generated based on the generated extension. \n If the question can be inferred under all extensions, and the negation of the question cannot be inferred under all extensions, the answer label of the question is: "True"; \n If the negation of the question can be inferred under all extensions, and the question cannot be inferred under all extensions, the answer label of the question is: "False"; \n If the question and the negation of the question cannot be deduced under a certain extension, the answer label of the question is: "Unknown". \n The input format is: ‘Facts:’’, Default Rules:’’’. Question:".  \n The output format is: The answer label of the question is:". \n You must generate all extensions and answer the question according to the extensions. Don\'t output your reasoning or thinking process. Please read the context carefully. Let\'s think step by step.'
Zero_Shot_COT_Extensions_Credulous_Instruction = 'Task Description: \n Given contexts and question, the context consists of facts and default rules. You first need to generate all extensions based on the given context and then answer the question according to the extensions. \n An extension is a set of non-contradictory facts and conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to find all the extensions according to the above steps. Next, the answer to the question is generated based on the generated extension. \n If the question can be inferred under a certain extension, the answer label of the question is: "True"; \n If the negation of the question can be inferred under a certain extension, the answer label of the question is: "False"; \n If the question and the negation of the question both cannot be deduced under all extension, the answer label of the question is: "Unknown". \n The input format is Context: ‘Facts:‘’, Default Rules:’’’. Question:". \n The output format is: The answer label of the question is:". \n You must generate all extensions and answer the question according to the extensions. Don\'t output your reasoning or thinking process. Please read the context carefully. Let\'s think step by step.'
Few_Shot_COT_Extensions_Skeptical_Instruction = 'Task Description: \n Given contexts and question, and the context consists of facts and default rules. You need first to generate all extensions based on the given context and then to answer the question according to the extensions. \n An extension is a set of non-contradictory facts and conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to find all the extensions. Next, the answer to the question is generated based on the generated extension.\n If the question can be inferred under all extensions, and the negation of the question cannot be inferred under all extensions, the answer label of the question is: "True"; \n If the negation of the question can be inferred under all extensions, and the question cannot be inferred under all extensions, the answer label of the question is: "False"; \n If the question and the negation of the question cannot be deduced under a certain extension, the answer label of the question is: "Unknown".  \n The input format is Context: ‘Facts:’’, Default Rules:’’’. Question:". The output format is: The extensions are:’’. The answer label of the question is:". \n For example: \n Context: \n Facts: Toby is not noisy. Toby is handsome.…. Default Rules: If someoneA is handsome then he is delicious, unless he is not drab. If someoneA is not noisy then he is not drab, unless he is delicious. This context can generate two extensions: The extension 1 are: " Toby is not noisy. Toby is handsome. Toby is delicious."; \n The extension 2 are " Toby is not noisy. Toby is handsome. Toby is not drab.". \n If the Question is: Toby is not noisy. Since all expansions can infer the query " Toby is not noisy.", so the answer label for the question is: True. ; \n If the question is: Toby is not drab. Although extension 2 can deduce the query " Toby is not drab ", extension 1 cannot, so the answer label for the question is: Unknown; \n If the question is: Toby is not handsome. Since all three extensions can lead to the query "Toby is handsome", so the answer label for the question is: False. \n You must generate all extensions and answer the question according to the extensions. Don\'t output your reasoning or thinking process. Please read the context carefully. Let\'s think step by step.'
Few_Shot_COT_Extensions_Credulous_Instruction = 'Task Description: \n Given contexts and question, the context consists of facts and default rules. You first need to generate all extensions based on the given context and then answer the question according to the extensions. \n An extension is a set of non-contradictory facts and conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to find all the extensions according to the above steps. Next, the answer to the question is generated based on the generated extension. If the question can be inferred under a certain extension, the answer label of the question is: "True"; \n If the negation of the question can be inferred under a certain extension, the answer label of the question is: "False"; \n If the question and the negation of the question both cannot be deduced under all extension, the answer label of the question is: "Unknown". \n The input format is: ‘Facts:‘’, Default Rules:’’’. Question:". The output format is: The extensions are:’’. The answer label of the question is:". \n For example: \n Facts: Toby is not noisy. Toby is handsome.…. Default Rules: If someoneA is handsome then he is delicious, unless he is not drab. If someoneA is not noisy then he is not drab, unless he is delicious.  The context can generate two extensions: The extension 1 are: " Toby is not noisy. Toby is handsome. Toby is delicious."; \n The extension 2 are " Toby is not noisy. Toby is handsome. Toby is not drab.". \n If the question is: Toby is not drab. Since extension 2 can lead to the query " Toby is not drab ", so the answer label for the question is True; \n If the question is: Toby is intelligent. Since extensions 1 and 2 cannot deduce the query and the negation of the query, so the answer label for the question is Unknown; \n If the question is: Toby is not handsome. Since the negation of query fact " Toby is handsome." can be derived in extensions, so the answer label for the question is: False. \n You must generate all extensions and answer the question according to the extensions. Don\'t output your reasoning or thinking process. Please read the context carefully. Let\'s think step by step.'

Zero_Shot_Symbolic_COT_Skeptical_Instruction = 'Task Description: \n Given contexts and question, and the context consists of facts and default rules. You need to first generate all extensions based on the given context, then answer the question according to the extensions. To generate an extension in the context, firstly, to generate the initial upper and lower bounds fact sets of extension based on the instantiated default rules, the lower bound fact set is initialized with the original facts. The upper bound fact set should also include all the facts extracted from the rules. Then, the upper and lower bounds facts are updated using the conclusions generated by the rules. If the updated lower bound fact set is still a subset of the upper bound fact set, a fact is selected from the upper bound fact set and added to the lower bound set. Then, the rules are inferred based on the updated upper and lower bound fact sets, and the upper and lower bound fact sets are updated again using the generated conclusions. Specifically, the conclusions generated by the rules under the upper bound fact set should be included in the lower bound fact set. In comparison, the upper bound fact set should only contain the conclusions generated by the reduced rules in the lower bound fact set. Finally, the process is iterated until the upper and lower bounds facts are consistent and an extension is found. There may be multiple extensions in the context, and you need to find all the extensions according to the above steps. Next, the answer to the question is generated based on the generated extension. If the question can be inferred under all extensions, and the negation of the question cannot be inferred under all extensions, the answer label of the question is: "True" ###; If the negation of the question can be inferred under all extensions, and the question cannot be inferred under all extensions, the answer label of the question is: "False" ### ; If the question and the negation of the question cannot be deduced under a certain extension, the answer label of the question is: "Unknown" ###. \n The input format is: ‘Facts:’’, Default Rules:’’’. Question:". \n The output format is: The answer label of the question is:".### \n Note that you only need to generate the answer label for the question. Don\'t output your reasoning or thinking process. Please read the context carefully and answer the questions. Let\'s think step by step.'
Zero_Shot_Symbolic_COT_Credulous_Instruction = 'Task Description: \n Given contexts and question, and the context consists of facts and default rules. You need to first generate all extensions based on given context, then to answer the question according to the extensions. To generate an extension in the context, firstly, to generate the initial upper and lower bounds fact sets of extension based on the instantiated default rules, the lower bound fact set is initialized with the original facts. The upper bound fact set should also include all the facts extracted from the rules. Then, the upper and lower bounds facts are updated using the conclusions generated by the rules. If the updated lower bound fact set is still a subset of the upper bound fact set, a fact is selected from the upper bound fact set and added to the lower bound set. Then, the rules are inferred based on the updated upper and lower bound fact sets, and the upper and lower bound fact sets are updated again using the generated conclusions. Specifically, the conclusions generated by the rules under the upper bound fact set should be included in the lower bound fact set. In comparison, the upper bound fact set should only contain the conclusions generated by the reduced rules in the lower bound fact set. Finally, the process is iterated until the upper and lower bounds facts are consistent and an extension is found. There may be multiple extensions in the context, and you need to find all the extensions according to the above steps. Next, the answer to the question is generated based on the generated extension. If the question can be inferred under a certain extension, the answer label of the question is: "True" ###; If the negation of the question can be inferred under a certain extension, the answer label of the question is: "False" ###; If the question and the negation of the question both cannot be deduced under all extension, the answer label of the question is: "Unknown" ###. \n The input format is: ‘Facts:‘’, Default Rules:’’’. Question:". \n The output format is: The answer label of the question is:". ### \n Note that you only need to generate the answer label for the question. Don\'t output your reasoning or thinking process. Please read the context carefully and answer the questions. Let\'s think step by step.'
Few_Shot_Symbolic_COT_Skeptical_Instruction = 'Task Description: \n Given contexts and question, and the context consists of facts and default rules. You need to first generate all extensions based on the given context, then answer the question according to the extensions. To generate an extension in the context, firstly, to generate the initial upper and lower bounds fact sets of extension based on the instantiated default rules, the lower bound fact set is initialized with the original facts. The upper bound fact set should also include all the facts extracted from the rules. Then, the upper and lower bounds facts are updated using the conclusions generated by the rules. If the updated lower bound fact set is still a subset of the upper bound fact set, a fact is selected from the upper bound fact set and added to the lower bound set. Then, the rules are inferred based on the updated upper and lower bound fact sets, and the upper and lower bound fact sets are updated again using the generated conclusions. Specifically, the conclusions generated by the rules under the upper bound fact set should be included in the lower bound fact set. In comparison, the upper bound fact set should only contain the conclusions generated by the reduced rules in the lower bound fact set. Finally, the process is iterated until the upper and lower bounds facts are consistent and an extension is found. There may be multiple extensions in the context, and you need to find all the extensions according to the above steps. Next, the answer to the question is generated based on the generated extension. If the question can be inferred under all extensions, and the negation of the question cannot be inferred under all extensions, the answer label of the question is: "True"; If the negation of the question can be inferred under all extensions, and the question cannot be inferred under all extensions, the answer label of the question is: "False"; If the question and the negation of the question cannot be deduced under a certain extension, the answer label of the question is: "Unknown". \n The input format is: ‘Facts:’’, Default Rules:’’’. Question:". \n The output format is: The extensions are:’’. The answer label of the question is:" ###. \n For example: \n Context: \n Facts: Toby is not noisy. Toby is handsome.…. Default Rules: If someoneA is handsome then he is delicious, unless he is not drab. If someoneA is not noisy then he is not drab, unless he is delicious. The first step is to generate the upper and lower bounds of the extension. The lower bound fact set is "Toby is not noisy. Toby is handsome.", and the upper bound fact set is "Toby is not noisy. Toby is handsome. Toby is delicious. Toby is not drab.". Then, the upper bound facts are updated using the conclusion "Toby is delicious. Toby is not drab." generated by the lower bound fact set based on the default rule. The new upper bound fact set is "Toby is not noisy. Toby is handsome. Toby is delicious. Toby is not drab.". Similarly, since the default rule does not generate new facts when reasoning on the upper bound fact set, the lower bound fact set remains unchanged. At this time, since the lower bound fact set is a subset of the upper bound fact set, a fact is randomly selected from the upper bound fact set and added to the lower bound fact set. The new lower bound fact set is updated to "Toby is not noisy. Toby is handsome. Toby is delicious." The new upper bound fact set is "Toby is not noisy. Toby is handsome. Toby is not drab.". Then the default rule is inferred based on the new upper and lower bound fact sets, and the process is iterated until the upper and lower bounds of the extension are consistent. Finally, the context can generate two extensions: The extension 1 are: " Toby is not noisy. Toby is handsome. Toby is delicious."; \n The extension 2 is " Toby is not noisy. Toby is handsome. Toby is not drab.". \n If the Question is: Toby is not noisy. Since all expansions can infer the query " Toby is not noisy."， so the answer label for the question is: True. ### ; \n If the question is: Toby is not drab. Although extension 2 can deduce the query " Toby is not drab ", extension 1 cannot deduce this query， so the answer label for the question is: Unknown ###; \n If the question is: Toby is not handsome. Since all three extensions can lead to the query "Toby is handsome", so the answer label for the question is: False ### . \n Note that you only need to generate the answer label for the question. Don\'t output your reasoning or thinking process. Please read the context carefully and answer the questions. Let\'s think step by step. '
Few_Shot_Symbolic_COT_Credulous_Instruction = 'Task Description: \n Given contexts and question, and the context consists of facts and default rules. You need to first generate all extensions based on the given context, then answer the question according to the extensions. To generate an extension in the context, firstly, to generate the initial upper and lower bounds fact sets of extension based on the instantiated default rules, the lower bound fact set is initialized with the original facts. The upper bound fact set should also include all the facts extracted from the rules. Then, the upper and lower bounds facts are updated using the conclusions generated by the rules. If the updated lower bound fact set is still a subset of the upper bound fact set, a fact is selected from the upper bound fact set and added to the lower bound set. Then, the rules are inferred based on the updated upper and lower bound fact sets, and the upper and lower bound fact sets are updated again using the generated conclusions. Specifically, the conclusions generated by the rules under the upper bound fact set should be included in the lower bound fact set. In comparison, the upper bound fact set should only contain the conclusions generated by the reduced rules in the lower bound fact set. Finally, the process is iterated until the upper and lower bounds facts are consistent and an extension is found. There may be multiple extensions in the context, and you need to find all the extensions according to the above steps. Next, the answer to the question is generated based on the generated extension. If the question can be inferred under a certain extension, the answer label of the question is: "True"; If the negation of the question can be inferred under a certain extension, the answer label of the question is: "False"; If the question and the negation of the question both cannot be deduced under all extension, the answer label of the question is: "Unknown". \n The input format is: ‘Facts:‘’, Default Rules:’’’. Question:". \n The output format is: The extensions are:’’. The answer label of the question is:" ###. \n For example: \n Facts: Toby is not noisy. Toby is handsome.…. Default Rules: If someoneA is handsome then he is delicious, unless he is not drab. If someoneA is not noisy then he is not drab, unless he is delicious. The first step is to generate the upper and lower bounds of the extension. The lower bound fact set is "Toby is not noisy. Toby is handsome.", and the upper bound fact set is "Toby is not noisy. Toby is handsome. Toby is delicious. Toby is not drab.". Then, the upper bound facts are updated using the conclusion "Toby is delicious. Toby is not drab." generated by the lower bound fact set based on the default rule. The new upper bound fact set is "Toby is not noisy. Toby is handsome. Toby is delicious. Toby is not drab.". Similarly, since the default rule does not generate new facts when reasoning on the upper bound fact set, the lower bound fact set remains unchanged. At this time, since the lower bound fact set is a subset of the upper bound fact set, a fact is randomly selected from the upper bound fact set and added to the lower bound fact set. The new lower bound fact set is updated to "Toby is not noisy. Toby is handsome. Toby is delicious." The new upper bound fact set is "Toby is not noisy. Toby is handsome. Toby is not drab.". Then the default rule is inferred based on the new upper and lower bound fact sets, and the process is iterated until the upper and lower bounds of the extension are consistent. Finally, the context can generate two extensions: The extension 1 are: " Toby is not noisy. Toby is handsome. Toby is delicious."; \n The extension 2 are " Toby is not noisy. Toby is handsome. Toby is not drab.". \n If the question is: Toby is not drab. Since extension 2 can lead to the query " Toby is not drab ", so the answer label for the question is: True; ### \n If the question is: Toby is intelligent. Since extensions 1 and 2 cannot deduce the query and the negation of the query, the answer label for the question is: Unknown; ###  \n If the question is: Toby is not handsome. Since the negation of query fact " Toby is handsome." can be derived in extensions, the answer label for the question is: False. ### \n Note that you only need to generate the answer label for the question. Don\'t output your reasoning or thinking process. Please read the context carefully and answer the questions. Let\'s think step by step.'
Output_Pattern = "(?<=question is:).*?(?=Note|#|The explanation is|Step-by-step|```｜Instruction|1```1)"


Yeliang_API_Key = "sk-n7IWXtrI2d0JsnbuDa6dD8F090444fEaAaF1C101D899Fa3b" # "sk-wYnDOGnqs7X62a2DEcFa8094B6384f2aAf12AfD88d1dC649", "sk-n7IWXtrI2d0JsnbuDa6dD8F090444fEaAaF1C101D899Fa3b"
Base_URL = "https://35.aigcbest.top/v1" #  "https://api.nhyun.top" #"https://35.aigcbest.top/v1"
def chatGPT_Solver(instructions, context, question):
    client = OpenAI(base_url=Base_URL,
                    api_key=Yeliang_API_Key)
    while_count01 = 0
    while while_count01 < 10:
        try:
            rsp = client.chat.completions.create(
              model="gpt-3.5-turbo", # gpt-3.5-turbo/ gpt-4-turbo-preview
              messages=[
                    {"role": "system", "content": instructions},
                    {"role": "user", "content": context + question}
                ],
              temperature=0
            )
            result = rsp.choices[0].message.content
            return result
        except Exception as e:
            print(f"llm_send报错 {while_count01 + 1}次尝试: {e}")
            while_count01 += 1
        return ""

def GPTo3_Solver(instructions, context, question):
    client = OpenAI(base_url=Base_URL,
                    api_key=Yeliang_API_Key,
                    http_client=httpx.Client(base_url=Base_URL,follow_redirects=True,
                                             ),
                    )
    while_count01 = 0
    while while_count01 < 10:
        try:
            rsp = client.chat.completions.create(
              model="o3-mini",
              messages=[
                    {"role": "system", "content": instructions},
                    {"role": "user", "content": context + question}
                ],
              temperature=0
            )
            result = rsp.choices[0].message.content
            return result
        except Exception as e:
            print(f"llm_send报错 {while_count01 + 1}次尝试: {e}")
            while_count01 += 1
        return ""

def claude_Solver(instructions, context, question):
    client = OpenAI(base_url=Base_URL,
                    api_key=Yeliang_API_Key,
                    http_client=httpx.Client(base_url=Base_URL,follow_redirects=True,
                                             ),
                    )
    while_count01 = 0
    while while_count01 < 10:
        try:
            rsp = client.chat.completions.create(
              model="claude-3-opus-20240229", # 'claude-3-opus-20240229','claude-3-sonnet-20240229'
              messages=[
                    {"role": "system", "content": instructions},
                    {"role": "user", "content": context + question}
                ]
            )
            result = rsp.choices[0].message.content
            return result
        except Exception as e:
            print(f"llm_send报错 {while_count01 + 1}次尝试: {e}")
            while_count01 += 1
    return ""

def Read():
    with open(Read_Data_file, 'r', encoding='utf-8') as f0, open(Write_file_path02, 'a', encoding='utf-8') as f1:
        Total_Question_label_List = []
        Total_LLMs_Generted_Label_List = []
        Total_count01 = 1
        Test_Extension_Example_Dict = {}
        Test_Extension_Example_Dict01 = {6: 0, 8: 0, 10: 0, 12: 0, 16: 0} if OOD_Flag == True else {2: 20, 1: 20, 4: 20, 3: 20, 5: 5}

        for line in f0:
            Write_Dict = {}  # 该字典用于存储需要写入的样本字典
            LLMs_Generted_Label_List = []
            LLMs_Generted_Answer_Set_Explanation_List = []
            js = json.loads(line.strip())
            # 将数据集划分成训练/验证/测试
            # print(json.dumps(js, ensure_ascii=False))
            Sample_number = js['Sample_number']
            Origin_Facts = js['Origin_Facts']
            Facts_number = js['Facts_number']  # 计算缺省理论中事实的个数
            Defalut_Rules = js['Defalut_Rules']
            # Noise_Facts_Lists = js['Noise_Facts_Lists']
            NL_Origin_Facts = js['NL_Origin_Facts']
            NL_Defalut_Rules = js['NL_Defalut_Rules']
            # NL_Noise_Facts_Lists = js['NL_Noise_Facts_Lists']

            # Noise_Default_Rules_Lists = js['Noise_Default_Rules_Lists']
            # NL_Noise_Default_Rule_Lists = js['NL_Noise_Default_Rule_Lists']
            Origin_ASP_extension_number = js['Origin_ASP_extension_number']
            Origin_Question_Text_Lists = js['Origin_Question_Text_Lists']
            NL_Origin_Question_Text = js['NL_Origin_Question_Text']
            Origin_Question_Label_Lists = js['Origin_Question_Label_Lists']
            Origin_Question_proof_List = js['Origin_Question_proof_List']
            NL_Origin_Question_proof_Text = js['NL_Origin_Question_proof_Text']

            # # 每个扩展数量的样本测试20个
            if Origin_ASP_extension_number not in Test_Extension_Example_Dict.keys():
                Test_Extension_Example_Dict[Origin_ASP_extension_number] = 1
                if Test_Extension_Example_Dict[Origin_ASP_extension_number] <= Test_Extension_Example_Dict01[Origin_ASP_extension_number]:
                    Total_count01 = Total_count01 + 1
                    continue
            else:
                if Test_Extension_Example_Dict[Origin_ASP_extension_number] >= 20:
                    continue
                else:
                    Test_Extension_Example_Dict[Origin_ASP_extension_number] = Test_Extension_Example_Dict[Origin_ASP_extension_number] + 1
                    if Test_Extension_Example_Dict[Origin_ASP_extension_number] <= Test_Extension_Example_Dict01[Origin_ASP_extension_number]:
                        Total_count01 = Total_count01 + 1
                        continue

            Answer_Set_List = []
            if Total_count01 <= -1:
                print('Test_Extension_Example_Dict={}'.format(Test_Extension_Example_Dict))
                continue

            Instruction = ''
            if Zero_or_Few_Shot == 'Zero_Shot_Extension_COT' and Reasoning_Mode == 'credulous':
                Instruction = Zero_Shot_COT_Extensions_Credulous_Instruction
            elif Zero_or_Few_Shot == 'Zero_Shot_Extension_COT' and Reasoning_Mode == 'skeptical':
                Instruction = Zero_Shot_COT_Extensions_Skeptical_Instruction
            elif Zero_or_Few_Shot == 'Few_Shot_Extension_COT' and Reasoning_Mode == 'credulous':
                Instruction = Few_Shot_COT_Extensions_Credulous_Instruction
            elif Zero_or_Few_Shot == 'Few_Shot_Extension_COT' and Reasoning_Mode == 'skeptical':
                Instruction = Few_Shot_COT_Extensions_Skeptical_Instruction
            elif Zero_or_Few_Shot == 'Zero_Shot_Symolic_COT' and Reasoning_Mode == 'credulous':
                Instruction = Zero_Shot_Symbolic_COT_Credulous_Instruction
            elif Zero_or_Few_Shot == 'Zero_Shot_Symolic_COT' and Reasoning_Mode == 'skeptical':
                Instruction = Zero_Shot_Symbolic_COT_Skeptical_Instruction
            elif Zero_or_Few_Shot == 'Few_Shot_Symolic_COT' and Reasoning_Mode == 'credulous':
                Instruction = Few_Shot_Symbolic_COT_Credulous_Instruction
            elif Zero_or_Few_Shot == 'Few_Shot_Symolic_COT' and Reasoning_Mode == 'skeptical':
                Instruction = Few_Shot_Symbolic_COT_Skeptical_Instruction

            Context_Text_String = 'Context: ' + NL_Origin_Facts
            Context_Text_String = Context_Text_String + NL_Defalut_Rules
            Question_Text_String = ''
            for question_key in range(len(NL_Origin_Question_Text)):
                question_text = ' Question: ' + NL_Origin_Question_Text[question_key]
                Question_Text_String = question_text
                question_label = Origin_Question_Label_Lists[question_key]
                Total_Question_label_List.extend(Label_Dict[question_label[0]])
                # 调用大模型预测
                results = None
                extracted_result = ''

                if LLMs_Models_Choise =='GPTo3-mini':
                    while_count01 = 0
                    while True:
                        if while_count01 >= 3:
                            break
                        results = GPTo3_Solver(Instruction, Context_Text_String, Question_Text_String)
                        if not isinstance(results, str):
                            print("结果不是字符串类型，跳过当前循环")
                            while_count01 = while_count01 + 1
                            continue
                        ### 添加一个函数用于对大模型生成结果的格式进行判断，如何不符合格式，则重新生成。
                        results = results.replace('\n', ' ')
                        extracted_result_list = re.findall(Output_Pattern, results)
                        if len(extracted_result_list) != 0:
                            extracted_result = extracted_result_list[0]
                            break
                        else:
                            extracted_result = results
                            while_count01 = while_count01 + 1
                            continue


                ### 添加一个函数用于对大模型生成结果的格式进行判断，如何不符合格式，则重新生成。

                # 对生成的结果进行分析
                print("Total_count01={}, extracted_Results = {}, results = {}".format(Total_count01, extracted_result, results))
                predict_label = None
                if 'unknown' in extracted_result or 'Unknown' in extracted_result:
                    predict_label = 'M'
                elif 'true' in extracted_result or 'True' in extracted_result:
                    predict_label = 'T'
                elif 'false' in extracted_result or 'False' in extracted_result:
                    predict_label = 'F'
                else:
                    predict_label = 'M'
                LLMs_Generted_Label_List.append([predict_label])

                Total_LLMs_Generted_Label_List.extend(Label_Dict[predict_label])
            print('Total_count01={}, Total_LLMs_Generted_Label_List = {}, Origin_Question_Label_Lists: = {}'.format(Total_count01, LLMs_Generted_Label_List, Origin_Question_Label_Lists))

            Total_count01 = Total_count01 + 1
            Write_Dict['Sample_number'] = Sample_number  # 样本个数
            Write_Dict['Origin_ASP_extension_number'] = Origin_ASP_extension_number
            Write_Dict['NL_Origin_Question_Text'] = NL_Origin_Question_Text
            Write_Dict['Origin_Question_Label_Lists'] = Origin_Question_Label_Lists
            Write_Dict['LLMs_Generated_Question_Label_Lists'] = LLMs_Generted_Label_List

            Write_Dict['Origin_Question_proof_List'] = Origin_Question_proof_List
            Write_Dict['NL_Origin_Question_proof_Text'] = NL_Origin_Question_proof_Text
            Write_Dict['LLMs_Generated_Question_Explanation_Lists'] = ''
            Write_Dict['LLMs_Repose'] = ''
            Write_Dict = json.dumps(Write_Dict, ensure_ascii=False)
            f1.write(Write_Dict + '\n')

        accuracy = accuracy_score(Total_Question_label_List, Total_LLMs_Generted_Label_List) # 计算准确率
        F1 = f1_score(Total_Question_label_List, Total_LLMs_Generted_Label_List,average = 'macro')
        print('accuracy={},F1={}'.format(accuracy,F1))


if __name__ == '__main__':
    Read()
