"""
针对非单调推理的神经符号方法的实现
"""
from abc import ABC, abstractmethod
from collections import defaultdict
import math
import copy
import random
import sys
import re
import httpx
import torch

sys.path.append('/home/yeliangxiu/Projects/LLM_ASP_NeSY_Solver/Datasets')
import difflib
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
import json
import traceback
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ["NCCL_P2P_DISABLE"] = "1"  # 禁用NCCL P2P通信
os.environ["NCCL_IB_DISABLE"] = "0"  # 禁用NCCL IB通信
import torch
from clingo.control import Control
from clingo.symbol import parse_term
from transformers import TrainingArguments, AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig, AutoTokenizer, \
    AutoModel
from trl import SFTTrainer, SFTConfig, DataCollatorForCompletionOnlyLM
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
from peft import LoraConfig
import json
from datasets import Dataset
import pandas as pd
from sentence_transformers import SentenceTransformer, util

max_seq_length = 2048
Reasoning_Mode = 'skeptical'  # [credulous, skeptical]
Formal_Natural_Language = 'ASP'  # ['ASP','DL']
Translation_Sentences_Number = 3  # 表示每个句子的翻译次数，当生成的候选句子为1时，则表示每个句子只翻译一次，并且不使用验证器。
Aligned_Rules_Flag = False  # 用于指示是否进行谓词一致性对齐 , True表示使用对齐谓词模块，False表示不使用
Iterative_Repair_Flag = False  # 用于指示是， True表示直接修复， False表示间接修复
Grammar_Semantic_Verifier_Flag = False if Translation_Sentences_Number == 1 else True  # 当生成的候选句子为1时，则表示每个句子只翻译一次，并且不使用验证器。
Selected_Sentence_Number = 1  # 表示每个句子从候选翻译句子列表中选择加入到上下文中的个数，默认为1
OOD_Flag, NL_Flag = False, True
Similarity_with_GPT4_Flag, Similarity_with_LLAMA31_Flag, Similarity_with_Sentence_Transformer_Flag = False, False, True  # 用于指示是否是基于相似度进行对问题在回答集上推理还是直接使用大模型对问题进行推理
Dataset_Name = None  # 表示数据集  ['MultiLogicNMR_OOD', 'MultiLogicNMR_NL', 'MultiLogicNMR']
if OOD_Flag == True:
    Dataset_Name = "MultiLogicNMR_OOD"
elif NL_Flag == True:
    Dataset_Name = "MultiLogicNMR_NL"
else:
    Dataset_Name = "MultiLogicNMR"

read_file_path = None
read_file_path = '/home/yeliangxiu/Projects/LLM_ASP_NeSY_Solver/Datasets/' + Dataset_Name + '/' + Reasoning_Mode + '/'
write_file_path = '/home/yeliangxiu/Projects/LLM_ASP_NeSY_Solver/Experiment/Results/'
ASP_extension_number_Min, ASP_extension_number_Max = 1, 5  # 用于对回答集进行过滤
if OOD_Flag == True:
    ASP_extension_number_Min, ASP_extension_number_Max = 6, 16

LLMs_Models_Choise = "GPT3.5"  # ['GPT3.5','GPT4o-mini','Claude','Gemma_7B','Mistral_7B','LLAMA3','LLAMA31']

import warnings

warnings.filterwarnings("ignore")

import numpy as np


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


# 设置随机数种子
setup_seed(20)
# 提示模型生成最初的ASP程序
Prompt_with_Generate_ASP_Code = '###Task: \n You are an expert trained in Answer Set Programming. Our goal is to translate the natural language sentence into ASP programs. The general fact of answer set programming is: a(X). This fact means that X is a. The general rule of ASP program is: a(X) :- b(X), not c.(X) This rule means that if X is b then he is a, unless he is not c. \n The input format is: The natural language sentence to be translated is:"". \n The output format is: The predicate of the sentence is:. ### \n The entities of the sentence is:. ### \n The translated sentence is:. ### \n For example 1: The natural language sentence to be translated is: kingston is guilty. Toby scorn benjamin. sinclair is not super. If someoneA is not nervous and gifted then he is boring, unless he is important and not stress. If someonea is not numerous and young then he is pleasant, unless he is not financial.\n The predicate of the sentence is: guilty. ### \n The entities of the sentence is: kingston. ### \n The translated sentence is: guilty(kingston). scorn(toby, benjamin). -super(sinclair). boring(X):- -nervous(X), gifted(X), not important(X), not -stress(X). pleasant(X) :--numberous(X), young(X), not -financial(X). ### \n Note that you only need to generate the answer, not the solution step. \n'
# 提示模型生成缺省逻辑
Prompt_with_Generate_Default_Logic_Code = '###Task: \n You are an expert trained in default logic. Our goal is to translate the natural language sentence into default logic. The general fact of default logic is: a(X). This fact means that X is a. The general rule of default logic is: b(X) : c(X) / a(X). This rule means that if x is b and believe that he is c, then it can be inferred that x is a. \n The input format is: The natural language sentence to be translated is:"". \n The output format is: The predicate of the sentence is:. ### \n The entities of the sentence is:. ### \n The translated sentence is:. ### \n For example 1: The natural language sentence to be translated is: kingston is guilty. \n The predicate of the sentence is: guilty. ### \n The entities of the sentence is: kingston. ### \n The translated sentence is: guilty(kingston). ### \n For example 2: The natural language sentence to be translated is: Toby scorn benjamin. ### \n The predicate of the sentence is: scorn. ### \n The entities of the sentence is: toby. benjamin. ### \n The translated sentence is: scorn(toby, benjamin). ### \n For example 3: The natural language sentence to be translated is: If someoneA is not nervous and gifted then he is boring, unless he is important and not stress. ### \n The predicate of the sentence is: nervous. gifted. boring. important. stress. ### \n The entities of the sentence is: X. ### \n The translated sentence is: -nervous(X) ∧ gifted(X): important(X), -stress(X) / boring(X). ### \n For example 4: The natural language sentence to be translated is: sinclair is not super. ### \n The predicate of the sentence is: super. ### \n The entities of the sentence is: sinclair. ### \n The translated sentence is: -super(sinclair). ### \n For example 5: The natural language sentence to be translated is: if someonea is not numerous and young then he is pleasant, unless he is not financial. ### \n The predicate of the sentence is: numerous. young. pleasant. financial. ### \n The entities of the sentence is: X. ### \n The translated sentence is: -numberous(X)∧young(X): -financial(X) / pleasant(X). ### \n Note that you only need to generate the answer, not the solution step. \n'
Prompt_with_Predicate_Consistency_Alignment = '###Task: \n You are an expert in answer set programming. Our goal is to align predicates with the same semantics. If there are predicates with the same semantics but different terms in the answer set program, you can generate new rules to align the different predicates. The input format is: The natural language sentences are:‘’. ### \n The formal logic program are:’’. The output format is: The aligned logic program are:''. ### \n For example 1: The natural language sentences are: Toby is not loud. Toby lacks intelligence. Toby is attractive. If an individual is attractive yet unwise, they are considered delectable, unless they are dull. If a person is delectable but not vigilant, they are considered sizable, unless they mourn or are not mean-spirited. If a person is quiet and delectable, they are termed unique, unless they are deceased. ### \n The formal logic program are: -loud(toby). -intelligence(toby). attractive(toby). delectable(X) :- attractive(X), unwise(X), not dull(X). sizeable(X) :- delectable(X), -vigilant(X), not mourn(X), not -meanspirited(X). unique(X) :- quiet(X), delectable(X), not deceased(X). ### \n The aligned formal logic program are: -loud(toby). -intelligence(toby). attractive(toby). huge(toby). delectable(X) :- attractive(X), -intelligence (X), not dull(X). huge(X) :- delectable(X), -vigilant(X), not mourn(X), not -meanspirited(X). unique(X) :- -loud (X), delectable(X), not deceased(X). ### \n For example 2: The natural language sentences are: Sinclair is free from confusion. Sinclair embodies purity. Sinclair is courageous. Sinclair is full of glamour. Sinclair shows no reverence towards Grover. If an individual neither exhibits confusion nor holds a pessimistic view, they are free from regret, unless they are considered costly or not comforted. An individual who is pure is financially oriented, unless they are tangible. If an individual is both likely and glamorous, they do not grow tired, unless they lack enthusiasm.### \n The formal logic program are: confusion(sinclair). purity(sinclair). courageous(sinclair). glamour(sinclair). -reverence(sinclair). -regret(X) :- -confused(X), -pessimistic(X), not costly(X),not -comforted(X). financially_oriented(X) :- pure(X), not tangible(X). -tired(X) :- likely(X), glamorous(X), not -enthusiasm(X). ### \n The aligned formal logic program are: confusion(sinclair). purity(sinclair). courageous(sinclair). glamour(sinclair). -reverence(Sinclair, grover). financial(sinclair). -regret(X) :- -confusion(X), -pessimistic(X), not costly(X),not -comforted(X). financial(X) :- purity(X), not tangible(X). -tired(X) :- likely(X), glamour(X), not -enthusiasm(X). ### \n Note that you only need to generate the aligned logic program. \n'
# 提示模型对ASP程序进行修复
Prompt_with_Direct_Repair_ASP_Code = '###Task: \n You are an ASP program editor. You will be given a natural language sentence and the corresponding ASP program. However, the given ASP program contains syntax errors. You need to repair the ASP program according to the given syntax error information and explain the repair process. \n Input format: Natural language sentence: ''. \n Incorrect ASP sentence: ''. \n Error message: ''. \n Output format: Repaired ASP program is: ''. ### \n The repair explanation is:''.### \n. For example: The input are: Natural language sentence: If someoneA is different then he is not numerous, unless he is not confused or he is not financial. \n Incorrect ASP sentence: numerous(X) :- different(X), (confused(X); financial(X)). \n Error message: syntax error, unexpected not, expecting ).\n The output is: Repaired ASP program is: -numerous(X):- different(X), not confused(X), not financial(X). ### \n The repair explanation is: The main reason for the error is the translation error of the clause "unless he is not confused or he is not financial." There are also extra symbols "(",")" and ";". The correct translation should be "not -confused(X), not -financial(X).".### \n. Note that you only need to generate the repaired ASP program. \n'
# 基于大语言模型对语法风格正确性进行打分
Grammar_Score_Prompt = "You are an expert in answer set programming. Please carefully analyze the given asp sentence and score the correctness of the asp sentence. The score ranges from 0 to 1, where 1 means they are exactly correct and 0 means the asp sentence was wroing. \n The input format is: The ASP sentences is:''. \n The output format is: The score is:.  ### \n For example 1: The translated ASP sentences are: -southern(brandan). \n The score is: 0.95.### \n For example 2: The translated ASP sentences are: -southern(brandan). \n The score is: 0.95. ### \n For example 3: The translated ASP sentences are: -southern(brandan). \n The score is: 0.95. ### \n For example 4: The translated ASP sentences are: -southern(X). \n The score is: 0.5. ### \n For example 5: The translated ASP sentences are: different(X):- -noisy(X), delicious(X), not dead(X). \n The score is: 0.95. ### \n For example 6: The translated ASP sentences are: different(X):- -noisy(X), delicious(X). \n The score is: 0.5. ### \n For example 7: The translated ASP sentences are: different(X):- -noisy(X), delicious(X).-foreign(X) :-  -pessimistic(X), scared(X),  not -foreign(X);-sensitive(X),  not -bossy(X). \n The score is: 0. ### \n Note that you only need to output the score."
# 基于大语言模型语义相似性比较的提示
# 基于大语言模型语义相似性比较的提示, ASP语言
Semantic_Score_Prompt_with_ASP = "You are an expert in answer set programming. Please verify and score the correctness of the given natural language sentence and the corresponding logic program sentence. The general fact of answer set programming is: a(X). This fact means that X is a. The general rule of ASP program is: a(X) :- b(X), not c.(X) This rule means that if X is b then he is a, unless he is not c. \n The score ranges from 0 to 1, where 1 means that the translated logic program is completely correct, while a score of 0 means that the translated logic program sentence is completely wrong. If you think logical program is wrong, then you need to explain. \n The input format is: The natural language sentences are:''. The translated logic program sentences are:''. \n The output format is: The score is:. ### \n The explanation is:''. ### \n For example 1: The natural language sentences are: Brandan is not southern. \n The translated logic program sentences are: -southern(brandan). \n The score is: 0.99. ### \n  The explanation is: None. ### \n For example 2: The natural language sentences are: Brandan is southern. \n The translated logic program sentences are: -southern(brandan). \n The score is: 0.1. ### \n The explanation is: '-' error in logic program. ### \n For example 3: The natural language sentences are: Brandan is southern. \n The translated logic program sentences are: -southern(X). \n The score is: 0.1. ### \n The explanation is: The entities in the logic program should be Brandan. ### \n For example 4: The natural language sentences are: Brandan is emotional. \n The translated logic program sentences are: emotional(brandan). \n The score is: 0.99. ### \n  The explanation is: None. ### \n For example 5: The natural language sentences are: If someoneA is technical and zany then he is long, unless he is attractive. \n The translated logic program sentences are: long(X):- technical(X), zany(X), not attractive(X). \n The score is: 0.99. ### \n The explanation is: None. ### \n For example 6: The natural language sentences are: If someoneA is technical and zany then he is long, unless he is attractive. \n The translated logic program sentences are: long(X):- technical(X), zany(X). \n The score is: 0.1. ### \n The explanation is: 'unless he is attractive.' is not translated into a formal language. ### \n For example 7: The natural language sentences are: If someoneA is aggressive then he is asleep, unless he is not short. \n The translated ASP sentences are: asleep(X):- aggressive(X), not -short(X). \n The score is: 0.99. ### \n The explanation is: None. ### \n Note that you only need to output the semantic similarity score."
# 基于大语言模型语义相似性比较的提示, DL语言
Semantic_Score_Prompt_with_DL = "You are an expert in default logic. Please verify and score the correctness of the given natural language sentence and the corresponding default logic sentence. The general fact of default logic is: a(X). This fact means that X is a. The general rule of default logic is: b(X) : c(X) / a(X). This rule means that if x is b and believe that he is c, then it can be inferred that x is a. \n The score ranges from 0 to 1, where 1 means that the translated default logic is completely correct, while a score of 0 means that the translated default logic sentence is completely wrong. If you think logical program is wrong, then you need to explain.\n The input format is: The natural language sentences are:''. The translated logic program sentences are:''. \n The output format is: The score is:. ### \n The explanation is:''. ### \n For example 1: The natural language sentences are: Brandan is not southern. \n The translated logic program sentences are: -southern(brandan). \n The score is: 0.99. ### \n The explanation is: None. ### \n For example 2: The natural language sentences are: Brandan is southern. \n The translated logic program sentences are: -southern(brandan). \n The score is: 0.1. ### \n The explanation is: '-' error in logic program. ### \n For example 3: The natural language sentences are: Brandan is southern. \n The translated logic program sentences are: -southern(X). \n The score is: 0.1. ### \n The explanation is: The entities in the logic program should be Brandan. ### \n For example 4: The natural language sentences are: Brandan is emotional. \n The translated logic program sentences are: emotional(brandan). \n The score is: 0.99. ### \n  The explanation is: None. ### \n For example 5: The natural language sentences are: If someoneA is technical and zany then he is long, unless he is attractive. \n The translated logic program sentences are: technical(X), zany(X) :- attractive(X) / long(X). \n The score is: 0.99. ### \n The explanation is: None. ### \n For example 6: The natural language sentences are: If someoneA is technical and zany then he is long, unless he is attractive. \n The translated logic program sentences are: technical(X), zany(X) / long(X). \n The score is: 0.1. ### \n The explanation is: 'unless he is attractive.' is not translated into a formal language. ### \n For example 7: The natural language sentences are: If someoneA is aggressive then he is asleep, unless he is not short. \n The translated logic program sentences are: aggressive(X) : -short(X) / asleep(X) . \n The score is: 0.99. ### \n \n The explanation is: None. ### \n Note that you only need to output the semantic similarity score."
# 提示模型对ASP程序进行批判
Prompt_with_ASP_Critic = '###Task: \n You are an ASP program critic. You will be given a natural language sentence and the corresponding ASP program. However, the given ASP program may be an error. You need to verifier whether a given ASP is correct. In particular, it is necessary to determine whether the ASP program is semantically consistent with the given natural language. If you think the ASP is correct, then the output correct; if you think ASP is wrong, then you need to give an explanation .\n Input format: Natural language sentence: ''. \n ASP sentence: ''.  \n Output format: The result of verification is: ''. ### \n The verification explanation is:''.### \n. For example1: The input are: Natural language sentence: kingston is not courteous. \n ASP sentence: -courteous(kingston).\n The output is: The result of verification is: Correct. ### \n The verification explanation is: ASP and natural language are semantically consistent. ### \n For example2: The input are: Natural language sentence: If someoneA is different then he is not numerous, unless he is not confused or he is not financial. \n ASP sentence: numerous(X) :- different(X), (confused(X); financial(X)).\n The output is: The result of verification is: InCorrect. ### \n The verification explanation is: The main reason for the error is the translation error of the clause "unless he is not confused or he is not financial." There are also extra symbols "(",")" and ";". The correct translation should be "not -confused(X), not -financial(X).".### \n. Note that you only need to generate the criticized ASP program. \n'
Fine_Tune_Instruction = Prompt_with_Generate_ASP_Code  # 表示微调的提示, 微调模型的提示跟推理模型的提示一致

Yeliang_API_Key = "sk-hUac0FsEBWFPjF9wwRaxSnCyIHye7n89zPnylOjNJoh0BwGV"  # "sk-wYnDOGnqs7X62a2DEcFa8094B6384f2aAf12AfD88d1dC649", "sk-n7IWXtrI2d0JsnbuDa6dD8F090444fEaAaF1C101D899Fa3b"
Base_URL = "https://35.aigcbest.top/v1"  # "https://api.nhyun.top" #"https://35.aigcbest.top/v1"

Train_Dataset, Test_Datset = None, None
Label2Text = {'T': 'True', 'F': 'False', 'M': 'Unknown'}

llama3_8B_model, llama3_model_tokenizer = None, None
from unsloth import FastLanguageModel

Extract_Predicate_Pattern, Extract_Entity_Pattern, Translated_Sentence_Pattern = None, None, None
Predicate_Entity_ASP_Pattern, Repair_ASP_Program_Pattern = None, None
Repair_ASP_Program_Pattern_With_GPT4, Repair_Explanation_With_GPT4 = None, None
Semantic_Score_Pattern, Semantic_Explanation_Pattern, Grammar_Score_Pattern = None, None, None
Aligned_ASP_Pattern = None

if LLMs_Models_Choise == 'GPT3.5':
    # 定义调用LLAMA31模型生成ASP的抽取结果的模版
    Extract_Predicate_Pattern = "(?<=The predicate of the sentence is:).*?(?=Note|#|Instruction|1```1|```|The entities in the sentence is|\n)"  # 用于提取LLAMA3的输出结果
    Extract_Entity_Pattern = "(?<=The entities in the sentence is:).*?(?=Note|#|Instruction|Instantiation|1```1|```|The translated sentence is|\n)"  # 用于提取LLAMA3的输出结果
    Translated_Sentence_Pattern = "(?<=The translated sentence is:).*?(?=Note|#|Instruction|1```1|Final Answer|```|\n)"  # 用于提取LLAMA3的输出结果 # Final Answer:
    Aligned_ASP_Pattern = "(?<=The aligned formal logic program are:).*?(?=#|Note|###|Instruction|1```1|Final Answer|```|\n)"  # 用于提取LLAMA3的输出结果 # Final Answer:
    Semantic_Score_Pattern = "(?<=score is:).*?(?=#|The explanation is|The natural language sentences are|1```1|Final Answer|```|\n)"
    Semantic_Explanation_Pattern = "(?<=explanation is:).*?(?=#|Instruction|1```1|Final Answer|```|\n)"
    LLAMA31_Grammar_Score_Pattern = "(?<=score is:).*?(?=#|The ASP sentences are|1```1|Final Answer|```|\n)"


class Context:
    # get features/words from a string of space separated words
    def gen_feature(self, x):
        ret = []
        for term in str(x.string).split(' '):
            ret.append(parse_term(term))
        return ret


# ASP语言验证器
def ASP_Verifier_Solver(translated_context_sentences, Context_ASP_Text, opt=False):
    """
        Args:
            program (str): a string of ASP program
            opt (bool): if true, only optimal answer sets are returned
                        leave it to False when there is no weak constraint
        args of Control: args that will be passed to the solver.
            --models: the num of models that are output, would output all models when 0
            --opt-mode: optimization mode, opt or ignore, etc.
            --parallel-mode: num of parallel threads, set to 4 here.
        """
    Context_ASP_Text = translated_context_sentences + Context_ASP_Text
    clingo_control = Control(['--models=0', '--warn=none', '--opt-mode=optN', '-t', '4'])
    models = []
    try:
        clingo_control.add('base', [], Context_ASP_Text)
        clingo_control.ground([('base', [])], context=Context())
    except Exception as e:
        # breakpoint()
        # print('e={}'.format(e))
        return ["error", str(e)]
    if opt:
        clingo_control.solve(
            on_model=lambda model: models.append(model.symbols(atoms=True)) if model.optimality_proven else None)
    else:
        clingo_control.solve(on_model=lambda model: models.append(model.symbols(atoms=True)))
    models = [[str(atom) for atom in model] for model in models]
    return models


# 定义一个由GPT-4o实现的一个修复器
def Calling_GPT35_with_API(Repair_Instructions, To_repair_ASP_Code_sentence):
    client = OpenAI(base_url=Base_URL,
                    api_key=Yeliang_API_Key,
                    http_client=httpx.Client(base_url=Base_URL, follow_redirects=True,
                                             ),
                    )
    while_count01 = 0
    while while_count01 < 10:
        try:
            rsp = client.chat.completions.create(
                model='gpt-3.5-turbo',  # "gpt-4-turbo-preview",
                messages=[
                    {"role": "system", "content": Repair_Instructions},
                    {"role": "user", "content": To_repair_ASP_Code_sentence}
                ],
                temperature=0
            )
            result = rsp.choices[0].message.content
            return result
        except Exception as e:
            print(f"llm_send报错 {while_count01 + 1}次尝试: {e}")
            while_count01 += 1
        return ""




# 定义一个函数用于调用大模型翻译一个句子
def LLM_ASP_Solver_Single_Sentence(Dataset_Type,sentence_to_be_translated):

    Translated_ASP_Program_of_Sentence, Translated_ASP_Program_of_Sentence_list = '', ['']  # 用于存储当前翻译的ASP句子
    verifier_result = ''  # 用于存储ASP求解器验证结果
    Translated_Input_Format_String = ''  # 用于存储输入格式字符串
    sentence_to_be_translated = sentence_to_be_translated.lower()
    Translated_Input_Format_String = ' The natural language sentence to be translated is: ' + sentence_to_be_translated + '\n'

    while_Count0 = 0
    verifier_result = ''
    # 对于每个句子，可以考虑翻译多次，然后调用验证器进行验证，如果验证失败的作为微调的负样本，如果验证成功，则作为正样本；
    # 定义每个句子的翻译次数
    global Translation_Sentences_Number
    Total_Entities_in_ASP_Sentence_Lists, Total_Predicate_Used_in_Sentence_Lists, Total_Translated_ASP_Program_of_Sentence_Lists = [], [], []
    Total_Verfier_Result_Lists, Total_Translated_ASP_Program_of_Sentence_Lists, Total_Translated_Default_Logic_of_Sentence_Lists = [], [], []
    Translated_DL_Program_of_Sentence, Translated_ASP_Program_of_Sentence = '', ''
    Translation_Number01 = Translation_Sentences_Number  # 表示生成的候选ASP句子的数量，默认翻译次数为1
    while_Count01 = 0
    while True:
        if while_Count01 >= 10:  # 如果翻译次数(包含翻译正常和翻译错误的情况)达到上限，并且文法验证不出错，则跳出循环
            print('句子翻译次数达到上限！翻译结果错误！')
            if len(Total_Verfier_Result_Lists) != 0 and len(Total_Translated_ASP_Program_of_Sentence_Lists) != 0:
                break
            else:
                Total_Verfier_Result_Lists = [['error']]  # 将验证结果添加到列表中
                break
        while_Count01 = while_Count01 + 1
        # 如果翻译次数达到上限，并且文法验证不出错，则跳出循环
        if len(Total_Translated_ASP_Program_of_Sentence_Lists) >= Translation_Number01:
            print('候选asp句子翻译次数达到上限！翻译的候选asp句子列表为：{}'.format(Total_Translated_ASP_Program_of_Sentence_Lists))
            break
        # 第一步：调用大模型先讲事实/规则翻译成ASP.  演绎步骤先抽取谓词，再翻译出多个候选的句子
        Models_Results = ''
        Models_Results = Calling_GPT35_with_API(Prompt_with_Generate_ASP_Code, Translated_Input_Format_String)
        Models_Results = Models_Results.replace('\n','')
        if len(Models_Results)<10:
            continue
        Models_Results = Models_Results + '###' if Models_Results[-1]!='#' else Models_Results
        # 解析大模型输出结果
        # 第一步先抽取出所有的答案
        Translated_DL_Program_of_Sentence_list = re.findall(Translated_Sentence_Pattern, Models_Results)
        if len(Translated_DL_Program_of_Sentence_list) == 0:
            print('抽取出翻译的形式句子失败，重新翻译！Translated_Sentence_Pattern ={}, Models_Results={}'.format(
                Translated_Sentence_Pattern, Models_Results))
            continue

        # 根据正则表达式提取Models_Results中The translated default logic of the sentence is:与.之间的句子
        while_Count01 = while_Count01 + 1
        if len(Translated_DL_Program_of_Sentence_list) != 0 and len(Translated_DL_Program_of_Sentence_list[0]) > 2:
            dl_sentence = Translated_DL_Program_of_Sentence_list[0] + '.'
            Translated_DL_Program_of_Sentence = dl_sentence.replace('#', '').replace('. ', '.').replace(',.','.').replace('..', '.')
        else:
            print('第一步中翻译输出的格式错误，重新翻译！while_Count01={}'.format(while_Count01))
            continue

        # 如果生成的是缺省规则，则需要将其转换成ASP规则
       
        Translated_ASP_Program_of_Sentence = Translated_DL_Program_of_Sentence
        Translated_ASP_Program_of_Sentence = Translated_ASP_Program_of_Sentence.replace('¬', '-')

        # 第二步：调用符号验证器对单个句子进行验证 translated_context_asp_sentences
        verifier_result = ''
        if Dataset_Type == 'question':
            verifier_result = ASP_Verifier_Solver('', Translated_ASP_Program_of_Sentence,opt=False)  # 如果验证的是问题，则验证当前翻译的asp句子
        else:  # 如果验证的是上下文，则需要将上下文中的asp句子进行合并
            verifier_result = ASP_Verifier_Solver('', Translated_ASP_Program_of_Sentence,opt=False)

        if len(verifier_result) == 0:
            print('验证结果为空，重新翻译！while_Count01={}'.format(while_Count01))
        else:
            break

        # 如果验证结果不为空，则说明通过了文法检测，再对生成的句子进行语义一致性评估

        print('第{}次翻译,对候选的asp进行验证，翻译的自然语言:{},生成的dl句子为:{},翻译生成的asp句子:{}（验证结果为当前形式化上下文所产生的回答集）：{}'.format(while_Count01, sentence_to_be_translated, Translated_DL_Program_of_Sentence, Translated_ASP_Program_of_Sentence, verifier_result))

    return Translated_ASP_Program_of_Sentence


from collections import namedtuple

_TTTB = namedtuple("ASPTranslationNode", "translated context asp sentences")



# 定义一个框架主函数
# fine_tune_file1: 用于存储微调模型的数据 ， 从训练集中选择通过验证的数据样本
# 可以考虑增加推理时间， 讲搜索策略和奖励模型（验证器、符号求解器）结合起来。搜索：同时生成多个候选的ASP上下文，然后最后根据多数投票的原则给出最终答案。
def LLM_ASP_Solver(Sample_number, Question_List, Facts, Rules, llama3_8B_model, llama3_model_tokenizer, Dataset_Type,
                   fine_tune_f2, repair_f3, Origin_Question_Label_Lists):
    Context_List, Facts_List, Rules_Lists = [], [], []

    
    #-------------------------------------------------#
    Question_ASP_List,solver_result_answer_set=[],[]
    translated_context_sentences = ''


    Context = Facts + Rules # 同时翻译事实和规则

    Translated_ASP_Program_of_Context = LLM_ASP_Solver_Single_Sentence(Dataset_Type, Context)


    # 调用符号求解器求出所有扩展
    solver_result_answer_set = ASP_Verifier_Solver(Translated_ASP_Program_of_Context, '', opt=False)
    
    Questions_string = ''
    for question_key in range(len(Question_List)):
        Questions_string = Questions_string + Question_List[question_key]

    Translated_ASP_Program_of_question = LLM_ASP_Solver_Single_Sentence(Dataset_Type, Questions_string)

    Question_ASP_List = Translated_ASP_Program_of_question.split('.') if '.' in Translated_ASP_Program_of_question else [Translated_ASP_Program_of_question]
    Question_ASP_List = [q.strip() for q in Question_ASP_List if q.strip()]  # 去除空字符串和空白字符

    # 遍历问题
    LLMs_Generted_Label_List = []  # 用于存储每个问题的标签
    for question_key in range(len(Question_ASP_List)):
        
        if len(Question_ASP_List)==0:
            LLMs_Generted_Label_List.append(['M'])
        else:
            question_sentence = Question_ASP_List[question_key]
            if len(question_sentence)==0:
                LLMs_Generted_Label_List.append(['M'])
                continue
            predicate_question_label = Generate_Label_with_Skeptical_Credulous(solver_result_answer_set,
                                                                               question_sentence, Reasoning_Mode)
            LLMs_Generted_Label_List.append([predicate_question_label])

    # 返回翻译好的上下文和问题
    return translated_context_sentences, solver_result_answer_set, Question_ASP_List, LLMs_Generted_Label_List


# 定义一个函数，用于根据回答集对问题进行推理 Reasoning_Flag表示是可怀疑推理还是轻信推理
def Generate_Label_with_Skeptical_Credulous(answer_sets, question, Reasoning_Mode):
    '''
    answer_sets: 回答集
    question: 问题
    Reasoning_Mode: 推理模式
    '''
    question_label = ''
    Extract_predicate = re.compile(r'(.*?)[(]', re.S)  #
    Extract_entity = re.compile(r'[(](.*?)[)]', re.S)  # 用于提取LLAMA3的输出结果
    # 如果回答集错误，则该标签输出为‘M'
    if 'error' in answer_sets:
        question_label = 'M'
        return question_label
    question = question.replace(' ', '')
    # 提取原始问题的谓词
    question_predicate_list = re.findall(Extract_predicate, question) if '(' in question else ['']
    question_predicate_text = question_predicate_list[0]
    if question_predicate_text == '':
        question_label = 'M'
        return question_label
    question_negation_text = '-' + question_predicate_text  # 生成问题的否定形式
    question_negation_text = question_negation_text.replace('--', '')  # 去掉重复的负号
    skeptical_question_label_Flag_List = []  # 用于标记问题是否在回答集中
    skeptical_question_negation_label_Flag_List = []  # 用于标记否定问题是否在回答集中
    skeptical_question_unknown_label_Flag_List = []  # 用于标记否定问题是否在回答集中

    credulous_question_label_Flag_List = []  # 用于标记问题是否在回答集中
    credulous_question_negation_label_Flag_List = []  # 用于标记否定问题是否在回答集中

    if Reasoning_Mode == 'skeptical':  # 可怀疑推理下生成问题标签
        # 遍历每个回答集
        # 遍历每个回答集
        for answer_set in answer_sets:
            # 遍历每个回答集中的元素
            for fact_key in range(len(answer_set)):  # 事实形如happy(toby)
                # 根据正则表达式抽取出事实中的谓词

                generate_predicate_list = re.findall(Extract_predicate, answer_set[fact_key]) if '(' in question else [
                    '']  # 返回的是列表
                generate_entitie_list = re.findall(Extract_entity,
                                                   answer_set[fact_key]) if '(' and ')' in question else ['']
                generate_predicate, generate_entitie = '', ''
                if len(generate_predicate_list) != 0 and len(generate_entitie_list) != 0:
                    generate_predicate = generate_predicate_list[0].replace(' ', '')
                    generate_entitie = generate_entitie_list[0].replace(' ', '')
                # 获取回答集中的谓词，如果和问题一致，则问题标签重置为True, 否则为False
                # 如果和否定问题一致，则否定问题标签重置为True, 否则为False
                if generate_predicate == question_predicate_text:
                    skeptical_question_label_Flag_List.append('True')
                    break
                if generate_predicate == question_negation_text:
                    skeptical_question_negation_label_Flag_List.append('True')
                    break
                if int(fact_key) == len(answer_set) - 1:  # 如果遍历到最后一个元素，即该回答集既不包含谓词，也不包含谓词的假。则标签为M
                    skeptical_question_unknown_label_Flag_List.append('Unknown')
                    break

        # 如果回答集中既包含问题又包含问题的非，则标签为M.
        if 'True' in skeptical_question_label_Flag_List and 'True' in skeptical_question_negation_label_Flag_List:
            question_label = 'M'
        elif len(skeptical_question_label_Flag_List) == 0 and len(
                skeptical_question_negation_label_Flag_List) == 0 and 'Unknown' in skeptical_question_unknown_label_Flag_List:
            question_label = 'M'
        elif 'True' in skeptical_question_label_Flag_List and 'True' not in skeptical_question_negation_label_Flag_List and 'Unknown' not in skeptical_question_unknown_label_Flag_List:
            question_label = 'T'
        elif 'True' not in skeptical_question_label_Flag_List and 'True' in skeptical_question_negation_label_Flag_List and 'Unknown' not in skeptical_question_unknown_label_Flag_List:
            question_label = 'F'
        else:
            question_label = 'M'

    elif Reasoning_Mode == 'credulous':
        # 轻信推理
        # 遍历每个回答集
        for answer_set in answer_sets:
            # 遍历每个回答集中的元素
            for fact in answer_set:  # 事实形如happy(toby)
                # 根据正则表达式抽取出事实中的谓词

                generate_predicate_list = re.findall(Extract_predicate, fact) if '(' in question else ['']  # 返回的是列表
                generate_entitie_list = re.findall(Extract_entity, fact) if '(' and ')' in question else ['']
                generate_predicate, generate_entitie = '', ''
                if len(generate_predicate_list) != 0 and len(generate_entitie_list) != 0:
                    generate_predicate = generate_predicate_list[0].replace(' ', '')
                    generate_entitie = generate_entitie_list[0].replace(' ', '')
                # 获取回答集中的谓词，如果和问题一致，则问题标签重置为True, 否则为False
                # 如果和否定问题一致，则否定问题标签重置为True, 否则为False
                if generate_predicate == question_predicate_text:
                    credulous_question_label_Flag_List.append('True')
                    continue
                if generate_predicate == question_negation_text:
                    credulous_question_negation_label_Flag_List.append('True')
                    continue
        # 如果回答集中既包含问题又包含问题的非，则标签为M.
        if 'True' in credulous_question_label_Flag_List:
            question_label = 'T'
        elif 'True' in credulous_question_negation_label_Flag_List:
            question_label = 'F'
        else:
            question_label = 'M'

    else:
        print('推理模式错误！')

    return question_label


def Evaluation_Train_Test_Data(Read_Test_Data_file, Write_fine_tune_file_path, Write_Result_file_path,
                               Expert_Iterative_Number, llama3_8B_model, llama3_model_tokenizer, Dataset_Type):
    fine_tune_f2, repair_f3 = None, None
    with open(Read_Test_Data_file, 'r') as f0, open(Write_Result_file_path, 'a',
                                                    encoding='utf-8') as result_f1:  # , open(Write_fine_tune_file_path, 'a', encoding='utf-8') as fine_tune_f2: #, open(Write_Repair_file_path, 'a', encoding='utf-8') as repair_f3:
        Total_Question_label_List = []
        Total_LLMs_Generted_Label_List = []
        Total_count01 = 1
        Test_Extension_Example_Dict = {}
        Test_Extension_Example_Dict01 = {2: 0, 1: 0, 4: 0, 3: 0, 5: 0} if OOD_Flag == False else {6: 0, 8: 0, 10: 0, 12: 0, 16: 0}
        Each_Extension_Sample_Number = 40 if Dataset_Type == 'test' else 200
        for line in f0:

            global Answer_Set_List, Soft_Answer_Set_List, Prerequisite_Conclusion_Consistent_Facts_Dict
            global Each_Example_chatgpt_Number
            Each_Example_chatgpt_Number = 0
            Write_Result_Dict = {}  # 该字典用于存储最终的结果
            LLMs_Generted_Label_List = []
            LLMs_Generted_Answer_Set_Explanation_List = []
            js = json.loads(line.strip())
            # 将数据集划分成训练/验证/测试
            # print(json.dumps(js, ensure_ascii=False))
            Sample_number = js['Sample_number']
            Origin_Facts = js['Origin_Facts']
            Facts_number = js['Facts_number']  # 计算缺省理论中事实的个数
            Defalut_Rules = js['Defalut_Rules']
            # Noise_Facts_Lists = js['Noise_Facts_Lists']
            NL_Origin_Facts = js['NL_Origin_Facts']
            NL_Defalut_Rules = js['NL_Defalut_Rules']
            # NL_Noise_Facts_Lists = js['NL_Noise_Facts_Lists']
            # Noise_Default_Rules_Lists = js['Noise_Default_Rules_Lists']
            # NL_Noise_Default_Rule_Lists = js['NL_Noise_Default_Rule_Lists']
            Origin_ASP_extension_number = js['Origin_ASP_extension_number']
            Origin_Question_Text_Lists = js['Origin_Question_Text_Lists']
            NL_Origin_Question_Text = js['NL_Origin_Question_Text']
            Origin_Question_Label_Lists = js['Origin_Question_Label_Lists']
            Origin_Question_proof_List = js['Origin_Question_proof_List']
            NL_Origin_Question_proof_Text = js['NL_Origin_Question_proof_Text']

            # # 每个扩展数量的样本测试20个
            if Origin_ASP_extension_number not in Test_Extension_Example_Dict.keys():
                Test_Extension_Example_Dict[Origin_ASP_extension_number] = 1
                if Test_Extension_Example_Dict[Origin_ASP_extension_number] <= Test_Extension_Example_Dict01[Origin_ASP_extension_number]:
                    Total_count01 = Total_count01 + 1
                    continue
            else:
                if Test_Extension_Example_Dict[Origin_ASP_extension_number] >= Each_Extension_Sample_Number:
                    continue
                else:
                    Test_Extension_Example_Dict[Origin_ASP_extension_number] = Test_Extension_Example_Dict[Origin_ASP_extension_number] + 1
                    if Test_Extension_Example_Dict[Origin_ASP_extension_number] <= Test_Extension_Example_Dict01[Origin_ASP_extension_number]:
                        Total_count01 = Total_count01 + 1
                        continue

            translated_context_sentences, solver_result_answer_set, Question_ASP_List, LLMs_Generted_Label_List = LLM_ASP_Solver(
                Sample_number, NL_Origin_Question_Text, NL_Origin_Facts, NL_Defalut_Rules, llama3_8B_model,
                llama3_model_tokenizer, Dataset_Type, fine_tune_f2, repair_f3, Origin_Question_Label_Lists)

            Total_count01 = Total_count01 + 1

            Write_Result_Dict['Sample_number'] = Sample_number  # 样本个数
            Write_Result_Dict['Origin_ASP_extension_number'] = Origin_ASP_extension_number
            Write_Result_Dict['NL_Origin_Facts'] = NL_Origin_Facts
            Write_Result_Dict['NL_Defalut_Rules'] = NL_Defalut_Rules
            Write_Result_Dict['Generated_ASP_Facts_Rules'] = translated_context_sentences
            Write_Result_Dict['Generated_ASP_Questions'] = Question_ASP_List
            Write_Result_Dict['NL_Origin_Question_Text'] = NL_Origin_Question_Text
            Write_Result_Dict['Origin_Question_Label_Lists'] = Origin_Question_Label_Lists
            Write_Result_Dict['Answer_set'] = solver_result_answer_set
            Write_Result_Dict['LLMs_Generated_Question_Skeptical_Label_Lists'] = LLMs_Generted_Label_List
            Write_Result_Dict['LLMs_Generated_Question_Credulous_Label_Lists'] = LLMs_Generted_Label_List

            Write_Result_Dict['Origin_Question_proof_List'] = Origin_Question_proof_List
            Write_Result_Dict['NL_Origin_Question_proof_Text'] = NL_Origin_Question_proof_Text
            Write_Result_Dict['LLMs_Generated_Question_Explanation_Lists'] = ''
            Write_Result_Dict['Each_Example_chatgpt_Number'] = Each_Example_chatgpt_Number

            Write_Result_Dict['LLMs_Repose'] = ''
            Write_Result_Dict = json.dumps(Write_Result_Dict, ensure_ascii=False)
            result_f1.write(Write_Result_Dict + '\n')

            print('第{}个样本完成！生成的标签为:{},真实的标签为:{}'.format(str(Sample_number), LLMs_Generted_Label_List,
                                                                          Origin_Question_Label_Lists))

        accuracy = accuracy_score(Total_Question_label_List, Total_LLMs_Generted_Label_List)  # 计算准确率
        F1 = f1_score(Total_Question_label_List, Total_LLMs_Generted_Label_List, average='macro')
        print('accuracy={},F1={}'.format(accuracy, F1))


# 定义一个函数，用于获取读取文件和输出文件路径
def Get_Read_and_Write_file_path(Expert_Iterative_Number, Dataset_Type):
    Read_Data_file = read_file_path + Reasoning_Mode + '_multiNMR_' + Dataset_Type + '_' + str(
        ASP_extension_number_Min) + '_' + str(ASP_extension_number_Max) + '_balance' + '.json'

    # 用于保存样本最终的求解的结果 LLMs_Models_Choise:['DeepSeek'] ;Dataset_Type:['test', 'train'], Reasoning_Mode:['skeptical', 'credulous']
    Write_Result_file_path = write_file_path + 'LLM_ASP_Solver_Iterative_DL_Tree' + str(
        Expert_Iterative_Number) + '_' + LLMs_Models_Choise + '_' + 'ASP_Number_' + str(Translation_Sentences_Number) + '_FNL_' + Formal_Natural_Language + '_Repair_' + str(
        Iterative_Repair_Flag) + '_Aligned_' + str(Aligned_Rules_Flag) + '_result_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type + '_' + str(
        ASP_extension_number_Min) + '_' + str(ASP_extension_number_Max) + '_balance' + '.json'
    # 用于保存微调的训练集
    Write_fine_tune_file_path = ''  # write_file_path + LLMs_Models_Choise + '_ASP_Solver_Iterative_DL_Tree'+ str(Expert_Iterative_Number) + '_' + LLMs_Models_Choise + '_fine_tune_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + '.json'
    # 读取用于微调模型的数据
    Read_fine_tune_Data_file = ''  # write_file_path + LLMs_Models_Choise + '_ASP_Solver_Iterative_DL_Tree'+ str(Expert_Iterative_Number) + '_' + LLMs_Models_Choise + '_fine_tune_on_' + Dataset_Name + '_' + Reasoning_Mode + '_' + Dataset_Type +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + '.json'

    return Read_Data_file, Write_Result_file_path, Write_fine_tune_file_path, Read_fine_tune_Data_file  # , Write_Repair_file_path_ASP_Repair, Read_Repair_Data_file_ASP_Repair


if __name__ == '__main__':
    # 对模型框架进行专家迭代
    Expert_Iterative_Number = 0  # 专家迭代次数，从0开始
    # Dataset_Type表示当前读取的是测试集还是验证集，test表示测试集，train表示训练集
    Dataset_Type = 'test'  # 先评估测试集

    # 第一步先评估测试集
    # 获取读取文件和输出文件的路径， 此时读取的是测试集
    Read_Data_file, Write_Result_file_path, Write_fine_tune_file_path, Read_fine_tune_Data_file = Get_Read_and_Write_file_path(
        Expert_Iterative_Number, Dataset_Type)
    # 加载初始模型
    Test_llama3_8B_model, Test_llama3_model_tokenizer = None, None
    # 读取数据集，并进行测试, 如果只是测试集，则只生成测试集的结果。 如果是训练集，则同时生成微调样本和结果。
    # Read_Test_Data_file表示测试数据集的路径，Write_file_path02用于保存测试集输出结果的路径
    Evaluation_Train_Test_Data(Read_Data_file, Write_fine_tune_file_path, Write_Result_file_path,
                               Expert_Iterative_Number, Test_llama3_8B_model, Test_llama3_model_tokenizer,
                               Dataset_Type='test')
