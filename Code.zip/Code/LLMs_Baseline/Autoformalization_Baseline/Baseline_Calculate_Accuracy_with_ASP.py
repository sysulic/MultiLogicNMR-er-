"""
通过评估指标计算大模型产生的结果，
"""
import copy
import random
import sys
import re
import httpx

sys.path.append('/home/yeliangxiu/Projects/LLM_ASP_NeSY_Solver/Datasets')
import difflib
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
import json
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
import torch
from clingo.control import Control
from clingo.symbol import parse_term

from trl import SFTTrainer, DataCollatorForCompletionOnlyLM
from transformers import TrainingArguments
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
import json
max_seq_length = 204800
Reasoning_Mode = 'skeptical' # [credulous, skeptical]
Dataset_Category = 'test' # ['train', 'dev', 'test']0
Fine_Tune_Iterative_Number = 0 # 用于指示是微调第几次迭代00, 1表示是第一次迭代，2表示是第二次迭代，以此类推
Translation_Sentences_Number = 3 # 表示每个句子00的翻译次数
Aligned_Rules_Flag = False # 表示是否使用对齐模块
Iterative_Repair_Flag = False # 用于指0示是， True表示直接修复， False表示间接修复
Formal_Natural_Language = 'ASP' # ['ASP','DL']00000
Reasoning_With_Similarity = False # 用于指示是否是基于相似度进行对问题在回答集上推理还是直接使用大模型对问题进行推理
OOD_Flag, NL_Flag = False, True
Dataset_Type = None # 表示数据集  ['MultiLogicNMR_OOD', 'MultiLogicNMR_NL', 'MultiLogicNMR']
if OOD_Flag == True:
    Dataset_Type = "MultiLogicNMR_OOD"
elif NL_Flag == True:
    Dataset_Type = "MultiLogicNMR_NL"
else:
    Dataset_Type = "MultiLogicNMR"

read_file_path = '/home/yeliangxiu/Projects/LLM_00ASP_NeSY_Solver/Datasets/' + Dataset_Type + '/' + Reasoning_Mode + '/'
write_file_path = '/home/yeliangxiu/Projects/LLM_ASP_NeSY_Solver/Experiment/Results/'
ASP_extension_number_Min, ASP_extension_number_Max = 1,5 #用于对回答集进行过滤
if OOD_Flag == True:
    ASP_extension_number_Min, ASP_extension_number_Max = 6,16

LLMs_Models_Choise = "Gemma3_27B" # ['GPT3.5','GPT4o-mini','LLAMA31','DeepSeek_R1','o3-mini','Gemma3_27B','Mistral_7B']
read_file_path02 = ''
if Aligned_Rules_Flag == True and Iterative_Repair_Flag == False:
    read_file_path02 = write_file_path + 'LLM_ASP_Solver_Iterative_DL_Tree'+ str(Fine_Tune_Iterative_Number) + '_' + LLMs_Models_Choise + '_' + 'ASP_Number_' + str(Translation_Sentences_Number) + '_FNL_' + Formal_Natural_Language + '_Repair_' + str(Iterative_Repair_Flag) + '_Aligned_' + str(Aligned_Rules_Flag) + '_result_on_' + Dataset_Type + '_' + Reasoning_Mode + '_' + Dataset_Category +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + '.json'
elif Aligned_Rules_Flag == True and Iterative_Repair_Flag == True:
    read_file_path02 = write_file_path + 'LLM_ASP_Solver_Iterative_DL_Tree'+ str(Fine_Tune_Iterative_Number) + '_' + LLMs_Models_Choise + '_' + 'ASP_Number_' + str(Translation_Sentences_Number) + '_FNL_' + Formal_Natural_Language + '_Repair_' + str(Iterative_Repair_Flag) + '_Aligned_' + str(Aligned_Rules_Flag) + '_result_on_' + Dataset_Type + '_' + Reasoning_Mode + '_' + Dataset_Category +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + '.json'
elif Aligned_Rules_Flag == False and Iterative_Repair_Flag == True:
    read_file_path02 = write_file_path + 'LLM_ASP_Solver_Iterative_DL_Tree'+ str(Fine_Tune_Iterative_Number) + '_' + LLMs_Models_Choise + '_' + 'ASP_Number_' + str(Translation_Sentences_Number) + '_FNL_' + Formal_Natural_Language + '_Repair_' + str(Iterative_Repair_Flag) + '_Aligned_' + str(Aligned_Rules_Flag) + '_result_on_' + Dataset_Type + '_' + Reasoning_Mode + '_' + Dataset_Category +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + '.json'
elif Aligned_Rules_Flag == False and Iterative_Repair_Flag == False:
    read_file_path02 = write_file_path + 'LLM_ASP_Solver_Iterative_DL_Tree'+ str(Fine_Tune_Iterative_Number) + '_' + LLMs_Models_Choise + '_' + 'ASP_Number_' + str(Translation_Sentences_Number) + '_FNL_' + Formal_Natural_Language + '_Repair_' + str(Iterative_Repair_Flag) + '_Aligned_' + str(Aligned_Rules_Flag) + '_result_on_' + Dataset_Type + '_' + Reasoning_Mode + '_' + Dataset_Category +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + '.json'
import warnings
warnings.filterwarnings("ignore")

Label_Dict = {'F':[0],'T':[1],'M':[2]}



# 定义一个函数，用于评估二个句子集合的相似匹配度。
def Similarity_Explaination(Generation_Explain_list, Explaination_list):
    Predict_Explain_Number = len(Generation_Explain_list)
    # 遍历所有生成的句子，
    Explaination_list01 = copy.deepcopy(Explaination_list)
    # 遍历真是的扩展列表，一个标签可能存在多个扩展
    avager_similarity_list = []
    for key00 in range(len(Explaination_list01)):
        Correct_Explain_Number = len(Explaination_list[key00])
        Explaination_list02 = Explaination_list01[key00]
        similarity_matrix = [] # 存储所有生成句子在一个扩展下的相似度
        for key01 in range(len(Generation_Explain_list)):
            similarity_list01= [] # 存储单个句子在扩展的相似度
            for key02 in range(len(Explaination_list02)):
                similarity = difflib.SequenceMatcher(None, Generation_Explain_list[key01], Explaination_list02[key02]).ratio()
                similarity_list01.append(similarity)
            similarity_matrix.append(similarity_list01)

        # 遍历相似性矩阵，计算平均匹配准确率。
        total_similarity01 = 0 # 表示生成的解释相对于某个真是解释的匹配准确率。
        for similarity_list in similarity_matrix:
            max_similarity = max(similarity_list)
            total_similarity01 = total_similarity01 + max_similarity if max_similarity>0.5 else total_similarity01
        avager_similarity = total_similarity01 / Correct_Explain_Number
        avager_similarity_list.append(avager_similarity)

        # 在根据相似性矩阵算出该扩展的
    # 返回生成解释与真实扩真相似度最大的值
    max_avager_similarity = max(avager_similarity_list)
    return max_avager_similarity



def Read():
    with open(read_file_path02, 'r',encoding='utf-8') as f0:
        Total_Question_label_List = []
        Total_LLMs_Generted_Label_List = []
        Extension_Question_Label_Dict = {} # 按照扩展数划分，来计算分值。
        Extension_LLMs_Generted_Label_Dict = {}
        Total_count01 = 1
        Test_Extension_Example_Dict ={}

        for line in f0:
            print('Total_count01={}'.format(Total_count01))
            js = json.loads(line.strip())
            Sample_number = js['Sample_number']
            Origin_ASP_extension_number = js['Origin_ASP_extension_number']
            NL_Origin_Question_Text = js['NL_Origin_Question_Text']
            Origin_Question_Label_Lists = js['Origin_Question_Label_Lists']
            LLMs_Generated_Question_Label_Lists = js['LLMs_Generated_Question_Skeptical_Label_Lists']
            NL_Origin_Question_proof_Text = js['NL_Origin_Question_proof_Text']
            LLMs_Generated_Question_Explanation_Lists = js['LLMs_Generated_Question_Explanation_Lists']

            # 每个扩展数量的样本测试20个
            if Origin_ASP_extension_number not in Test_Extension_Example_Dict.keys():
                Test_Extension_Example_Dict[Origin_ASP_extension_number] = 1
            else:
                Test_Extension_Example_Dict[Origin_ASP_extension_number] = Test_Extension_Example_Dict[Origin_ASP_extension_number] + 1

            if Origin_ASP_extension_number not in Extension_Question_Label_Dict.keys():
                Extension_Question_Label_Dict[Origin_ASP_extension_number] = []
                Extension_LLMs_Generted_Label_Dict[Origin_ASP_extension_number] =[]

            # 遍历该样本的标签列表
            for label, predict_label in zip(Origin_Question_Label_Lists, LLMs_Generated_Question_Label_Lists):
                Total_Question_label_List.extend(Label_Dict[label[0]])
                Total_LLMs_Generted_Label_List.extend(Label_Dict[predict_label[0]])

                Extension_Question_Label_Dict[Origin_ASP_extension_number].extend(Label_Dict[label[0]])
                Extension_LLMs_Generted_Label_Dict[Origin_ASP_extension_number].extend(Label_Dict[predict_label[0]])
            Total_count01 = Total_count01 + 1
        print('Test_Extension_Example_Dict={}'.format(Test_Extension_Example_Dict))

        accuracy = accuracy_score(Total_Question_label_List, Total_LLMs_Generted_Label_List)  # 计算准确率
        F1 = f1_score(Total_Question_label_List, Total_LLMs_Generted_Label_List, average='macro')
        print('The total accuracy={},The total F1={}'.format(accuracy, F1))


        # 遍历扩展字典，分别计算在不同扩展下产生的值
        for key in Extension_Question_Label_Dict.keys():
            label_list = Extension_Question_Label_Dict[key]
            predict_label_list= Extension_LLMs_Generted_Label_Dict[key]
            accuracy = accuracy_score(label_list, predict_label_list)  # 计算准确率
            F1 = f1_score(label_list, predict_label_list, average='macro')
            print('The accuracy on extension {} is {},The F1 on extension {} is {}'.format(int(key),accuracy, int(key), F1))

if __name__ == '__main__':
    Read()