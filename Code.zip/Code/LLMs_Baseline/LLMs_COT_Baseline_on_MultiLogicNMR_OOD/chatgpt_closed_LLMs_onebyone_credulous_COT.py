"""
新提出的评估指标方法，利用语言模型对证明树进行打分，
"""
import copy
import sys
import re
import httpx
# import torch
sys.path.append('../../Dataset')
import difflib
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
import json
Reasoning_Mode = 'credulous' # [credulous, skeptical]
Dataset_Category = 'test' # ['train', 'dev', 'test']
Zero_or_Few_Shot = 'Few_Shot_COT' # ['Zero_Shot','Few_Shot', 'Zero_Shot_COT','Few_Shot_COT', 'COT_Extensions', 'COT_Symbolic']
OOD_Flag = True
OOD_Data_Path = "OOD_Datasets" if OOD_Flag == True else ''
OOD_read_filename = "_ood" if OOD_Flag == True else ''
OOD_write_filename = "ood_" if OOD_Flag == True else ''
read_file_path = None
LLMs_Generate = False
LLMs_Generate_Datasets = 'GPT4_LLMs_Generated_' if LLMs_Generate == True else ''
if OOD_Flag == True:
    read_file_path = './../../../../Automated_Construct_MultiNMR/Datasets/' + OOD_Data_Path + '/'
elif LLMs_Generate == True:
    read_file_path = './../../../../Automated_Construct_MultiNMR/LLMs_Generate_Datasets/' + Reasoning_Mode + '/'
else:
    read_file_path = './../../../../Automated_Construct_MultiNMR/Datasets/' + Reasoning_Mode + '/'

write_file_path = './../../../../Automated_Construct_MultiNMR/Experimens/LLMs_Results/'
ASP_extension_number_Min, ASP_extension_number_Max = 1,5 #用于对回答集进行过滤
if OOD_Flag == True:
    ASP_extension_number_Min, ASP_extension_number_Max = 6,16
LLMs_Models_Choise = "GPT3.5" #['GPT3.5','GPT4','Claude','Gemma_7B','Mistral_7B']
Read_Data_file = read_file_path + LLMs_Generate_Datasets + Reasoning_Mode + '_multiNMR_'+ Dataset_Category +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + OOD_read_filename + '_New.json'
Write_file_path02 = write_file_path + Zero_or_Few_Shot + '_' + LLMs_Models_Choise + '_result_on_' + OOD_write_filename + LLMs_Generate_Datasets + Reasoning_Mode + '_multiNMR_'+ Dataset_Category +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + '_New.json'


Label_Dict = {'F':[0],'T':[1],'M':[2]}
# 提示要求同时回答多个问题。
# 提示要求逐个回答问题。
Zero_Shot_Skeptical_Instruction = 'Task Description: \n Given contexts and question, You need to generate answer labels for questions in a given context. \n  If the question can be inferred under all reasoning paths based on the context, and the negation of the question cannot be inferred under all reasoning paths based on the context, the answer label of the question is: "True";  \n if the negation of the question can be inferred under all reasoning path based on the context, and the question cannot be inferred under all reasoning path based on the context, the answer label of the question is: "False";  \n If the question and the negation of the question cannot be deduced under a certain reasoning path based on the context, the answer label of the question is: "Unknown". The input format is Context: ". Question:". You must generate answer labels for the question. The output format is: The answer label of the question is:".  \n Note that you only need to generate the answer label for the question without giving an explanation or justification. Please read the context carefully and answer the questions. '
Zero_Shot_Credulous_Instruction = 'Task Description: \n  Given contexts and question, You need to generate answer labels for questions in a given context.  \n If the question can be inferred under a certain reasoning path based on the context, the answer label of the question is: "True"; \n  if the negation of the question can be inferred under a certain reasoning path based on the context, the answer label of the question is: "False"; \n  If the question and the negation of the question both cannot be deduced under all reasoning path based on the context, the answer label of the question is: "Unknown".  \n The input format is Context: ". Question:". The output format is: The answer label of question is:". You must generate answer labels for the question. \n  Note that you only need to generate the answer label for the question, without giving an explanation or justification. Please read the context carefully and answer the questions. '
Three_Few_Shot_Skeptical_Instruction = 'Task Description: \n  Given contexts and question, You need to generate answer labels for questions in a given context. The context contains facts and a default rule, The default rule format is: If A then B, unless C. The A is the prerequisite, the B is the conclusion, and the C is called the justifications. The "If A then B, unless C." means that If the preconditions A are in the facts, and the justifications C is not in the facts, then you can deduce the conclusion B. The answers to the questions are labeled "True", "False" and "Unknown".  \n If the question can be inferred under all reasoning paths based on the context, and the negation of the question cannot be inferred under all reasoning paths based on the context, the answer label of the question is: "True";  \n if the negation of the question can be inferred under all reasoning path based on the context, and the question cannot be inferred under all reasoning path based on the context, the answer label of the question is: "False";  \n If the question and the negation of the question cannot be deduced under a certain reasoning path based on the context, the answer label of the question is: "Unknown".  \n Each context has a question, and the input format is Context: ". Question:". You must generate answer labels for each question. The output format is: The answer label of the question is:".  \n For example, Context: Grant is not impartial. Grant is not misty. Grant is not gentle. Grant is not lively. Grant is thankful.Grant is willing. Grant is red. Grant is medical. Grant is legal. Grant is not expensive. Grant is not crazy. If someoneA is not lively and not gentle then he is not adorable ,unless he is not annoying. If someoneA is thankful then he is critical ,unless he is not better. If someoneA is willing and not crazy then he is not aware ,unless he is not smoggy. If someoneA is legal then he is not annoying ,unless he is not adorable. If someoneA is not annoying then he is political,unless he is not alive or he is not adorable. If someoneA is not aware then he is not smoggy ,unless he is not aware. If someoneA is not misty then he is safe, unless he is not annoying. If someoneA is not expensive and not impartial then he is not mean, unless he is orange or he is safe.If someoneA is medical then he is not odd, unless he is optimistic or he is not smoggy. If someoneA is red then he is adventurous, unless he is not busy or he is not aware.  \n If the Question is: Grant is adorable.  \n Then the answer label for the question is: Unknown;  \n If the question is: Grant is not critical.  \n Then the answer label for the question is: False;  \n If the question is: Grant is not odd. \n  Then the answer label for the question is: True.  \n For example, Context: Jessie is horrible. Jessie admire Marion. Jessie is right. Jessie is consistent. Jessie is not handsome. Jessie is not warm hearted.Jessie is not tame. Jessie is self disciplined. Jessie is imaginative.Jessie is long. Jessie is rude. Jessie is not available. Jessie is not busy. Jessie is not reserved. Jessie is not tired. If someoneA is long then he is clear, unless he is placid or he is not few.If someoneA is not busy and not clear then he is not competitive, unless he is mean or he is not beautiful. If someoneA is right and not tired then he is weary ,unless he is not dangerous. If someoneA is clear and not tame then he is not dangerous,unless he is weary or he is not informal. If someoneA admire someoneB and someoneA is not reserved then he is not few ,unless he is not unpleasant or he is not self disciplined.If someoneA is consistent and horrible then he is not informal ,unless he is not dangerous. If someoneA is not handsome then he is mean,unless he is not competitive. If someoneA is imaginative and not warm hearted then he is green,unless he is not informal. If someoneA is self disciplined and not available then he is not salty, unless he is not sane or he is triangular. If someoneA is rude and weary then he is not pleasant ,unless he is mean.  \n If the Question is: Jessie is clear.  \n Then the answer label for the question is: Unknown;  \n If the question is: Jessie is few.  \n Then the answer label for the question is: False; \n  If the question is: Jessie is not informal.  \n Then the answer label for the question is: True.  \n For example, Context: Basil is not innocent. Basil is not wooden. Basil is discreet.Basil is not petite. Basil is comprehensive.Basil is nutty. Basil is historical. Basil is plastic.Basil is steep.Basil is not pleasant.Basil is not useful. Basil is long.Basil is better. Basil is not expensive. If someoneA is historical then he is red, unless he is not lively or he is not big. If someoneA is nutty and steep then he is miniscule, unless he is not weary or he is outstanding.If someoneA is not petite then he is brave, unless he is sticky or he is psychological. If someoneA is not wooden and miniscule then he is psychological, unless he is brave. If someoneA is not expensive and discreet then he is not legal, unless he is not ugly or he is psychological.If someoneA is plastic then he is sticky, unless he is brave.If someoneA is miniscule then he is not courageous,unless he is sticky or he is not eastern. If someoneA is not pleasant and better then he is ashamed, unless he is bloody. If someoneA is comprehensive and not useful then he is not disgusted,unless he is brave. If someoneA is long and not innocent then he is not compassionate, unless he is psychological or he is not smart. \n  If the Question is: Basil is red. \n  Then the answer label for the question is: True;  \n If the question is: Basil is miniscule. \n  Then the answer label for the question is: Unknown;  \n If the question is: Basil is not ashamed. \n  Then the answer label for the question is: False.  \n Note that you only need to generate the answer label for the question, without giving an explanation or justification. Please read the context carefully and answer the questions.'
Three_Few_Shot_Credulous_Instruction = 'Task Description: \n  Given contexts and question, You need to generate answer labels for questions in a given context. The context contains facts and a default rule, The default rule format is: If A then B, unless C. The A is the prerequisite, the B is the conclusion, and the C is called the justifications. The "If A then B, unless C." means that If the preconditions A are in the facts, and the justifications C is not in the facts, then you can deduce the conclusion B. The answers to the questions are labeled "True", "False" and "Unknown".  \n  If the question can be inferred under a certain reasoning path based on the context, the answer label of the question is: "True";  \n if the negation of the question can be inferred under a certain reasoning path based on the context, the answer label of the question is: "False"; \n  If the question and the negation of the question both cannot be deduced under all reasoning path based on the context, the answer label of the question is: "Unknown".  \n Each context has three questions, and the input format is Context: ". Question:". The output format is: The answer label of question is:". You must generate answer labels for each question. \n  For example, Context: Brooke is not bad. Brooke is not famous. Brooke is bumpy. Brooke is not quiet. Brooke is hypocritical. Brooke is not agreeable.Brooke is not compassionate. Brooke is tan.Brooke is not annoying. Brooke is careful. Brooke is boring. Brooke is not versatile. Brooke is silly. Brooke is not alive. If someoneA is hypocritical and tan then he is not weary, unless he is not puzzled or he is not untidy. If someoneA is not quiet and boring then he is humorous ,unless he is not self confident. If someoneA is not versatile and not bad then he is self confident,unless he is cautious. If someoneA is not compassionate then he is unsightly ,unless he is busy. If someoneA is not annoying then he is not lonely, unless he is humorous or he is not zealous. If someoneA is not lonely and careful then he is purple, unless he is handsome. If someoneA is not famous and not agreeable then he is lucky, unless he is humorous or he is sweet. If someoneA is not alive and bumpy then he is not intellectual, unless he is perfect or he is attentive. If someoneA is silly then he is handsome, unless he is purple or he is misty.If someoneA is not intellectual then he is useful, unless he is cool or he is adventurous.  \n If the question is: Brooke is not weary.  \n Then the answer label for the question is: True;  \n If the question is: Brooke is not humorous. \n  Then the answer label for the question is: False;  \n If the question is: Brooke is lonely.  \n Then the answer label for the question is: Unknown.  \n For example, Context: Kathie is not hilarious. Kathie is itchy. Kathie is sharp. Kathie is cloudy. Kathie is aware. Kathie is severe. Kathie is frail. Kathie contemn Stefan. Kathie is latter. Kathie is not thankful. Kathie is not powerful. Kathie is grotesque. Kathie is not disobedient. If someoneA is not hilarious then he is not nervous, unless he is not evil. If someoneA is not disobedient and severe then he is not tan, unless he is bloody or he is generous. If someoneA is not nervous then he is not splendid, unless he is not intellectual or he is not thoughtless. If someoneA is latter and itchy then he is not acceptable, unless he is not afraid or he is elegant. If someoneA is grotesque and frail then he is not puzzled, unless he is not famous or he is not exuberant. If someoneA is not nervous and not puzzled then he is generous, unless he is dynamic or he is not tan. If someoneA is sharp and aware then he is bloody, unless he is not tan. If someoneA contemn someoneB then he is dynamic, unless he is generous. If someoneA is not thankful and not powerful then he is not wet, unless he is generous. If someoneA is cloudy then he is not charming, unless he is thoughtless or he is massive.  \n If the question is: Kathie is not nervous. Then the answer label for the question is: Unknown;  \n If the question is: Kathie is tan.  \n Then the answer label for the question is: False;  \n If the question is: Kathie is not splendid. \n  Then the answer label for the question is: True. \n  For example, Context: Cecil is acceptable.Cecil is uptight.Cecil is not good tempered.Cecil is not severe.Cecil is not messy.Cecil is not self disciplined. Cecil is not logical.Cecil is not right.Cecil is careful.Cecil is not talented.Cecil is not curious.Cecil is not evil.Cecil is annoying. If someoneA is not evil and not good tempered then he is not good, unless he is not successful or he is not modern.If someoneA is not logical then he is not visible, unless he is not harsh. If someoneA is not messy and careful then he is not outstanding, unless he is not uptight. If someoneA is uptight and not severe then he is not successful, unless he is similar or he is not good. If someoneA is not visible then he is serious, unless he is not outstanding. If someoneA is not self disciplined then he is not fantastic, unless he is emotional or he is serious. If someoneA is not talented and acceptable then he is similar, unless he is not purple or he is not successful. If someoneA is not curious and annoying then he is typical, unless he is not self confident. If someoneA is not fantastic then he is not inquisitive, unless he is not outstanding or he is not tame. If someoneA is not right then he is emotional, unless he is not fantastic or he is not oak. \n  If the question is: Cecil is good.  \n Then the answer label for the question is: False;  \n If the question is: Cecil is not visible.  \n Then the answer label for the question is: Unknown;  \n If the question is: Cecil is similar.  \n Then the answer label for the question is: True. \n  Note that you only need to generate the answer label for the question, without giving an explanation or justification. Please read the context carefully and answer the questions. '
Zero_Shot_COT_Extensions_Shot_Skeptical_Instruction = 'Task Description: \n Given contexts and question, and the context consists of facts and default rules. You need first to generate all extensions based on the given context and then to answer the question according to the extensions. An extension is a set of non-contradictory facts and conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to find all the extensions. Next, the answer to the question is generated based on the generated extension. If the question can be inferred under all extensions, and the negation of the question cannot be inferred under all extensions, the answer label of the question is: "True"; If the negation of the question can be inferred under all extensions, and the question cannot be inferred under all extensions, the answer label of the question is: "False"; If the question and the negation of the question cannot be deduced under a certain extension, the answer label of the question is: "Unknown". \n  The input format is: ‘Facts:’’, Default Rules:’’’. Question:".  The output format is: The extensions are:’’. The answer label of the question is:". \n You must generate all extensions and answer the question according to the extensions. Please read the context carefully. Let\'s think step by step.'
Zero_Shot_COT_Extensions_Shot_Credulous_Instruction = 'Task Description: \n Given contexts and question, the context consists of facts and default rules. You first need to generate all extensions based on the given context and then answer the question according to the extensions. An extension is a set of non-contradictory facts and conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to find all the extensions according to the above steps. Next, the answer to the question is generated based on the generated extension. If the question can be inferred under a certain extension, the answer label of the question is: "True"; If the negation of the question can be inferred under a certain extension, the answer label of the question is: "False"; If the question and the negation of the question both cannot be deduced under all extension, the answer label of the question is: "Unknown". \n The input format is Context: ‘Facts:‘’, Default Rules:’’’. Question:". The output format is: The extensions are:’’. The answer label of the question is:". \n You must generate all extensions and answer the question according to the extensions. Please read the context carefully. Let\'s think step by step.'
Few_Shot_COT_Extensions_Shot_Skeptical_Instruction = 'Task Description: \n Given contexts and question, and the context consists of facts and default rules. You need first to generate all extensions based on the given context and then to answer the question according to the extensions. An extension is a set of non-contradictory facts and conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to find all the extensions. Next, the answer to the question is generated based on the generated extension. If the question can be inferred under all extensions, and the negation of the question cannot be inferred under all extensions, the answer label of the question is: "True"; If the negation of the question can be inferred under all extensions, and the question cannot be inferred under all extensions, the answer label of the question is: "False"; If the question and the negation of the question cannot be deduced under a certain extension, the answer label of the question is: "Unknown".  \n The input format is Context: ‘Facts:’’, Default Rules:’’’. Question:". The output format is: The extensions are:’’. The answer label of the question is:". \n For example: \n Context: \n Facts: Toby is not noisy. Toby is handsome.…. Default Rules: If someoneA is handsome then he is delicious, unless he is not drab. If someoneA is not noisy then he is not drab, unless he is delicious. This context can generate two extensions: The extension 1 are: " Toby is not noisy. Toby is handsome. Toby is delicious."; \n The extension 2 are " Toby is not noisy. Toby is handsome. Toby is not drab.". \n If the Question is: Toby is not noisy. Since all expansions can infer the query " Toby is not noisy.", so the answer label for the question is: True. ; \n If the question is: Toby is not drab. Although extension 2 can deduce the query " Toby is not drab ", extension 1 cannot, so the answer label for the question is: Unknown; \n If the question is: Toby is not handsome. Since all three extensions can lead to the query "Toby is handsome", so the answer label for the question is: False. \n You must generate all extensions and answer the question according to the extensions. Please read the context carefully. Let\'s think step by step.'
Few_Shot_COT_Extensions_Shot_Credulous_Instruction = 'Task Description: \n Given contexts and question, the context consists of facts and default rules. You first need to generate all extensions based on the given context and then answer the question according to the extensions. An extension is a set of non-contradictory facts and conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to find all the extensions according to the above steps. Next, the answer to the question is generated based on the generated extension. If the question can be inferred under a certain extension, the answer label of the question is: "True"; If the negation of the question can be inferred under a certain extension, the answer label of the question is: "False"; If the question and the negation of the question both cannot be deduced under all extension, the answer label of the question is: "Unknown". \n The input format is: ‘Facts:‘’, Default Rules:’’’. Question:". The output format is: The extensions are:’’. The answer label of the question is:". \n For example: \n Facts: Toby is not noisy. Toby is handsome.…. Default Rules: If someoneA is handsome then he is delicious, unless he is not drab. If someoneA is not noisy then he is not drab, unless he is delicious.  The context can generate two extensions: The extension 1 are: " Toby is not noisy. Toby is handsome. Toby is delicious."; \n The extension 2 are " Toby is not noisy. Toby is handsome. Toby is not drab.". \n If the question is: Toby is not drab. Since extension 2 can lead to the query " Toby is not drab ", so the answer label for the question is True; \n If the question is: Toby is intelligent. Since extensions 1 and 2 cannot deduce the query and the negation of the query, so the answer label for the question is Unknown; \n If the question is: Toby is not handsome. Since the negation of query fact " Toby is handsome." can be derived in extensions, so the answer label for the question is: False. \n You must generate all extensions and answer the question according to the extensions. Please read the context carefully. Let\'s think step by step.'
Three_COT_Extensions_Shot_Skeptical_Instruction = 'Task Description: \n Given contexts and question, and the context consists of facts and default rules. You need to first generate all extensions based on given context, then to answer the question according to the extensions. To generate an extension in the context, firstly, to generate the initial upper and lower bounds fact sets of extension based on the instantiated default rules, the lower bound fact set is initialized with the original facts. The upper bound fact set should also include all the facts extracted from the rules. Then, the upper and lower bounds facts are updated using the conclusions generated by the rules. If the updated lower bound fact set is still a subset of the upper bound fact set, a fact is selected from the upper bound fact set and added to the lower bound set. Then, the rules are inferred based on the updated upper and lower bound fact sets, and the upper and lower bound fact sets are updated again using the generated conclusions. Specifically, the conclusions generated by the rules under the upper bound fact set should be included in the lower bound fact set. In comparison, the upper bound fact set should only contain the conclusions generated by the reduced rules in the lower bound fact set. Finally, the process is iterated until the upper and lower bounds facts are consistent and an extension is found. There may be multiple extensions in the context, and you need to find all the extensions according to the above steps. Next, the answer to the question is generated based on the generated extension. If the question can be inferred under all extensions, and the negation of the question cannot be inferred under all extensions, the answer label of the question is: "True"; If the negation of the question can be inferred under all extensions, and the question cannot be inferred under all extensions, the answer label of the question is: "False"; If the question and the negation of the question cannot be deduced under a certain extension, the answer label of the question is: "Unknown". \n The input format is: ‘Facts:’’, Default Rules:’’’. Question:". The output format is: The extensions are:’’. The answer label of the question is:". \n For example: \n Context: \n Facts: Toby is not noisy. Toby is handsome.…. Default Rules: If someoneA is handsome then he is delicious, unless he is not drab. If someoneA is not noisy then he is not drab, unless he is delicious. The first step is to generate the upper and lower bounds of the extension. The lower bound fact set is "Toby is not noisy. Toby is handsome.", and the upper bound fact set is "Toby is not noisy. Toby is handsome. Toby is delicious. Toby is not drab.". Then, the upper bound facts are updated using the conclusion "Toby is delicious. Toby is not drab." generated by the lower bound fact set based on the default rule. The new upper bound fact set is "Toby is not noisy. Toby is handsome. Toby is delicious. Toby is not drab.". Similarly, since the default rule does not generate new facts when reasoning on the upper bound fact set, the lower bound fact set remains unchanged. At this time, since the lower bound fact set is a subset of the upper bound fact set, a fact is randomly selected from the upper bound fact set and added to the lower bound fact set. The new lower bound fact set is updated to "Toby is not noisy. Toby is handsome. Toby is delicious." The new upper bound fact set is "Toby is not noisy. Toby is handsome. Toby is not drab.". Then the default rule is inferred based on the new upper and lower bound fact sets, and the process is iterated until the upper and lower bounds of the extension are consistent. Finally, the context can generate two extensions: The extension 1 are: " Toby is not noisy. Toby is handsome. Toby is delicious."; \n The extension 2 are " Toby is not noisy. Toby is handsome. Toby is not drab.". \n If the Question is: Toby is not noisy. Since all expansions can infer the query " Toby is not noisy."，so the answer label for the question is: True. ; \n If the question is: Toby is not drab. Although extensions 2 can deduce the query " Toby is not drab ", extension 1 cannot deduce this query，so the answer label for the question is: Unknown; \n If the question is: Toby is not handsome. Since all three extensions can lead to the query "Toby is handsome"，so the answer label for the question is: False. \n You must generate all extensions and answer the question according to the extensions.  Please read the context carefully. Let\'s think step by step.'
Three_COT_Extensions_Shot_Credulous_Instruction = 'Task Description: \n Given contexts and question, and the context consists of facts and default rules. You need to first generate all extensions based on given context, then to answer the question according to the extensions. To generate an extension in the context, firstly, to generate the initial upper and lower bounds fact sets of extension based on the instantiated default rules, the lower bound fact set is initialized with the original facts. The upper bound fact set should also include all the facts extracted from the rules. Then, the upper and lower bounds facts are updated using the conclusions generated by the rules. If the updated lower bound fact set is still a subset of the upper bound fact set, a fact is selected from the upper bound fact set and added to the lower bound set. Then, the rules are inferred based on the updated upper and lower bound fact sets, and the upper and lower bound fact sets are updated again using the generated conclusions. Specifically, the conclusions generated by the rules under the upper bound fact set should be included in the lower bound fact set. In comparison, the upper bound fact set should only contain the conclusions generated by the reduced rules in the lower bound fact set. Finally, the process is iterated until the upper and lower bounds facts are consistent and an extension is found. There may be multiple extensions in the context, and you need to find all the extensions according to the above steps. Next, the answer to the question is generated based on the generated extension. If the question can be inferred under a certain extension, the answer label of the question is: "True"; If the negation of the question can be inferred under a certain extension, the answer label of the question is: "False"; If the question and the negation of the question both cannot be deduced under all extension, the answer label of the question is: "Unknown". \n The input format is: ‘Facts:‘’, Default Rules:’’’. Question:". The output format is: The extensions are:’’. The answer label of the question is:". \n For example: \n Facts: Toby is not noisy. Toby is handsome.…. Default Rules: If someoneA is handsome then he is delicious, unless he is not drab. If someoneA is not noisy then he is not drab, unless he is delicious. The first step is to generate the upper and lower bounds of the extension. The lower bound fact set is "Toby is not noisy. Toby is handsome.", and the upper bound fact set is "Toby is not noisy. Toby is handsome. Toby is delicious. Toby is not drab.". Then, the upper bound facts are updated using the conclusion "Toby is delicious. Toby is not drab." generated by the lower bound fact set based on the default rule. The new upper bound fact set is "Toby is not noisy. Toby is handsome. Toby is delicious. Toby is not drab.". Similarly, since the default rule does not generate new facts when reasoning on the upper bound fact set, the lower bound fact set remains unchanged. At this time, since the lower bound fact set is a subset of the upper bound fact set, a fact is randomly selected from the upper bound fact set and added to the lower bound fact set. The new lower bound fact set is updated to "Toby is not noisy. Toby is handsome. Toby is delicious." The new upper bound fact set is "Toby is not noisy. Toby is handsome. Toby is not drab.". Then the default rule is inferred based on the new upper and lower bound fact sets, and the process is iterated until the upper and lower bounds of the extension are consistent. Finally, the context can generate two extensions: The extension 1 are: " Toby is not noisy. Toby is handsome. Toby is delicious."; \n The extension 2 are " Toby is not noisy. Toby is handsome. Toby is not drab.". \n If the question is: Toby is not drab. Since the extension 2 can lead to the query " Toby is not drab ", so the answer label for the question is: True; \n If the question is: Toby is intelligent. Since extensions 1 and 2 cannot deduce the query and the negation of query, so the answer label for the question is: Unknown; \n If the question is: Toby is not handsome. Since the negation of query fact " Toby is handsome." can be derived in extensions, so the answer label for the question is: False. \n You must generate all extensions and answer the question according to the extensions. Please read the context carefully. Let\'s think step by step.'

Yeliang_API_Key = "sk-n7IWXtrI2d0JsnbuDa6dD8F090444fEaAaF1C101D899Fa3b" # "sk-wYnDOGnqs7X62a2DEcFa8094B6384f2aAf12AfD88d1dC649", "sk-n7IWXtrI2d0JsnbuDa6dD8F090444fEaAaF1C101D899Fa3b"
Base_URL = "https://35.aigcbest.top/v1" #  "https://api.nhyun.top" #"https://35.aigcbest.top/v1"

def chatGPT_Solver(instructions, context, question):
    client = OpenAI(base_url=Base_URL,
                    api_key=Yeliang_API_Key)
    while_count01 = 0
    while while_count01 < 10:
        try:
            rsp = client.chat.completions.create(
              model="gpt-3.5-turbo", # gpt-3.5-turbo/ gpt-4-turbo-preview
              messages=[
                    {"role": "system", "content": instructions},
                    {"role": "user", "content": context + question}
                ],
              temperature=0
            )
            result = rsp.choices[0].message.content
            return result
        except Exception as e:
            print(f"llm_send报错 {while_count01 + 1}次尝试: {e}")
            while_count01 += 1
        return ""

def GPT4_Solver(instructions, context, question):
    client = OpenAI(base_url=Base_URL,
                    api_key=Yeliang_API_Key,
                    http_client=httpx.Client(base_url=Base_URL,follow_redirects=True,
                                             ),
                    )
    while_count01 = 0
    while while_count01 < 10:
        try:
            rsp = client.chat.completions.create(
              model="gpt-4-turbo-preview",
              messages=[
                    {"role": "system", "content": instructions},
                    {"role": "user", "content": context + question}
                ],
              temperature=0
            )
            result = rsp.choices[0].message.content
            return result
        except Exception as e:
            print(f"llm_send报错 {while_count01 + 1}次尝试: {e}")
            while_count01 += 1
        return ""

def claude_Solver(instructions, context, question):
    client = OpenAI(base_url=Base_URL,
                    api_key=Yeliang_API_Key,
                    http_client=httpx.Client(base_url=Base_URL,follow_redirects=True,
                                             ),
                    )
    while_count01 = 0
    while while_count01 < 10:
        try:
            rsp = client.chat.completions.create(
              model="claude-3-opus-20240229", # 'claude-3-opus-20240229','claude-3-sonnet-20240229'
              messages=[
                    {"role": "system", "content": instructions},
                    {"role": "user", "content": context + question}
                ]
            )
            result = rsp.choices[0].message.content
            return result
        except Exception as e:
            print(f"llm_send报错 {while_count01 + 1}次尝试: {e}")
            while_count01 += 1
    return ""


def Read():
    with open(Read_Data_file, 'r', encoding='utf-8') as f0, open(Write_file_path02, 'a', encoding='utf-8') as f1:
        Total_Question_label_List = []
        Total_LLMs_Generted_Label_List = []
        Total_count01 = 1
        Test_Extension_Example_Dict ={}
        Test_Extension_Example_Dict01 = {6: 0, 8: 0, 10: 0, 12: 0, 16: 0} if OOD_Flag == True else {2: 0, 1: 0, 4: 0, 3: 0, 5: 0}
        for line in f0:
            Write_Dict = {}  # 该字典用于存储需要写入的样本字典
            LLMs_Generted_Label_List = []
            LLMs_Generted_Answer_Set_Explanation_List = []
            js = json.loads(line.strip())
            # 将数据集划分成训练/验证/测试
            # print(json.dumps(js, ensure_ascii=False))
            Sample_number = js['Sample_number']
            Origin_Facts = js['Origin_Facts']
            Facts_number = js['Facts_number']  # 计算缺省理论中事实的个数
            Defalut_Rules = js['Defalut_Rules']
            # Noise_Facts_Lists = js['Noise_Facts_Lists']
            NL_Origin_Facts = js['NL_Origin_Facts']
            NL_Defalut_Rules = js['NL_Defalut_Rules']
            # NL_Noise_Facts_Lists = js['NL_Noise_Facts_Lists']

            # Noise_Default_Rules_Lists = js['Noise_Default_Rules_Lists']
            # NL_Noise_Default_Rule_Lists = js['NL_Noise_Default_Rule_Lists']
            Origin_ASP_extension_number = js['Origin_ASP_extension_number']
            Origin_Question_Text_Lists = js['Origin_Question_Text_Lists']
            NL_Origin_Question_Text = js['NL_Origin_Question_Text']
            Origin_Question_Label_Lists = js['Origin_Question_Label_Lists']
            Origin_Question_proof_List = js['Origin_Question_proof_List']
            NL_Origin_Question_proof_Text = js['NL_Origin_Question_proof_Text']

            # # 每个扩展数量的样本测试20个
            if Origin_ASP_extension_number not in Test_Extension_Example_Dict.keys():
                Test_Extension_Example_Dict[Origin_ASP_extension_number] = 1
                if Test_Extension_Example_Dict[Origin_ASP_extension_number] <= Test_Extension_Example_Dict01[Origin_ASP_extension_number]:
                    Total_count01 = Total_count01 + 1
                    continue
            else:
                if Test_Extension_Example_Dict[Origin_ASP_extension_number] >= 100:
                    Total_count01 = Total_count01 + 1
                    continue
                else:
                    Test_Extension_Example_Dict[Origin_ASP_extension_number] = Test_Extension_Example_Dict[Origin_ASP_extension_number] + 1
                    if Test_Extension_Example_Dict[Origin_ASP_extension_number] <= Test_Extension_Example_Dict01[Origin_ASP_extension_number]:
                        Total_count01 = Total_count01 + 1
                        continue

            Answer_Set_List = []
            if Total_count01 <= -1:
                print('Test_Extension_Example_Dict={}'.format(Test_Extension_Example_Dict))
                Total_count01 = Total_count01 + 1
                continue

            Instruction = ''
            if Zero_or_Few_Shot == 'Zero_Shot' and Reasoning_Mode == 'credulous':
                Instruction = Zero_Shot_Credulous_Instruction
            elif Zero_or_Few_Shot == 'Zero_Shot' and Reasoning_Mode == 'skeptical':
                Instruction = Zero_Shot_Skeptical_Instruction
            elif Zero_or_Few_Shot == 'Few_Shot' and Reasoning_Mode == 'credulous':
                Instruction = Three_Few_Shot_Credulous_Instruction
            elif Zero_or_Few_Shot == 'Few_Shot' and Reasoning_Mode == 'skeptical':
                Instruction = Three_Few_Shot_Skeptical_Instruction
            elif Zero_or_Few_Shot == 'Zero_Shot_COT' and Reasoning_Mode == 'credulous':
                Instruction = Zero_Shot_COT_Extensions_Shot_Credulous_Instruction
            elif Zero_or_Few_Shot =='Zero_Shot_COT' and Reasoning_Mode == 'skeptical':
                Instruction = Zero_Shot_COT_Extensions_Shot_Skeptical_Instruction
            elif Zero_or_Few_Shot == 'Few_Shot_COT' and Reasoning_Mode == 'credulous':
                Instruction = Few_Shot_COT_Extensions_Shot_Credulous_Instruction
            elif Zero_or_Few_Shot =='Few_Shot_COT' and Reasoning_Mode == 'skeptical':
                Instruction = Few_Shot_COT_Extensions_Shot_Skeptical_Instruction
            elif Zero_or_Few_Shot == 'COT_Extensions' and Reasoning_Mode == 'credulous':
                Instruction = Three_COT_Extensions_Shot_Credulous_Instruction
            elif Zero_or_Few_Shot == 'COT_Extensions' and Reasoning_Mode == 'skeptical':
                Instruction = Three_COT_Extensions_Shot_Skeptical_Instruction

            Context_Text_String = 'Facts:' + NL_Origin_Facts
            Context_Text_String = Context_Text_String + 'Defaults Rules:' + NL_Defalut_Rules
            Question_Text_String = ''
            for question_key in range(len(NL_Origin_Question_Text)):
                question_text = ' Question: ' + NL_Origin_Question_Text[question_key]
                Question_Text_String = question_text
                question_label = Origin_Question_Label_Lists[question_key]
                Total_Question_label_List.extend(Label_Dict[question_label[0]])
                # 调用大模型预测
                results = None
                if LLMs_Models_Choise == 'GPT3.5':
                    results = chatGPT_Solver(Instruction, Context_Text_String, Question_Text_String)
                elif LLMs_Models_Choise =='GPT4':
                    results = GPT4_Solver(Instruction, Context_Text_String, Question_Text_String)
                elif LLMs_Models_Choise == 'Claude':
                    results = claude_Solver(Instruction, Context_Text_String, Question_Text_String)

                ### 添加一个函数用于对大模型生成结果的格式进行判断，如何不符合格式，则重新生成。

                # 对生成的结果进行分析
                print("Total_count01={}, LLMs Results = {}".format(Total_count01, results))
                predict_label = None
                if 'unknown' in results or 'Unknown' in results:
                    predict_label = 'M'
                elif 'true' in results or 'True' in results:
                    predict_label = 'T'
                elif 'false' in results or 'False' in results:
                    predict_label = 'F'
                else:
                    predict_label = 'M'
                LLMs_Generted_Label_List.append([predict_label])

                Total_LLMs_Generted_Label_List.extend(Label_Dict[predict_label])


            Total_count01 = Total_count01 + 1
            Write_Dict['Sample_number'] = Sample_number  # 样本个数
            Write_Dict['Origin_ASP_extension_number'] = Origin_ASP_extension_number
            Write_Dict['NL_Origin_Question_Text'] = NL_Origin_Question_Text
            Write_Dict['Origin_Question_Label_Lists'] = Origin_Question_Label_Lists
            Write_Dict['LLMs_Generated_Question_Label_Lists'] = LLMs_Generted_Label_List

            Write_Dict['Origin_Question_proof_List'] = Origin_Question_proof_List
            Write_Dict['NL_Origin_Question_proof_Text'] = NL_Origin_Question_proof_Text
            Write_Dict['LLMs_Generated_Question_Explanation_Lists'] = ''
            Write_Dict['LLMs_Repose'] = ''
            Write_Dict = json.dumps(Write_Dict, ensure_ascii=False)
            f1.write(Write_Dict + '\n')


        accuracy = accuracy_score(Total_Question_label_List, Total_LLMs_Generted_Label_List) # 计算准确率
        F1 = f1_score(Total_Question_label_List, Total_LLMs_Generted_Label_List,average = 'macro')
        print('accuracy={},F1={}'.format(accuracy,F1))


if __name__ == '__main__':
    Read()
