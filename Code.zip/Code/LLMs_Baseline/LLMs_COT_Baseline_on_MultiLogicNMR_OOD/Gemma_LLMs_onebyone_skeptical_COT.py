"""
新提出的评估指标方法，利用语言模型对证明树进行打分，
"""
import copy
import sys
import re
import httpx
import torch
sys.path.append('../../Dataset')
import difflib
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import json
Reasoning_Mode = 'skeptical' # [credulous, skeptical]
Dataset_Category = 'test' # ['train', 'dev', 'test']
Zero_or_Few_Shot = 'Zero_Shot_COT' # ['Zero_Shot','Few_Shot', 'Zero_Shot_COT','Few_Shot_COT', 'COT_Extensions', 'COT_Symbolic']
OOD_Flag = True
OOD_Data_Path = "OOD_Datasets" if OOD_Flag == True else ''
OOD_read_filename = "_OOD" if OOD_Flag == True else ''
OOD_write_filename = "OOD_" if OOD_Flag == True else ''
read_file_path = None
if OOD_Flag == True:
    read_file_path = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Datasets/' + OOD_Data_Path + '/'
else:
    read_file_path = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Datasets/' + Reasoning_Mode + '/'
write_file_path = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Experimens/LLMs_Results/'
ASP_extension_number_Min, ASP_extension_number_Max = 1,5 #用于对回答集进行过滤
if OOD_Flag == True:
    ASP_extension_number_Min, ASP_extension_number_Max = 6,16
LLMs_Models_Choise = "Gemma2_7B" #['GPT3.5','GPT4','Claude','Gemma_7B','Mistral_7B', 'llama3']
Read_Data_file = read_file_path + Reasoning_Mode + '_multiNMR_'+ Dataset_Category +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance'+ OOD_read_filename + '_New.json'
Write_file_path02 = write_file_path + Zero_or_Few_Shot +'_'+ LLMs_Models_Choise + '_result_on_'+ OOD_write_filename + Reasoning_Mode + '_multiNMR_'+ Dataset_Category +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + '_New.json'


Label_Dict = {'F':[0],'T':[1],'M':[2]}
# 提示要求同时回答多个问题。
# Zero_Shot_Skeptical_Instruction = 'You are an expert in non-monotonic reasoning and are asked to generate answer labels and answer set explanations for questions in a given context. The answers to the questions are labeled "True", "False" and "Unknown". The answer set explanations are all intermediate conclusions generated under a certain reasoning path based on context, where intermediate conclusions are the conclusions generated when applying rules for reasoning. The set of intermediate conclusions generated under a certain reasoning path cannot contradict each other. Since there may be many different paths of reasoning, there may be multiple answer set explanations. If the question can be inferred under all reasoning paths based on the context, and the negation of the question cannot be inferred under all reasoning paths based on the context, the answer label of the question is "True", and needs to generate all answer set explanations that contain the question; if the negation of the question can be inferred under all reasoning path based on the context, and the question cannot be inferred under all reasoning path based on the context, the answer label of the question is "False", and needs to generate all answer set explanations that contain the negation of question; If the question and the negation of the question cannot be deduced under a certain reasoning path based on the context, the answer label of the question is "Unknown", and needs to generate all the answer set explanations than cannot contain the question and all the answer set explanations that cannot contain the negation of the question. Each context has three questions, and the input format is Context: ". Question 1:". Question 2:". Question 3:". You must generate answer labels and answer set explanations for each question. The output format is: The answer label of question 1 is:", The answer set explanations of question 1 is: explanation 1:''.,...,. Explanation n:''. The answer label of question 2 is:", The answer set explanations of question 2 is: Explanation 1:''.,...,. Explanation n:''. The answer label of question 3 is:", The answer set explanations of question 3 is: Explanation 1:''.,...,. Explanation n:''. Please read the context carefully and answer the questions. '
# Zero_Shot_Credulous_Instruction = 'You are an expert in non-monotonic reasoning and are asked to generate answer labels and answer set explanations for questions in a given context. The answers to the questions are labeled "True", "False" and "Unknown". The answer set explanations are all intermediate conclusions generated under a certain reasoning path based on context, where intermediate conclusions are the conclusions generated when applying rules for reasoning. The set of intermediate conclusions generated under a certain reasoning path cannot contradict each other. Since there may be many different paths of reasoning, there may be multiple answer set explanations. If the question can be inferred under a certain reasoning path based on the context, the answer label of the question is "True" and needs to generate all answer set explanations that contain the question; if the negation of the question can be inferred under a certain reasoning path based on the context, the answer label of the question is "False", and needs to generate all answer set explanations that contain the negation of question; If the question and the negation of the question both cannot be deduced under all reasoning path based on the context, the answer label of the question is "Unknown". It needs to generate all the answer set explanations that can not contain the question and all the answer set explanations that can not contain the negation of the question. Each context has three questions, and the input format is Context: ", question 1:", question 2:", question 3:". Please read the context carefully and answer the questions. You must generate answer labels and answer set explanations for each question. The output format is: The answer label of question 1 is:", The answer set explanations of question 1 is: Explanation 1:''.,...,. Explanation n:''. The answer label of question 2 is:". The answer set explanations of question 2 is: Explanation 1:''.,...,. Explanation n:''. The answer label of question 3 is:". The answer set explanations of question 3 is: Explanation 1:''.,...,. Explanation n:''.'

# 提示要求逐个回答问题。
Zero_Shot_Skeptical_Instruction = 'Task Description: Given contexts and question, You need to generate answer labels for questions in a given context. If the question can be inferred under all reasoning paths based on the context, and the negation of the question cannot be inferred under all reasoning paths based on the context, the answer label of the question is: "True"; if the negation of the question can be inferred under all reasoning path based on the context, and the question cannot be inferred under all reasoning path based on the context, the answer label of the question is: "False"; If the question and the negation of the question cannot be deduced under a certain reasoning path based on the context, the answer label of the question is: "Unknown". The input format is Context: ". Question:". You must generate answer labels for the question. The output format is: The answer label of the question is:". Note that you only need to generate the answer label for the question without giving an explanation or justification. Please read the context carefully and answer the questions. '
Zero_Shot_Credulous_Instruction = 'Task Description: Given contexts and question, You need to generate answer labels for questions in a given context. If the question can be inferred under a certain reasoning path based on the context, the answer label of the question is: "True"; if the negation of the question can be inferred under a certain reasoning path based on the context, the answer label of the question is: "False"; If the question and the negation of the question both cannot be deduced under all reasoning path based on the context, the answer label of the question is: "Unknown". The input format is Context: ". Question:". The output format is: The answer label of question is:". You must generate answer labels for the question. Note that you only need to generate the answer label for the question, without giving an explanation or justification. Please read the context carefully and answer the questions. '
Three_Few_Shot_Skeptical_Instruction = 'Task Description: Given contexts and question, You need to generate answer labels for questions in a given context. The context contains facts and a default rule, The default rule format is: If A then B, unless C. The A is the prerequisite, the B is the conclusion, and the C is called the justifications. The "If A then B, unless C." means that If the preconditions A are in the facts, and the justifications C is not in the facts, then you can deduce the conclusion B. The answers to the questions are labeled "True", "False" and "Unknown". If the question can be inferred under all reasoning paths based on the context, and the negation of the question cannot be inferred under all reasoning paths based on the context, the answer label of the question is: "True"; if the negation of the question can be inferred under all reasoning path based on the context, and the question cannot be inferred under all reasoning path based on the context, the answer label of the question is: "False"; If the question and the negation of the question cannot be deduced under a certain reasoning path based on the context, the answer label of the question is: "Unknown". Each context has a question, and the input format is Context: ". Question:". You must generate answer labels for each question. The output format is: The answer label of the question is:". For example, Context: Grant is not impartial. Grant is not misty. Grant is not gentle. Grant is not lively. Grant is thankful.Grant is willing. Grant is red. Grant is medical. Grant is legal. Grant is not expensive. Grant is not crazy. If someoneA is not lively and not gentle then he is not adorable ,unless he is not annoying. If someoneA is thankful then he is critical ,unless he is not better. If someoneA is willing and not crazy then he is not aware ,unless he is not smoggy. If someoneA is legal then he is not annoying ,unless he is not adorable. If someoneA is not annoying then he is political,unless he is not alive or he is not adorable. If someoneA is not aware then he is not smoggy ,unless he is not aware. If someoneA is not misty then he is safe, unless he is not annoying. If someoneA is not expensive and not impartial then he is not mean, unless he is orange or he is safe.If someoneA is medical then he is not odd, unless he is optimistic or he is not smoggy. If someoneA is red then he is adventurous, unless he is not busy or he is not aware. If the Question is: Grant is adorable. Then the answer label for the question is: Unknown; If the question is: Grant is not critical. Then the answer label for the question is: False; If the question is: Grant is not odd. Then the answer label for the question is: True. For example, Context: Jessie is horrible. Jessie admire Marion. Jessie is right. Jessie is consistent. Jessie is not handsome. Jessie is not warm hearted.Jessie is not tame. Jessie is self disciplined. Jessie is imaginative.Jessie is long. Jessie is rude. Jessie is not available. Jessie is not busy. Jessie is not reserved. Jessie is not tired. If someoneA is long then he is clear, unless he is placid or he is not few.If someoneA is not busy and not clear then he is not competitive, unless he is mean or he is not beautiful. If someoneA is right and not tired then he is weary ,unless he is not dangerous. If someoneA is clear and not tame then he is not dangerous,unless he is weary or he is not informal. If someoneA admire someoneB and someoneA is not reserved then he is not few ,unless he is not unpleasant or he is not self disciplined.If someoneA is consistent and horrible then he is not informal ,unless he is not dangerous. If someoneA is not handsome then he is mean,unless he is not competitive. If someoneA is imaginative and not warm hearted then he is green,unless he is not informal. If someoneA is self disciplined and not available then he is not salty, unless he is not sane or he is triangular. If someoneA is rude and weary then he is not pleasant ,unless he is mean. If the Question is: Jessie is clear. Then the answer label for the question is: Unknown; If the question is: Jessie is few. Then the answer label for the question is: False; If the question is: Jessie is not informal. Then the answer label for the question is: True. For example, Context: Basil is not innocent. Basil is not wooden. Basil is discreet.Basil is not petite. Basil is comprehensive.Basil is nutty. Basil is historical. Basil is plastic.Basil is steep.Basil is not pleasant.Basil is not useful. Basil is long.Basil is better. Basil is not expensive. If someoneA is historical then he is red, unless he is not lively or he is not big. If someoneA is nutty and steep then he is miniscule, unless he is not weary or he is outstanding.If someoneA is not petite then he is brave, unless he is sticky or he is psychological. If someoneA is not wooden and miniscule then he is psychological, unless he is brave. If someoneA is not expensive and discreet then he is not legal, unless he is not ugly or he is psychological.If someoneA is plastic then he is sticky, unless he is brave.If someoneA is miniscule then he is not courageous,unless he is sticky or he is not eastern. If someoneA is not pleasant and better then he is ashamed, unless he is bloody. If someoneA is comprehensive and not useful then he is not disgusted,unless he is brave. If someoneA is long and not innocent then he is not compassionate, unless he is psychological or he is not smart. If the Question is: Basil is red. Then the answer label for the question is: True; If the question is: Basil is miniscule. Then the answer label for the question is: Unknown; If the question is: Basil is not ashamed. Then the answer label for the question is: False. Note that you only need to generate the answer label for the question, without giving an explanation or justification. Please read the context carefully and answer the questions.'
Three_Few_Shot_Credulous_Instruction = 'Task Description: Given contexts and question, You need to generate answer labels for questions in a given context. The context contains facts and a default rule, The default rule format is: If A then B, unless C. The A is the prerequisite, the B is the conclusion, and the C is called the justifications. The "If A then B, unless C." means that If the preconditions A are in the facts, and the justifications C is not in the facts, then you can deduce the conclusion B. The answers to the questions are labeled "True", "False" and "Unknown".  If the question can be inferred under a certain reasoning path based on the context, the answer label of the question is: "True"; if the negation of the question can be inferred under a certain reasoning path based on the context, the answer label of the question is: "False"; If the question and the negation of the question both cannot be deduced under all reasoning path based on the context, the answer label of the question is: "Unknown". Each context has three questions, and the input format is Context: ". Question:". The output format is: The answer label of question is:". You must generate answer labels for each question. For example, Context: Brooke is not bad. Brooke is not famous. Brooke is bumpy. Brooke is not quiet. Brooke is hypocritical. Brooke is not agreeable.Brooke is not compassionate. Brooke is tan.Brooke is not annoying. Brooke is careful. Brooke is boring. Brooke is not versatile. Brooke is silly. Brooke is not alive. If someoneA is hypocritical and tan then he is not weary, unless he is not puzzled or he is not untidy. If someoneA is not quiet and boring then he is humorous ,unless he is not self confident. If someoneA is not versatile and not bad then he is self confident,unless he is cautious. If someoneA is not compassionate then he is unsightly ,unless he is busy. If someoneA is not annoying then he is not lonely, unless he is humorous or he is not zealous. If someoneA is not lonely and careful then he is purple, unless he is handsome. If someoneA is not famous and not agreeable then he is lucky, unless he is humorous or he is sweet. If someoneA is not alive and bumpy then he is not intellectual, unless he is perfect or he is attentive. If someoneA is silly then he is handsome, unless he is purple or he is misty.If someoneA is not intellectual then he is useful, unless he is cool or he is adventurous. If the question is: Brooke is not weary. Then the answer label for the question is: True; If the question is: Brooke is not humorous. Then the answer label for the question is: False; If the question is: Brooke is lonely. Then the answer label for the question is: Unknown. For example, Context: Kathie is not hilarious. Kathie is itchy. Kathie is sharp. Kathie is cloudy. Kathie is aware. Kathie is severe. Kathie is frail. Kathie contemn Stefan. Kathie is latter. Kathie is not thankful. Kathie is not powerful. Kathie is grotesque. Kathie is not disobedient. If someoneA is not hilarious then he is not nervous, unless he is not evil. If someoneA is not disobedient and severe then he is not tan, unless he is bloody or he is generous. If someoneA is not nervous then he is not splendid, unless he is not intellectual or he is not thoughtless. If someoneA is latter and itchy then he is not acceptable, unless he is not afraid or he is elegant. If someoneA is grotesque and frail then he is not puzzled, unless he is not famous or he is not exuberant. If someoneA is not nervous and not puzzled then he is generous, unless he is dynamic or he is not tan. If someoneA is sharp and aware then he is bloody, unless he is not tan. If someoneA contemn someoneB then he is dynamic, unless he is generous. If someoneA is not thankful and not powerful then he is not wet, unless he is generous. If someoneA is cloudy then he is not charming, unless he is thoughtless or he is massive. If the question is: Kathie is not nervous. Then the answer label for the question is: Unknown; If the question is: Kathie is tan. Then the answer label for the question is: False; If the question is: Kathie is not splendid. Then the answer label for the question is: True. For example, Context: Cecil is acceptable.Cecil is uptight.Cecil is not good tempered.Cecil is not severe.Cecil is not messy.Cecil is not self disciplined. Cecil is not logical.Cecil is not right.Cecil is careful.Cecil is not talented.Cecil is not curious.Cecil is not evil.Cecil is annoying. If someoneA is not evil and not good tempered then he is not good, unless he is not successful or he is not modern.If someoneA is not logical then he is not visible, unless he is not harsh. If someoneA is not messy and careful then he is not outstanding, unless he is not uptight. If someoneA is uptight and not severe then he is not successful, unless he is similar or he is not good. If someoneA is not visible then he is serious, unless he is not outstanding. If someoneA is not self disciplined then he is not fantastic, unless he is emotional or he is serious. If someoneA is not talented and acceptable then he is similar, unless he is not purple or he is not successful. If someoneA is not curious and annoying then he is typical, unless he is not self confident. If someoneA is not fantastic then he is not inquisitive, unless he is not outstanding or he is not tame. If someoneA is not right then he is emotional, unless he is not fantastic or he is not oak. If the question is: Cecil is good. Then the answer label for the question is: False; If the question is: Cecil is not visible. Then the answer label for the question is: Unknown; If the question is: Cecil is similar. Then the answer label for the question is: True. Note that you only need to generate the answer label for the question, without giving an explanation or justification. Please read the context carefully and answer the questions. '
Zero_Shot_COT_Extensions_Shot_Skeptical_Instruction = 'Task Description: \n Given contexts and question, and the context consists of facts and default rules. You need first to generate all extensions based on the given context and then to answer the question according to the extensions. An extension is a set of non-contradictory facts and conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to find all the extensions. Next, the answer to the question is generated based on the generated extension. If the question can be inferred under all extensions, and the negation of the question cannot be inferred under all extensions, the answer label of the question is: "True"; If the negation of the question can be inferred under all extensions, and the question cannot be inferred under all extensions, the answer label of the question is: "False"; If the question and the negation of the question cannot be deduced under a certain extension, the answer label of the question is: "Unknown". \n Each context has a question, and the input format is Context: ‘Facts:’’, Default Rules:’’’. Question:". You must generate all extensions and answer the question according to the extensions. The output format is: The extensions are:’’. The answer label of the question is:". \n Please read the context carefully. Let\'s think step by step.'
Zero_Shot_COT_Extensions_Shot_Credulous_Instruction = 'Task Description: \n Given contexts and question, the context consists of facts and default rules. You first need to generate all extensions based on the given context and then answer the question according to the extensions. An extension is a set of non-contradictory facts and conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to find all the extensions according to the above steps. Next, the answer to the question is generated based on the generated extension. If the question can be inferred under a certain extension, the answer label of the question is: "True"; If the negation of the question can be inferred under a certain extension, the answer label of the question is: "False"; If the question and the negation of the question both cannot be deduced under all extension, the answer label of the question is: "Unknown". \n Each context has a question, and the input format is Context: ‘Facts:‘’, Default Rules:’’’. Question:". You must generate all extensions and answer the question according to the extensions. \n Please read the context carefully. Let\'s think step by step.'
Few_Shot_COT_Extensions_Shot_Skeptical_Instruction = 'Task Description: \n Given contexts and question, and the context consists of facts and default rules. You need first to generate all extensions based on the given context and then to answer the question according to the extensions. An extension is a set of non-contradictory facts and conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to find all the extensions. Next, the answer to the question is generated based on the generated extension. If the question can be inferred under all extensions, and the negation of the question cannot be inferred under all extensions, the answer label of the question is: "True"; If the negation of the question can be inferred under all extensions, and the question cannot be inferred under all extensions, the answer label of the question is: "False"; If the question and the negation of the question cannot be deduced under a certain extension, the answer label of the question is: "Unknown". \n Each context has a question, and the input format is Context: ‘Facts:’’, Default Rules:’’’. Question:". You must generate all extensions and answer the question according to the extensions. The output format is: The extensions are:’’. The answer label of the question is:". \n For example: \n Context: \n Facts: Toby is not noisy. Toby is handsome.…. Default Rules: If someoneA is handsome then he is delicious, unless he is not drab. If someoneA is not noisy then he is not drab, unless he is delicious. This context can generate two extensions: The extension 1 are: " Toby is not noisy. Toby is handsome. Toby is delicious."; \n The extension 2 are " Toby is not noisy. Toby is handsome. Toby is not drab.". \n If the Question is: Toby is not noisy. Since all expansions can infer the query " Toby is not noisy.", so the answer label for the question is: True. ; \n If the question is: Toby is not drab. Although extension 2 can deduce the query " Toby is not drab ", extension 1 cannot, so the answer label for the question is: Unknown; \n If the question is: Toby is not handsome. Since all three extensions can lead to the query "Toby is handsome", so the answer label for the question is: False. \n Please read the context carefully. Let\'s think step by step.'
Few_Shot_COT_Extensions_Shot_Credulous_Instruction = 'Task Description: \n Given contexts and question, the context consists of facts and default rules. You first need to generate all extensions based on the given context and then answer the question according to the extensions. An extension is a set of non-contradictory facts and conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to find all the extensions according to the above steps. Next, the answer to the question is generated based on the generated extension. If the question can be inferred under a certain extension, the answer label of the question is: "True"; If the negation of the question can be inferred under a certain extension, the answer label of the question is: "False"; If the question and the negation of the question both cannot be deduced under all extension, the answer label of the question is: "Unknown". \n Each context has a question, and the input format is Context: ‘Facts:‘’, Default Rules:’’’. Question:". You must generate all extensions and answer the question according to the extensions. \n For example: \n Context: \n Facts: Toby is not noisy. Toby is handsome.…. Default Rules: If someoneA is handsome then he is delicious, unless he is not drab. If someoneA is not noisy then he is not drab, unless he is delicious.  The context can generate two extensions: The extension 1 are: " Toby is not noisy. Toby is handsome. Toby is delicious."; \n The extension 2 are " Toby is not noisy. Toby is handsome. Toby is not drab.". \n If the question is: Toby is not drab. Since extension 2 can lead to the query " Toby is not drab ", so the answer label for the question is True; \n If the question is: Toby is intelligent. Since extensions 1 and 2 cannot deduce the query and the negation of the query, so the answer label for the question is Unknown; \n If the question is: Toby is not handsome. Since the negation of query fact " Toby is handsome." can be derived in extensions, so the answer label for the question is: False. \n Please read the context carefully. Let\'s think step by step.'
Three_COT_Extensions_Shot_Skeptical_Instruction = 'Task Description: \n Given contexts and question, you need to first generate all extensions based on given context, then answer the questions according to the extensions. The context contains facts and a default rule, The default rule format is: If A then B, unless C. The A is the prerequisite, the B is the conclusion, and the C is called the justifications. The "If A then B, unless C." means that if the preconditions A are in the facts, and the justifications C is not in the facts, then you can deduce the conclusion B. The answers to the questions are labeled "True", "False" and "Unknown". An extension is a collection of consistent facts generated by reasoning about the context. \n If the question can be inferred under all extensions, and the negation of the question cannot be inferred under all extensions, the answer label of the question is: "True"; \n if the negation of the question can be inferred under all extensions based on the context, and the question cannot be inferred under all extensions, the answer label of the question is: "False"; \n If the question and the negation of the question cannot be deduced under a certain extension, the answer label of the question is: "Unknown". \n Each context has a question, and the input format is Context: ". Question:". You must generate answer labels for each question. The output format is: The answer label of the question is:".  \n for example, Context: Hanna is nervous. Hanna is not fuzzy. Hanna is not quiet. Hanna is rainy. Hanna is not inquisitive. Hanna is dizzy. Hanna is courteous. Hanna is tense. Hanna is not green. Hanna is entire. Hanna is famous. Hanna is gifted. Hanna is tough. If someoneA is nervous and gifted then he is boring, unless he is important. If someoneA is courteous and boring then he is oak, unless he is not historical or he is embarrassed. If someoneA is not inquisitive then he is practical, unless he is excited or he is happy. If someoneA is not quiet and famous then he is embarrassed, unless he is oak or he is impressive. If someoneA is oak and tough then he is excited, unless he is practical or he is not obedient. If someoneA is not fuzzy then he is not obedient, unless he is not embarrassed or he is excited. If someoneA is tense and excited then he is important, unless he is boring or he is not mean. If someoneA is not green and entire then he is impressive, unless he is not quaint or he is embarrassed. If someoneA is embarrassed and rainy then he is troubled, unless he is excited. If someoneA is dizzy then he is not magnificent, unless he is not long or he is not exciting. We can deduce three extensions based on the context. The extension 1 are: " Hanna is excited. Hanna is impressive. Hanna is not magnificent. Hanna is boring. Hanna is oak.”;  and the extension 2 are "Hanna is not obedient. Hanna is not magnificent. Hanna is practical. Hanna is boring. Hanna is troubled. Hanna is embarrassed."; and extensions 3 are: "Hanna is not obedient. Hanna is impressive. Hanna is not magnificent. Hanna is practical. Hanna is boring. Hanna is oak.". \n If the Question is: Hanna is not boring. Since all expansions can infer the negation of the query "Hanna is boring"，so the answer label for the question is: False. ; \n If the question is: Hanna is oak. Although extensions 1 and 3 can deduce the query "Hanna is oak", extension 2 cannot deduce this query，so the answer label for the question is: Unknown; \n If the question is: Hanna is not magnificent. Since all three extensions can lead to the query "Hanna is not magnificent"，so the answer label for the question is: True.  \n Note that you only need to generate all extensions and answer label for the question. Please read the context carefully and answer the questions.'
Three_COT_Extensions_Shot_Credulous_Instruction = 'Task Description: \n Given contexts and question, you need to first generate all extensions based on given context, then answer the questions according to the extensions. The context contains facts and a default rule, The default rule format is: If A then B, unless C. The A is the prerequisite, the B is the conclusion, and the C is called the justifications. The "If A then B, unless C." means that If the preconditions A are in the facts, and the justifications C is not in the facts, then you can deduce the conclusion B. The answers to the questions are labeled "True", "False" and "Unknown". An extension is a collection of consistent facts generated by reasoning about the context. \n If the question can be inferred under a certain extension, the answer label of the question is: "True"; \n if the negation of the question can be inferred under a certain extension, the answer label of the question is: "False"; \n If the question and the negation of the question both cannot be deduced under all extension, the answer label of the question is: "Unknown".  \n Each context has three questions, and the input format is Context: ". Question:". The output format is: The answer label of question is:". You must generate answer labels for each question. \n For example, Context: Robert discriminate Kathryn. Robert is superior. Robert is courteous. Robert is not quaint. Robert is logical. Robert is not lonely. Robert is not additional. Robert is not crooked. Robert is not unfair. Robert is not busy. Robert is not determined. Robert is environmental. Robert is not fresh. Robert is massive. If someoneA is not fresh and environmental then he is tremendous, unless he is long. If someoneA is not quaint and tremendous then he is not elated, unless he is hypocritical. If someoneA is not crooked then he is not outrageous, unless he is creepy or he is not similar. If someoneA is massive and not determined then he is hypocritical, unless he is not elated or he is not happy. If someoneA discriminate someoneB and someoneA is not additional then he is long, unless he is tremendous or he is not untidy. If someoneA is superior and logical then he is impossible, unless he is tremendous. If someoneA is not lonely and not unfair then he is not pleasant, unless he is impossible. If someoneA is not pleasant then he is not happy, unless he is hypocritical or he is not courageous. If someoneA is not busy and courteous then he is gifted, unless he is tremendous or he is realistic. If someoneA is not tremendous then he is not untidy, unless he is not similar or he is long. We can deduce three extensions based on the context. The extension 1 are: "Robert is long. Robert is not outrageous. Robert is impossible. Robert is hypocritical. Robert is gifted."; The extension 2 are: "Robert is tremendous. Robert is not outrageous. Robert is not pleasant. Robert is not happy. Robert is not elated."; The extension 3 are: "Robert is not pleasant. Robert is hypocritical. Robert is tremendous. Robert is not outrageous.". \n If the question is: Robert is not untidy. Since none of the three extensions can lead to the query "Robert is not untidy", so the answer label for the question is: Unknown; \n If the question is: Robert is not tremendous. Since extensions 2 and 3 can deduce the negation of query fact “Robert is tremendous.”, so the answer label for the question is: False; \n If the question is: Robert is not elated.  Since the query fact "Robert is not elated." can be derived in Extension 2, so the answer label for the question is: True. \n Note that you only need to generate the answer label for the question, without giving an explanation or justification. Please read the context carefully and answer the questions. '



Yeliang_API_Key = "sk-6s04MlOTPcivLzH6B7316e8813Dd457a956129E803Eb8736"

Gemma_Model_7B = None
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig

bnb_config = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_use_double_quant=True, bnb_4bit_quant_type="nf4",bnb_4bit_compute_dtype=torch.bfloat16)
if LLMs_Models_Choise == 'Gemma2_7B':
    Gemma_Model_tokenizer = AutoTokenizer.from_pretrained("/home/yeliangxiu/Projects/Pre_trained_Models/Gemma-2-9B-it")
    Gemma_Model_7B = AutoModelForCausalLM.from_pretrained("/home/yeliangxiu/Projects/Pre_trained_Models/Gemma-2-9B-it", quantization_config = bnb_config,device_map="cuda")
    Gemma_Model_tokenizer.pad_token = Gemma_Model_tokenizer.eos_token
    Gemma_Model_tokenizer.padding_side = "right"

if LLMs_Models_Choise == 'Mistral_7B':
    Mistral_7B_model = AutoModelForCausalLM.from_pretrained("/home/yeliangxiu/Projects/Pre_trained_Models/Mistral-7B-Instruct_v0.2", quantization_config=bnb_config, device_map="cuda")
    Mistral_7B_model_tokenizer = AutoTokenizer.from_pretrained("/home/yeliangxiu/Projects/Pre_trained_Models/Mistral-7B-Instruct_v0.2")
    Mistral_7B_model_tokenizer.pad_token = Mistral_7B_model_tokenizer.eos_token
    Mistral_7B_model_tokenizer.padding_side = "right"

llama3_8B_model, llama3_model_tokenizer = None, None
if LLMs_Models_Choise == 'LLAMA3':
    llama3_8B_model = AutoModelForCausalLM.from_pretrained("/home/yeliangxiu/Projects/Pre_trained_Models/Meta-Llama-3-8B", quantization_config=bnb_config, device_map="cuda")
    llama3_model_tokenizer = AutoTokenizer.from_pretrained("/home/yeliangxiu/Projects/Pre_trained_Models/Meta-Llama-3-8B")
    llama3_model_tokenizer.pad_token = llama3_model_tokenizer.eos_token
    llama3_model_tokenizer.padding_side = "right"
def Gemma_7B_LLMs(instructions, context, question):
    input_text = instructions + context + question
    input_ids = Gemma_Model_tokenizer(input_text, return_tensors="pt").to("cuda")

    outputs = Gemma_Model_7B.generate(**input_ids, pad_token_id=Gemma_Model_tokenizer.eos_token_id, max_new_tokens=100)
    Gemma_LLMs_response_output = Gemma_Model_tokenizer.batch_decode(outputs.detach().cpu().numpy(), skip_special_tokens=True)[0][len(input_text):]
    print('Gemma_LLMs_response_output={}'.format(Gemma_LLMs_response_output))
    return Gemma_LLMs_response_output

def Mistral_7B_LLMs(instructions, context, question):
    device = "cuda"  # the device to load the model onto
    input_text = instructions + context + question
    messages = [
       # {"role":"assistant","content": instructions},
        {"role": "user", "content": input_text}
    ]
    encodeds = Mistral_7B_model_tokenizer.apply_chat_template(messages, return_tensors="pt")
    input_ids = encodeds.to(device)
    outputs = Mistral_7B_model.generate(input_ids, pad_token_id=Mistral_7B_model_tokenizer.eos_token_id,max_new_tokens=100, do_sample=True)

    generated_ids = [output_ids[len(input_ids):] for input_ids, output_ids in zip(input_ids, outputs)]
    Mistral_LLMs_response_output = Mistral_7B_model_tokenizer.batch_decode(generated_ids)
    print('Mistral_LLMs_response_output={}'.format(Mistral_LLMs_response_output))
    return Mistral_LLMs_response_output
def LLAMA3_generate_text(Instruction, Context_Text_String, Question_Text_String):
    Test_prompt = f"""###Instruction:{Instruction}###Context: {Context_Text_String}###Question: {Question_Text_String}\n### Response: The answer label for the question is:"""
    input_ids = llama3_model_tokenizer(Test_prompt, return_tensors="pt", truncation=True).input_ids.cuda()
    attention_mask = torch.ones(input_ids.shape, dtype=torch.long, device='cuda')
    outputs = llama3_8B_model.generate(input_ids=input_ids, max_new_tokens=100, pad_token_id=llama3_model_tokenizer.eos_token_id, do_sample=True, top_p=0.9, temperature=0.5)
    # result_output = llama3_model_tokenizer.batch_decode(outputs.detach().cpu().numpy(), skip_special_tokens=True)[0][len(Test_prompt)-35:]

    generated_ids = [output_ids[len(input_ids):] for input_ids, output_ids in zip(input_ids, outputs)]
    # Decode the response
    LLMs_response_output = llama3_model_tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0]
    print('LLMs_response_output={}'.format(LLMs_response_output))
    return LLMs_response_output




def Read():
    with open(Read_Data_file, 'r') as f0, open(Write_file_path02, 'w', encoding='utf-8') as f1:
        Total_Question_label_List = []
        Total_LLMs_Generted_Label_List = []
        Total_count01 = 1
        Test_Extension_Example_Dict ={}
        Test_Extension_Example_Dict01 = {2: 0, 1: 0, 4: 0, 3: 0, 5: 0}

        for line in f0:
            # if Total_count01<=4:
            #     Total_count01 = Total_count01 + 1
            #     continue
            Write_Dict = {}  # 该字典用于存储需要写入的样本字典
            LLMs_Generted_Label_List = []
            LLMs_Generted_Answer_Set_Explanation_List = []
            js = json.loads(line.strip())
            # 将数据集划分成训练/验证/测试
            # print(json.dumps(js, ensure_ascii=False))
            Sample_number = js['Sample_number']
            Origin_Facts = js['Origin_Facts']
            Facts_number = js['Facts_number']  # 计算缺省理论中事实的个数
            Defalut_Rules = js['Defalut_Rules']
            # Noise_Facts_Lists = js['Noise_Facts_Lists']
            NL_Origin_Facts = js['NL_Origin_Facts']
            NL_Defalut_Rules = js['NL_Defalut_Rules']
            # NL_Noise_Facts_Lists = js['NL_Noise_Facts_Lists']

            # Noise_Default_Rules_Lists = js['Noise_Default_Rules_Lists']
            # NL_Noise_Default_Rule_Lists = js['NL_Noise_Default_Rule_Lists']
            Origin_ASP_extension_number = js['Origin_ASP_extension_number']
            Origin_Question_Text_Lists = js['Origin_Question_Text_Lists']
            NL_Origin_Question_Text = js['NL_Origin_Question_Text']
            Origin_Question_Label_Lists = js['Origin_Question_Label_Lists']
            Origin_Question_proof_List = js['Origin_Question_proof_List']
            NL_Origin_Question_proof_Text = js['NL_Origin_Question_proof_Text']

            # # # 每个扩展数量的样本测试20个
            # if Origin_ASP_extension_number not in Test_Extension_Example_Dict.keys():
            #     Test_Extension_Example_Dict[Origin_ASP_extension_number] = 1
            #     if Test_Extension_Example_Dict[Origin_ASP_extension_number] <= Test_Extension_Example_Dict01[
            #         Origin_ASP_extension_number]:
            #         Total_count01 = Total_count01 + 1
            #         continue
            # else:
            #     if Test_Extension_Example_Dict[Origin_ASP_extension_number] >= 40:
            #         Total_count01 = Total_count01 + 1
            #         continue
            #     else:
            #         Test_Extension_Example_Dict[Origin_ASP_extension_number] = Test_Extension_Example_Dict[Origin_ASP_extension_number] + 1
            #         if Test_Extension_Example_Dict[Origin_ASP_extension_number] <= Test_Extension_Example_Dict01[
            #             Origin_ASP_extension_number]:
            #             Total_count01 = Total_count01 + 1
            #             continue

            Answer_Set_List = []
            if Total_count01 <= -1:
                print('Test_Extension_Example_Dict={}'.format(Test_Extension_Example_Dict))
                continue

            Instruction = ''
            if Zero_or_Few_Shot == 'Zero_Shot' and Reasoning_Mode == 'credulous':
                Instruction = Zero_Shot_Credulous_Instruction
            elif Zero_or_Few_Shot == 'Zero_Shot' and Reasoning_Mode == 'skeptical':
                Instruction = Zero_Shot_Skeptical_Instruction
            elif Zero_or_Few_Shot == 'Few_Shot' and Reasoning_Mode == 'credulous':
                Instruction = Three_Few_Shot_Credulous_Instruction
            elif Zero_or_Few_Shot == 'Few_Shot' and Reasoning_Mode == 'skeptical':
                Instruction = Three_Few_Shot_Skeptical_Instruction
            elif Zero_or_Few_Shot == 'Zero_Shot_COT' and Reasoning_Mode == 'credulous':
                Instruction = Zero_Shot_COT_Extensions_Shot_Credulous_Instruction
            elif Zero_or_Few_Shot == 'Zero_Shot_COT' and Reasoning_Mode == 'skeptical':
                Instruction = Zero_Shot_COT_Extensions_Shot_Skeptical_Instruction
            elif Zero_or_Few_Shot == 'Few_Shot_COT' and Reasoning_Mode == 'credulous':
                Instruction = Few_Shot_COT_Extensions_Shot_Credulous_Instruction
            elif Zero_or_Few_Shot == 'Few_Shot_COT' and Reasoning_Mode == 'skeptical':
                Instruction = Few_Shot_COT_Extensions_Shot_Skeptical_Instruction
            elif Zero_or_Few_Shot == 'COT_Extensions' and Reasoning_Mode == 'credulous':
                Instruction = Three_COT_Extensions_Shot_Credulous_Instruction
            elif Zero_or_Few_Shot == 'COT_Extensions' and Reasoning_Mode == 'skeptical':
                Instruction = Three_COT_Extensions_Shot_Skeptical_Instruction

            Context_Text_String = NL_Origin_Facts
            Context_Text_String = Context_Text_String + NL_Defalut_Rules
            Question_Text_String = ''
            for question_key in range(len(NL_Origin_Question_Text)):
                question_text = NL_Origin_Question_Text[question_key]
                Question_Text_String = question_text
                question_label = Origin_Question_Label_Lists[question_key]
                Total_Question_label_List.extend(Label_Dict[question_label[0]])
                # 调用大模型预测
                results = None
                if LLMs_Models_Choise == 'LLAMA3':
                    results = LLAMA3_generate_text(Instruction, Context_Text_String, Question_Text_String)
                elif LLMs_Models_Choise =='Gemma_7B':
                    results = Gemma_7B_LLMs(Instruction, Context_Text_String, Question_Text_String)
                elif LLMs_Models_Choise =='Mistral_7B':
                    results = Mistral_7B_LLMs(Instruction, Context_Text_String, Question_Text_String)

                ### 添加一个函数用于对大模型生成结果的格式进行判断，如何不符合格式，则重新生成。
                # 对生成的结果进行分析
                # print("Total_count01={}, LLMs Results = {}".format(Total_count01, results))
                predict_label = None
                if 'unknown' in results or 'Unknown' in results:
                    predict_label = 'M'
                elif 'true' in results or 'True' in results:
                    predict_label = 'T'
                elif 'false' in results or 'False' in results:
                    predict_label = 'F'
                else:
                    predict_label = 'M'
                LLMs_Generted_Label_List.append([predict_label])

                Total_LLMs_Generted_Label_List.extend(Label_Dict[predict_label])

            print('Model tested: Total_count01={}, Total_LLMs_Generted_Label_List = {}, Origin_Question_Label_Lists: = {}'.format(Total_count01, LLMs_Generted_Label_List, Origin_Question_Label_Lists))

            Write_Dict['Sample_number'] = Sample_number  # 样本个数
            Write_Dict['Origin_ASP_extension_number'] = Origin_ASP_extension_number
            Write_Dict['NL_Origin_Question_Text'] = NL_Origin_Question_Text
            Write_Dict['Origin_Question_Label_Lists'] = Origin_Question_Label_Lists
            Write_Dict['LLMs_Generated_Question_Label_Lists'] = LLMs_Generted_Label_List

            Write_Dict['Origin_Question_proof_List'] = Origin_Question_proof_List
            Write_Dict['NL_Origin_Question_proof_Text'] = NL_Origin_Question_proof_Text
            Write_Dict['LLMs_Generated_Question_Explanation_Lists'] = ''
            Write_Dict['LLMs_Repose'] = ''
            Write_Dict = json.dumps(Write_Dict, ensure_ascii=False)
            f1.write(Write_Dict + '\n')
            Total_count01 = Total_count01 + 1


        accuracy = accuracy_score(Total_Question_label_List, Total_LLMs_Generted_Label_List) # 计算准确率
        F1 = f1_score(Total_Question_label_List, Total_LLMs_Generted_Label_List,average = 'macro')
        print('accuracy={},F1={}'.format(accuracy,F1))


if __name__ == '__main__':
    Read()
