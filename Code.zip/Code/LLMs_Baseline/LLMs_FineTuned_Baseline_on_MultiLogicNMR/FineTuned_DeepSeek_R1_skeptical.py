import copy
import sys
import re
import httpx
import torch
sys.path.append('../../Dataset')
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ["NCCL_P2P_DISABLE"] = "1"
os.environ["NCCL_IB_DISABLE"] = "0"
os.environ['WANDB_MODE'] = 'dryrun'
from unsloth import FastLanguageModel, PatchFastRL
PatchFastRL("GRPO", FastLanguageModel)  # 为GRPO算法打补丁以加速训练
import difflib
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
import json


from trl import SFTTrainer, DataCollatorForCompletionOnlyLM
from transformers import TrainingArguments
from datasets import load_dataset
from huggingface_hub import login
from huggingface_hub import notebook_login
max_seq_length = 2048
from datasets import Dataset
import pandas as pd
import numpy as np
from random import randrange
Train_Number = 5000 # 1000, 2000,5000, 10000, 15000, 20000

Reasoning_Mode = 'skeptical' # [credulous, skeptical]
Dataset_Name = 'MultiLogicNMR'
Dataset_Category = 'test' # ['train', 'dev', 'test']
Zero_or_Few_Shot = 'Zero_Shot' # ['Zero_Shot','Few_Shot']
OOD_Flag = False
LLMs_Generate = True

Noise_Flag = False

Noise_Name = '_Noise' if Noise_Flag ==True else ''
Noise_Length = 100 if  Noise_Flag == True else ''

OOD_Data_Path = "OOD_Datasets" if OOD_Flag == True else ''
OOD_read_filename = "_ood" if OOD_Flag == True else ''
OOD_write_filename = "ood_" if OOD_Flag == True else ''
LLMs_Generate_Datasets = 'GPT4_LLMs_Generated_' if LLMs_Generate == True else ''
if OOD_Flag == True:
    read_file_path = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Datasets/' + OOD_Data_Path + '/'
elif LLMs_Generate == True:
    read_file_path = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/LLMs_Generate_Datasets/' + Reasoning_Mode + '/'
else:
    read_file_path = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Datasets/' + Reasoning_Mode + '/'

write_file_path = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Experimens/LLMs_Results/'
ASP_extension_number_Min, ASP_extension_number_Max = 1,5 #用于对回答集进行过滤
if OOD_Flag == True:
    ASP_extension_number_Min, ASP_extension_number_Max = 6,16

LLMs_Models_Choise = "DeepSeek_R1" #['GPT3.5','GPT4','DeepSeek_R1','Claude','Gemma_7B','Mistral_7B', 'llama3']
Read_Train_Data_file = read_file_path + Reasoning_Mode + '_multiNMR_' + 'train' + '_' + str(ASP_extension_number_Min) + '_' + str(ASP_extension_number_Max) + '_balance' + OOD_read_filename + '.json'
Read_Test_Data_file = read_file_path + LLMs_Generate_Datasets + Reasoning_Mode + '_multiNMR_' + 'test' + '_' + str(ASP_extension_number_Min) + '_' + str(ASP_extension_number_Max) + '_balance' + OOD_read_filename + Noise_Name + str(Noise_Length) + '.json'

Write_file_path02 = write_file_path + Zero_or_Few_Shot +'_'+ LLMs_Models_Choise + '_FinedTune_result_on_'+ Dataset_Name +'_'+ OOD_write_filename + LLMs_Generate_Datasets + Reasoning_Mode + '_'+ Dataset_Category +'_'+str(ASP_extension_number_Min)+'_'+str(ASP_extension_number_Max)+ '_balance' + Noise_Name + str(Noise_Length) + '_' + str(Train_Number) + '.json'


Label_Dict = {'F':[0],'T':[1],'M':[2]}
# 提示要求同时回答多个问题。
# Zero_Shot_Skeptical_Instruction = 'You are an expert in non-monotonic reasoning and are asked to generate answer labels and answer set explanations for questions in a given context. The answers to the questions are labeled "True", "False" and "Unknown". The answer set explanations are all intermediate conclusions generated under a certain reasoning path based on context, where intermediate conclusions are the conclusions generated when applying rules for reasoning. The set of intermediate conclusions generated under a certain reasoning path cannot contradict each other. Since there may be many different paths of reasoning, there may be multiple answer set explanations. If the question can be inferred under all reasoning paths based on the context, and the negation of the question cannot be inferred under all reasoning paths based on the context, the answer label of the question is "True", and needs to generate all answer set explanations that contain the question; if the negation of the question can be inferred under all reasoning path based on the context, and the question cannot be inferred under all reasoning path based on the context, the answer label of the question is "False", and needs to generate all answer set explanations that contain the negation of question; If the question and the negation of the question cannot be deduced under a certain reasoning path based on the context, the answer label of the question is "Unknown", and needs to generate all the answer set explanations than cannot contain the question and all the answer set explanations that cannot contain the negation of the question. Each context has three questions, and the input format is Context: ". Question 1:". Question 2:". Question 3:". You must generate answer labels and answer set explanations for each question. The output format is: The answer label of question 1 is:", The answer set explanations of question 1 is: explanation 1:''.,...,. Explanation n:''. The answer label of question 2 is:", The answer set explanations of question 2 is: Explanation 1:''.,...,. Explanation n:''. The answer label of question 3 is:", The answer set explanations of question 3 is: Explanation 1:''.,...,. Explanation n:''. Please read the context carefully and answer the questions. '
# Zero_Shot_Credulous_Instruction = 'You are an expert in non-monotonic reasoning and are asked to generate answer labels and answer set explanations for questions in a given context. The answers to the questions are labeled "True", "False" and "Unknown". The answer set explanations are all intermediate conclusions generated under a certain reasoning path based on context, where intermediate conclusions are the conclusions generated when applying rules for reasoning. The set of intermediate conclusions generated under a certain reasoning path cannot contradict each other. Since there may be many different paths of reasoning, there may be multiple answer set explanations. If the question can be inferred under a certain reasoning path based on the context, the answer label of the question is "True" and needs to generate all answer set explanations that contain the question; if the negation of the question can be inferred under a certain reasoning path based on the context, the answer label of the question is "False", and needs to generate all answer set explanations that contain the negation of question; If the question and the negation of the question both cannot be deduced under all reasoning path based on the context, the answer label of the question is "Unknown". It needs to generate all the answer set explanations that can not contain the question and all the answer set explanations that can not contain the negation of the question. Each context has three questions, and the input format is Context: ", question 1:", question 2:", question 3:". Please read the context carefully and answer the questions. You must generate answer labels and answer set explanations for each question. The output format is: The answer label of question 1 is:", The answer set explanations of question 1 is: Explanation 1:''.,...,. Explanation n:''. The answer label of question 2 is:". The answer set explanations of question 2 is: Explanation 1:''.,...,. Explanation n:''. The answer label of question 3 is:". The answer set explanations of question 3 is: Explanation 1:''.,...,. Explanation n:''.'

Zero_Shot_COT_Extensions_Skeptical_Instruction = 'Task Description: \n Given contexts and question, and the context consists of facts and default rules. You need first to find all extensions based on the given context and then to answer the question according to the extensions. An extension is a set of non-contradictory conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to generate all the extensions. Next, the answer to the question is generated based on the generated extension.\n If the question can be inferred under all extensions, and the negation of the question cannot be inferred under all extensions, the answer label of the question is: "True"; \n If the negation of the question can be inferred under all extensions, and the question cannot be inferred under all extensions, the answer label of the question is: "False"; \n If the question and the negation of the question cannot be deduced under a certain extension, the answer label of the question is: "Unknown". \n  The input format is: The context are:''. \n The ouput format is: The answer of the question is:''. ### \n You must find all extensions and the answer of the question.  \n Please read the context carefully. Let\'s think step by step.'
Zero_Shot_COT_Extensions_Credulous_Instruction = 'Task Description: \n Given contexts and question, the context consists of facts and default rules. You first need to find all extensions based on the given context and then answer the question according to the extensions. An extension is a set of non-contradictory facts and conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to find all the extensions according to the above steps. Next, the answer to the question is generated based on the generated extension. \n If the question can be inferred under a certain extension, the answer label of the question is: "True"; \n If the negation of the question can be inferred under a certain extension, the answer label of the question is: "False"; \n If the question and the negation of the question both cannot be deduced under all extension, the answer label of the question is: "Unknown". \n  The input format is: The context are:''. The questions is:''. \n The output format is:  The answer of the question is:''. ###  \n You must generate all extensions and the answer of the question. \n Please read the context carefully. Let\'s think step by step.'
Few_Shot_COT_Extensions_Skeptical_Instruction = 'Task Description: \n Given contexts and question, and the context consists of facts and default rules. You need first to generate all extensions based on the given context and then to answer the question according to the extensions. An extension is a set of non-contradictory conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to generate all the extensions. Next, the answer to the question is generated based on the generated extension.\n If the question can be inferred under all extensions, and the negation of the question cannot be inferred under all extensions, the answer label of the question is: "True"; \n If the negation of the question can be inferred under all extensions, and the question cannot be inferred under all extensions, the answer label of the question is: "False"; \n If the question and the negation of the question cannot be deduced under a certain extension, the answer label of the question is: "Unknown". \n  The input format is: The context are:''. \n The ouput format is: The answer of the question is:''. ### \n The extensions are:''.### \n  For example: The context are: "Connor is not lovely.Connor is poor.Connor is not wonderful.Connor is not former.Connor is wicked.Connor is not comfortable.Connor is not oval.Connor is not cultural.Connor is old.Connor is not hungry.Connor does not honour Godfrey.Connor is awful.Connor is not long.If someoneA is not long then he is not immediate,unless he is not giant or he is sparkling.If someoneA is awful and not alert then he is not creative ,unless he is decent.If someoneA is not wonderful then he is civil,unless he is not substantial or he is not zany.If someoneA is not immediate and he does not honour someoneB then he is not giant ,unless he is not immediate.If someoneA is wicked then he is decent,unless he is not creative or he is significant.If someoneA is not comfortable and not giant then he is sparkling,unless he is not decent or he is not immediate.If someoneA is old and not lovely then he is not hollow,unless he is not giant or he is not crowded.If someoneA is not former and not hungry then he is not alert,unless he is hard or he is not immediate.If someoneA is not oval then he is cheap,unless he is not energetic or he is not technical.If someoneA is poor and not cultural then he is not crowded,unless he is oval or he is not hollow.". \n The question is:"Connor is civil.". ### \n The answer of the question is:"True". ### \n The extensions are:"[["Connor is civil.", "Connor is decent.", "Connor is cheap.", "Connor is not crowded.", "Connor is not immediate."], ["Connor is civil.", "Connor is decent.", "Connor is cheap.", "Connor is not hollow.", "Connor is not immediate."]]".### \n You must generate all extensions and the answer of the question.  \n Please read the context carefully. Let\'s think step by step.'
Few_Shot_COT_Extensions_Credulous_Instruction = 'Task Description: \n Given contexts and question, the context consists of facts and default rules. You first need to generate all extensions based on the given context and then answer the question according to the extensions. An extension is a set of non-contradictory facts and conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to find all the extensions according to the above steps. Next, the answer to the question is generated based on the generated extension. \n If the question can be inferred under a certain extension, the answer label of the question is: "True"; \n If the negation of the question can be inferred under a certain extension, the answer label of the question is: "False"; \n If the question and the negation of the question both cannot be deduced under all extension, the answer label of the question is: "Unknown". \n  The input format is: The context are:''. The questions is:''. \n The output format is: The answer of the question is:''. ### \n The extensions are:''. ### \n  For example, ### \n The context are: "Lancelot is significant.Lancelot is not attractive.Lancelot is teak.Lancelot does not embarrass Patricia.Lancelot is not fair.Lancelot is lovely.Lancelot is jolly.Lancelot is expensive.Lancelot is not anxious.Lancelot is dry.Lancelot is energetic.Lancelot is several.Lancelot does not mock Patricia.Lancelot is not octagonal. If someoneA is not anxious and not fair then he is persistent,unless he is old or he is soft.If someoneA is not attractive and not broad minded then he is not granite ,unless he is not wild.If someoneA is significant and not octagonal then he is melodic ,unless he is not shiny.If someoneA is dry then he is not shiny ,unless he is melodic.If someoneA is several and he does not embarrass someoneB then he is prickly ,unless he is technical or he is melodic.If someoneA is persistent then he is not wild,unless he is former or he is not granite.If someoneA does not mock someoneB and someoneA is energetic then he is technical ,unless he is oval or he is prickly.If someoneA is teak then he is not fat,unless he is not granite or he is not prickly.If someoneA is lovely then he is not broad minded ,unless he is not granite.If someoneA is jolly and expensive then he is not sparkling,unless he is not crowded or he is not granite." The questions is:"Lancelot is not persistent.". #### \n The answer of the question is:"False". ### \n The extensions are:"[["Lancelot is prickly.", "Lancelot is not sparkling.", "Lancelot is not fat.", "Lancelot is not broad minded.", "Lancelot is not shiny.", "Lancelot is not wild.", "Lancelot is persistent."], ["Lancelot is not sparkling.", "Lancelot is technical.", "Lancelot is not fat.", "Lancelot is not broad minded.", "Lancelot is not wild.", "Lancelot is melodic.", "Lancelot is persistent."], ["Lancelot is not sparkling.", "Lancelot is technical.", "Lancelot is not fat.", "Lancelot is not broad minded.", "Lancelot is not shiny.", "Lancelot is not wild.", "Lancelot is persistent."]]". ###\n  You must generate all extensions and the answer of the question. \n Please read the context carefully. Let\'s think step by step.'
Exact_Extensions_Pattern = "(?<=extensions are:).*?(?=Note|#|The answer |The answer label for the question|<end_of_turn>)"
Extract_Answer_Pattern = "(?<=the question is:).*?(?=Note|#|\.|extensions are|The explanation is|\;|<end_of_turn>|Step-by-step|```｜Instruction|1```1)"

Train_Dataset, Test_Datset = None, None
Label2Text = {'T':'True', 'F':'False', 'M':'Unknown'}
Train_Instruction, Test_Instruction = '',''
Train_Instruction = Zero_Shot_COT_Extensions_Skeptical_Instruction if Reasoning_Mode =='skeptical' else Zero_Shot_COT_Extensions_Credulous_Instruction
Test_Instruction = Few_Shot_COT_Extensions_Skeptical_Instruction if Reasoning_Mode =='skeptical' else Few_Shot_COT_Extensions_Credulous_Instruction
# 定义一个读取文件的函数
def Read_Train_Dataset(Train_Dev_Test_Flag):
    with open(Read_Train_Data_file, 'r', encoding='utf-8') as f0:
        All_Sample_List = []
        for line in f0:
            js = json.loads(line.strip())
            # 将数据集划分成训练/验证/测试
            NL_Origin_Facts = js['NL_Origin_Facts']
            NL_Defalut_Rules = js['NL_Defalut_Rules']
            NL_Origin_Question_Text = js['NL_Origin_Question_Text']
            Origin_Question_Label_Lists = js['Origin_Question_Label_Lists']
            NL_Origin_Question_proof_Text = js['NL_Origin_Question_proof_Text']
            # 在谨慎推理模式下，“M”标签的推理路径存储的是所有的回答集，而在怀疑推理模式下，“T”标签的推理路径存储的是所有的回答集
            Origin_Answer_Set_List = None
            if Reasoning_Mode=="credulous":
                for key in range(len(NL_Origin_Question_proof_Text)):
                    if "M" in NL_Origin_Question_proof_Text[key].keys():
                        Origin_Answer_Set_List = NL_Origin_Question_proof_Text[key]["M"]
                        break
            else:
                for key in range(len(NL_Origin_Question_proof_Text)):
                    if "T" in NL_Origin_Question_proof_Text[key].keys():
                        Origin_Answer_Set_List = NL_Origin_Question_proof_Text[key]["T"]
                        break
            Context = NL_Origin_Facts + NL_Defalut_Rules

            for question_key in range(len(NL_Origin_Question_Text)):
                sample_list01 = []
                sample_list01.append('### Instruction:'+Train_Instruction)
                sample_list01.append('### Context:'+ Context)
                sample_list01.append('### Question:'+ NL_Origin_Question_Text[question_key])
                sample_list01.append('\n ### Response: The extensions are:' + str(Origin_Answer_Set_List) + ' The answer label for the question is:' + Label2Text[Origin_Question_Label_Lists[question_key][0]])
                All_Sample_List.append(sample_list01)
        df = pd.DataFrame(All_Sample_List, columns=['Instruction','Context','Question', 'Answer'])
    return df

# 定义一个函数，用于格式化数据集
# def LLAMA_format_instruction(sample):
#     formal_text = f"""### Instruction: {Zero_Shot_Skeptical_Instruction}### Context: {sample['Context']}###Question: {sample['Question']}\n ### Response: {sample['Answer']}"""
#     return [formal_text]

def LLAMA_format_instruction(sample):
    output_texts = []
    if isinstance(sample['Context'], list):
        for i in range(len(sample['Context'])):
            text = f"""### Instruction: {Train_Instruction}### The context are: {sample['Context'][i]}### The question is: {sample['Question'][i]}\n ### Response: The answer label for the question is: {sample['Answer'][i]}"""
            output_texts.append(text)
    else:
        text = f"""### Instruction: {Train_Instruction}### The context are: {sample['Context']}### The question is: {sample['Question']}\n ### Response: The answer label for the question is: {sample['Answer']}"""
        output_texts.append(text)
    return output_texts


def Train_Test_Dataset():
    # 获取训练数据集
    Train_dataset_df = Read_Train_Dataset(Train_Dev_Test_Flag='train')
    Train_data = Train_dataset_df[['Context','Question', 'Answer']]
    Train_data=Train_data.reset_index(drop=True)
    Train_data = Dataset.from_pandas(Train_data.iloc[0:])
    print('len(train_data)=',len(Train_data))

    # 获取测试训练集
    Test_dataset_df = Read_Train_Dataset(Train_Dev_Test_Flag='test')
    Test_data = Test_dataset_df[['Context','Question', 'Answer']]
    Test_data=Test_data.reset_index(drop=True)
    Test_data = Dataset.from_pandas(Test_data.iloc[0:99])
    print('len(Test_data)=',len(Test_data))
    return Train_data, Test_data


# 2. Load Llama3 model 加载 Llama-3-8B
def Load_FineTune_Model():
    print('Loading model')
    Train_model, Train_tokenizer = FastLanguageModel.from_pretrained(
        model_name = "/home/yeliangxiu/Projects/Pre_trained_Models/DeepSeek-R1-32B", # 指定 Unsloth 库中的确切模型。“Llama3”可能是型号名称，“8b”表示 80 亿个参数，“bnb”可能是指特定的架构，“4bit”表示使用内存效率高的格式。
        max_seq_length = max_seq_length, # 设置最大序列长度（前面定义）以限制模型可以处理的输入长度。
        dtype = None, # （假设它设置为 None）允许库选择最合适的数据类型
        load_in_4bit = True, # 允许以内存高效的 4 位格式加载模型（如果模型和硬件支持）
    )
    Train_tokenizer.pad_token = Train_tokenizer.eos_token
    Train_tokenizer.padding_side = "right"
    print('Model loaded')

    # 进行模型参数设置和快速 LoRA 权重和训练
    # 设置lora架构
    Train_model = FastLanguageModel.get_peft_model(
        Train_model,
        r = 16,
        target_modules = ["q_proj", "k_proj", "v_proj", "o_proj",
                          "gate_proj", "up_proj", "down_proj",],
        lora_alpha = 16,
        lora_dropout = 0, # Supports any, but = 0 is optimized
        bias = "none",    # Supports any, but = "none" is optimized
        use_gradient_checkpointing = True,
        random_state = 3407,
        max_seq_length = max_seq_length,
        use_rslora = False,  # Rank stabilized LoRA
        loftq_config = None, # LoftQ
    )
    return Train_model, Train_tokenizer

print('Model prepared for training')
# 开始训练
def Train_llama3(Train_model, Train_tokenizer, train_data):
    response_template = " ### Response:"
    collator = DataCollatorForCompletionOnlyLM(response_template, tokenizer=Train_tokenizer)
    print('Training model')
    trainer = SFTTrainer(
        model = Train_model,
        train_dataset = train_data,
        max_seq_length = max_seq_length,
        tokenizer = Train_tokenizer,
        # packing=True,
        formatting_func=LLAMA_format_instruction,
        data_collator=collator,
        args = TrainingArguments(
            per_device_train_batch_size = 4,
            gradient_accumulation_steps = 4,
            warmup_steps = 10,
            max_steps = 200,
            fp16 = not torch.cuda.is_bf16_supported(),
            bf16 = torch.cuda.is_bf16_supported(),
            logging_steps = 1,
            # output_dir = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Saved_Models/' + LLMs_Models_Choise + '_FinedTune_result_on_' + Reasoning_Mode + '_multiNMR_'+ Dataset_Category +  '_' + str(Train_Number),
            optim = "adamw_8bit",
            weight_decay = 0.01,
            lr_scheduler_type = "linear",
            seed = 3407,
        ),
    )
    trainer.train()

    print('Model trained')

# 保存模型
def Saved_Model(Train_model, Train_tokenizer):
    print('Saving train model')
    Train_model.save_pretrained('/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Saved_Models/' + LLMs_Models_Choise + '_FinedTune_result_on_' + Reasoning_Mode + '_multiNMR_'+ Dataset_Category + '_lora_model'+  '_' + str(Train_Number))
    # Train_model.save_pretrained_merged('/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Saved_Models/' + LLMs_Models_Choise + '_FinedTune_result_on_' + Reasoning_Mode + '_multiNMR_'+ Dataset_Category+  '_' + str(Train_Number), Train_tokenizer, save_method = "merged_16bit",)
    # model.push_to_hub_merged("Qing666/llama3-8b-oig-unsloth-merged", tokenizer, save_method = "merged_4bit_force", token = "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") # merged_16bit
    # model.push_to_hub("Qing666/llama3-8b-oig-unsloth", tokenizer, save_method = "lora", token = "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")

    print('Trained Model saved')

# 加载预训练好的模型进行测试
def Load_Test_Model():
    # 2. Load Llama3 model 加载 Llama-3-8B
    print('Loading Test model')
    Test_model, Test_tokenizer = FastLanguageModel.from_pretrained(
        model_name = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Saved_Models/' + LLMs_Models_Choise + '_FinedTune_result_on_' + Reasoning_Mode + '_multiNMR_'+ Dataset_Category + '_lora_model' + '_' + str(Train_Number), # +  '_' + str(Train_Number) # 指定 Unsloth 库中的确切模型。“Llama3”可能是型号名称，“8b”表示 80 亿个参数，“bnb”可能是指特定的架构，“4bit”表示使用内存效率高的格式。
        max_seq_length = max_seq_length, # 设置最大序列长度（前面定义）以限制模型可以处理的输入长度。
        dtype = None, # （假设它设置为 None）允许库选择最合适的数据类型
        load_in_4bit = True, # 允许以内存高效的 4 位格式加载模型（如果模型和硬件支持）
    )
    FastLanguageModel.for_inference(Test_model)
    print('Test Model loaded')
    return Test_model, Test_tokenizer

Max_new_tokens = 1000 if OOD_Flag == True else 500
def Test_generate_text(Test_model, Test_tokenizer, prompt):
    input_ids = Test_tokenizer(prompt, return_tensors="pt").input_ids.cuda()
    # attention_mask = torch.ones(input_ids.shape, dtype=torch.long, device='cuda')
    outputs = Test_model.generate(input_ids=input_ids, pad_token_id=Test_tokenizer.eos_token_id, max_new_tokens=Max_new_tokens, do_sample=True, top_p=0.9, temperature=0.5) # max_new_tokens 推理生成的最大标记数
    # LLAMA3_LLMs_response_output01 = Test_tokenizer.batch_decode(outputs.detach().cpu().numpy(), skip_special_tokens=True)[0]
    # LLAMA3_LLMs_response_output = Test_tokenizer.batch_decode(outputs.detach().cpu().numpy(), skip_special_tokens=True)[0][len(prompt)-15:]

    generated_ids = [output_ids[len(input_ids):] for input_ids, output_ids in zip(input_ids, outputs)]
    # Decode the response
    LLAMA3_LLMs_response_output = Test_tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0]
    print(f"\nGenerated Response:\n{LLAMA3_LLMs_response_output}")
    return LLAMA3_LLMs_response_output

import ast
def Test_Model(Test_model, Test_tokenizer, Train_Dev_Test_Flag):
    with open(Read_Test_Data_file, 'r', encoding='utf-8') as f0, open(Write_file_path02, 'a', encoding='utf-8') as f1:
        Total_Question_label_List = []
        Total_LLMs_Generted_Label_List = []
        Total_count01 = 1
        Test_Extension_Example_Dict = {}
        Test_Extension_Example_Dict01 = {6: 0, 8: 0, 10: 0, 12: 0, 16: 0} if OOD_Flag == True else {2: 0, 1: 0, 4: 0, 3: 0, 5: 0}

        for line in f0:
            Write_Dict = {}  # 该字典用于存储需要写入的样本字典
            LLMs_Generted_Label_List = []
            LLMs_Generted_Answer_Set_Explanation_List = []
            js = json.loads(line.strip())
            # 将数据集划分成训练/验证/测试
            Sample_number = js['Sample_number']
            Origin_Facts = js['Origin_Facts']
            Facts_number = js['Facts_number']  # 计算缺省理论中事实的个数
            Defalut_Rules = js['Defalut_Rules']
            NL_Origin_Facts = js['NL_Origin_Facts']
            NL_Defalut_Rules = js['NL_Defalut_Rules']
            Origin_ASP_extension_number = js['Origin_ASP_extension_number']
            Origin_Question_Text_Lists = js['Origin_Question_Text_Lists']
            NL_Origin_Question_Text = js['NL_Origin_Question_Text']
            Origin_Question_Label_Lists = js['Origin_Question_Label_Lists']
            Origin_Question_proof_List = js['Origin_Question_proof_List']
            NL_Origin_Question_proof_Text = js['NL_Origin_Question_proof_Text']

            # 控制每个扩展数量的样本测试
            if Origin_ASP_extension_number not in Test_Extension_Example_Dict.keys():
                Test_Extension_Example_Dict[Origin_ASP_extension_number] = 1
                if Test_Extension_Example_Dict[Origin_ASP_extension_number] <= Test_Extension_Example_Dict01[
                    Origin_ASP_extension_number]:
                    continue
            else:
                if Test_Extension_Example_Dict[Origin_ASP_extension_number] >= 100:
                    continue
                else:
                    Test_Extension_Example_Dict[Origin_ASP_extension_number] += 1
                    if Test_Extension_Example_Dict[Origin_ASP_extension_number] <= Test_Extension_Example_Dict01[
                        Origin_ASP_extension_number]:
                        continue

            NL_Noise_Facts_Strings, NL_Noise_Default_Rule_Strings = '', ''
            if Noise_Flag == True:
                NL_Noise_Facts_Lists = js['NL_Noise_Facts_Lists']
                NL_Noise_Default_Rule_Lists = js['NL_Noise_Default_Rule_Lists']

                for noise_fact_key in range(Noise_Length):
                    noise_fact = NL_Noise_Facts_Lists[noise_fact_key]
                    NL_Noise_Facts_Strings = NL_Noise_Facts_Strings + noise_fact

                for noise_rule_key in range(Noise_Length):
                    noise_rule = NL_Noise_Default_Rule_Lists[noise_rule_key]
                    NL_Noise_Default_Rule_Strings = NL_Noise_Default_Rule_Strings + noise_rule

            Answer_Set_List = []
            if Total_count01 <= 25:
                print('Test_Extension_Example_Dict={}'.format(Test_Extension_Example_Dict))
                Total_count01 = Total_count01 + 1
                continue

            Context_Text_String = NL_Origin_Facts + NL_Noise_Facts_Strings
            Context_Text_String = Context_Text_String + NL_Defalut_Rules + NL_Noise_Default_Rule_Strings
            Question_Text_String = ''
            LLMs_Generted_Label_List = []
            Generated_Answer_Set_List = ''
            Soft_Generated_Answer_Set_List = ''
            for question_key in range(len(NL_Origin_Question_Text)):
                question_text = NL_Origin_Question_Text[question_key]
                Question_Text_String = question_text
                question_label = Origin_Question_Label_Lists[question_key]
                Total_Question_label_List.extend(Label_Dict[question_label[0]])
                # 调用大模型预测
                Test_prompt = f"""### Instruction: {Test_Instruction} ### The context are: {Context_Text_String} ### The question is: {Question_Text_String}\n ### Response: """
                while_count01 = 0
                while True:
                    if while_count01 > 10:
                        extracted_answer_output = result_output
                        break
                    result_output = Test_generate_text(Test_model, Test_tokenizer, Test_prompt)
                    while_count01 = while_count01 + 1
                    result_output = result_output.replace('\n', ' ')
                    print('result_output={}.'.format(result_output))
                    if '</think>' in result_output:
                        result_output = result_output.split('Response')[-1]
                    else:
                        continue
                    extracted_answer_output = re.findall(Extract_Answer_Pattern, result_output)
                    extracted_extension_output = re.findall(Exact_Extensions_Pattern, result_output)
                    if len(extracted_answer_output) == 0:  # len(extracted_extension_output)==0:
                        print("抽取标签答案不成功！while_count01={}".format(while_count01))
                        continue
                    else:
                        extracted_answer_output = extracted_answer_output[0]
                        print("抽取标签答案成功！extracted_answer_output={},while_count01={}".format(extracted_answer_output,while_count01))
                    if len(extracted_extension_output) >= 1:
                        Generated_Answer_Set_List = extracted_extension_output[0].replace('.', '').replace('doesn\'t','does not').replace('won\'t','will not').replace('isn\'t','is not').replace('aren\'t','are not').replace('\'s', ' is')
                        Generated_Answer_Set_List = Generated_Answer_Set_List.replace('[ [', '[[').replace('] ]', ']]')
                        if len(Generated_Answer_Set_List) > 10 and '[[' in Generated_Answer_Set_List and ']]' in Generated_Answer_Set_List:
                            Generated_Answer_Set_List = Generated_Answer_Set_List[:-2] if Generated_Answer_Set_List[-1] == '.' else Generated_Answer_Set_List
                            print('转换为列表之前的字符串Generated_Answer_Set_List={}'.format(Generated_Answer_Set_List))
                            Generated_Answer_Set_List = ast.literal_eval(Generated_Answer_Set_List)
                            print("抽取回答集成功！Generated_Answer_Set_List={},while_count01={}".format(Generated_Answer_Set_List, while_count01))

                    if len(Generated_Answer_Set_List) == 0:
                        # extracted_extension_output = extracted_extension_output[0]
                        if len(extracted_extension_output) == 0 and 'extensions are:' in result_output:
                            extracted_extension_output01 = result_output.split('extensions are:')[-1]
                            extracted_extension_output01 = extracted_extension_output01.replace('[   [', '[[')
                            # 截取最后一个']'之前的字符串
                            if '[' in extracted_extension_output01 and '[[' not in extracted_extension_output01:
                                extracted_extension_output01 = extracted_extension_output01.strip()
                                extracted_extension_output01 = '[' + extracted_extension_output01

                            try:
                                extracted_extension_output = extracted_extension_output01[:extracted_extension_output01.rfind(',') + 1]
                                extracted_extension_output = extracted_extension_output.strip().replace('doesn\'t',' does not').replace('won\'t','will not').replace('isn\'t','is not').replace('aren\'t','are not').replace('\'s', ' is')
                                extracted_extension_output = extracted_extension_output[:-1] if extracted_extension_output[-1] == ',' else extracted_extension_output
                                extracted_extension_output = extracted_extension_output + ']]'

                                extracted_extension_output = ast.literal_eval(extracted_extension_output)
                                if isinstance(extracted_extension_output, list):
                                    extracted_extension_list02 = copy.deepcopy(extracted_extension_output)
                                    # 对每个子列表进行去重
                                    for i in range(len(extracted_extension_list02)):
                                        extracted_extension_list02[i] = list(set(extracted_extension_list02[i]))
                                    # 对整个列表进行去重
                                    extracted_extension_list02 = [list(x) for x in set(
                                        tuple(sorted(x)) for x in extracted_extension_list02)]
                                    Soft_Generated_Answer_Set_List = extracted_extension_list02

                                    print("抽取回答集成功！extracted_extension_output={},while_count01={}".format(
                                        Soft_Generated_Answer_Set_List, while_count01))
                                else:
                                    print("抽取回答集失败！extracted_extension_output={},while_count01={}".format(
                                        extracted_extension_output, while_count01))
                            except:
                                Soft_Generated_Answer_Set_List = ''
                    if len(Generated_Answer_Set_List)!=0:
                        print('extracted_answer_output={},extracted_extension_output={},result_output={}'.format(extracted_answer_output, Generated_Answer_Set_List, result_output))
                    else:
                        print('extracted_answer_output={},extracted_extension_output={},result_output={}'.format(extracted_answer_output, Soft_Generated_Answer_Set_List, result_output))

                    if len(extracted_answer_output) != 0:
                        break

                # 对生成的结果进行分析
                predict_label = None
                if 'unknown' in extracted_answer_output or 'Unknown' in extracted_answer_output:
                    predict_label = 'M'
                elif 'true' in extracted_answer_output or 'True' in extracted_answer_output:
                    predict_label = 'T'
                elif 'false' in extracted_answer_output or 'False' in extracted_answer_output:
                    predict_label = 'F'
                else:
                    predict_label = 'M'
                LLMs_Generted_Label_List.append([predict_label])

                Total_LLMs_Generted_Label_List.extend(Label_Dict[predict_label])
            print('Total_count01={}, Total_LLMs_Generted_Label_List = {}, Origin_Question_Label_Lists: = {}'.format(Total_count01, LLMs_Generted_Label_List, Origin_Question_Label_Lists))

            Write_Dict['Sample_number'] = Sample_number  # 样本个数
            Write_Dict['Origin_ASP_extension_number'] = Origin_ASP_extension_number
            Write_Dict['NL_Origin_Question_Text'] = NL_Origin_Question_Text
            Write_Dict['Origin_Question_Label_Lists'] = Origin_Question_Label_Lists
            Write_Dict['LLMs_Generated_Question_Label_Lists'] = LLMs_Generted_Label_List

            Write_Dict['Origin_Question_proof_List'] = Origin_Question_proof_List
            Write_Dict['NL_Origin_Question_proof_Text'] = NL_Origin_Question_proof_Text
            Write_Dict['LLMs_Generated_Question_Explanation_Lists'] = ''
            Write_Dict['Answer_Set_List'] = Generated_Answer_Set_List if len(Generated_Answer_Set_List)!= 0 else Soft_Generated_Answer_Set_List  # 在微调模式下，每个问题都生成了回答集，所以需要用字典来存储。

            Write_Dict = json.dumps(Write_Dict, ensure_ascii=False)
            f1.write(Write_Dict + '\n')
            Total_count01 = Total_count01 + 1

        accuracy = accuracy_score(Total_Question_label_List, Total_LLMs_Generted_Label_List)  # 计算准确率
        F1 = f1_score(Total_Question_label_List, Total_LLMs_Generted_Label_List, average='macro')
        print('accuracy={},F1={}'.format(accuracy, F1))


if __name__ == '__main__':
    # Train_data, Test_data = Train_Test_Dataset()
    # Train_model, Train_tokenizer = Load_FineTune_Model()
    # Train_llama3(Train_model, Train_tokenizer, Train_data)
    # Saved_Model(Train_model, Train_tokenizer)
    # del Train_model
    # del Train_tokenizer
    Test_model, Test_tokenizer = Load_Test_Model()
    FastLanguageModel.for_inference(Test_model)
    Test_Model(Test_model, Test_tokenizer, Train_Dev_Test_Flag='test')
