import copy
import sys
import re
import httpx
import torch

sys.path.append('/home/yeliangxiu/Projects/Automated_Construct_MultiNMR//Dataset')
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ["NCCL_P2P_DISABLE"] = "1"
os.environ["NCCL_IB_DISABLE"] = "0"
os.environ['WANDB_MODE'] = 'dryrun'
from unsloth import FastLanguageModel
from unsloth.chat_templates import train_on_responses_only
from unsloth.chat_templates import get_chat_template
from unsloth.chat_templates import standardize_data_formats
from unsloth import FastModel
import difflib
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from openai import OpenAI
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
import json

import torch
from trl import SFTTrainer, DataCollatorForCompletionOnlyLM, SFTConfig
from transformers import TrainingArguments
from datasets import load_dataset
from huggingface_hub import login
from huggingface_hub import notebook_login

max_seq_length = 2048
from datasets import Dataset
import pandas as pd
import numpy as np
from random import randrange

Train_Number = 5000  # 1000, 2000,5000, 10000, 15000, 20000

Reasoning_Mode = 'skeptical'  # [credulous, skeptical]
Dataset_Name = 'MultiLogicNMR'
Dataset_Category = 'test'  # ['train', 'dev', 'test']
Zero_or_Few_Shot = 'Zero_Shot'  # ['Zero_Shot','Few_Shot']
OOD_Flag = False
LLMs_Generate = True
Noise_Flag = False
Noise_Name = '_Noise' if Noise_Flag == True else ''
Noise_Length = 10 if Noise_Flag == True else ''
Generate_AS_Flag = ''
OOD_Data_Path = "OOD_Datasets" if OOD_Flag == True else ''
OOD_read_filename = "_ood" if OOD_Flag == True else ''
OOD_write_filename = "ood_" if OOD_Flag == True else ''
LLMs_Generate_Datasets = 'GPT4_LLMs_Generated_' if LLMs_Generate == True else ''
if OOD_Flag == True:
    read_file_path = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Datasets/' + OOD_Data_Path + '/'
elif LLMs_Generate == True:
    read_file_path = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/LLMs_Generate_Datasets/' + Reasoning_Mode + '/'
else:
    read_file_path = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Datasets/' + Reasoning_Mode + '/'

write_file_path = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Experimens/LLMs_Results/'
ASP_extension_number_Min, ASP_extension_number_Max = 1, 5  # 用于对回答集进行过滤
if OOD_Flag == True:
    ASP_extension_number_Min, ASP_extension_number_Max = 6, 16

LLMs_Models_Choise = "Gemma3_27B"  # ['GPT3.5','GPT4','Claude','Gemma3_27B','Mistral_7B', 'llama3']
Read_Train_Data_file = read_file_path + Reasoning_Mode + '_multiNMR_' + 'train' + '_' + str(
    ASP_extension_number_Min) + '_' + str(ASP_extension_number_Max) + '_balance' + OOD_read_filename + '.json'
Read_Test_Data_file = read_file_path + LLMs_Generate_Datasets + Reasoning_Mode + '_multiNMR_' + 'test' + '_' + str(
    ASP_extension_number_Min) + '_' + str(ASP_extension_number_Max) + '_balance' + OOD_read_filename + Noise_Name + str(
    Noise_Length) + '.json'

Write_file_path02 = write_file_path + Zero_or_Few_Shot + '_' + LLMs_Models_Choise + '_FinedTune_result_on_' + Dataset_Name + '_' + OOD_write_filename + LLMs_Generate_Datasets + Reasoning_Mode + '_' + Dataset_Category + '_' + str(
    ASP_extension_number_Min) + '_' + str(ASP_extension_number_Max) + '_balance' + Noise_Name + str(
    Noise_Length) + '_' + str(Train_Number) + '.json'

Label_Dict = {'F': [0], 'T': [1], 'M': [2]}
# 提示要求同时回答多个问题。
# Zero_Shot_Skeptical_Instruction = 'You are an expert in non-monotonic reasoning and are asked to generate answer labels and answer set explanations for questions in a given context. The answers to the questions are labeled "True", "False" and "Unknown". The answer set explanations are all intermediate conclusions generated under a certain reasoning path based on context, where intermediate conclusions are the conclusions generated when applying rules for reasoning. The set of intermediate conclusions generated under a certain reasoning path cannot contradict each other. Since there may be many different paths of reasoning, there may be multiple answer set explanations. If the question can be inferred under all reasoning paths based on the context, and the negation of the question cannot be inferred under all reasoning paths based on the context, the answer label of the question is "True", and needs to generate all answer set explanations that contain the question; if the negation of the question can be inferred under all reasoning path based on the context, and the question cannot be inferred under all reasoning path based on the context, the answer label of the question is "False", and needs to generate all answer set explanations that contain the negation of question; If the question and the negation of the question cannot be deduced under a certain reasoning path based on the context, the answer label of the question is "Unknown", and needs to generate all the answer set explanations than cannot contain the question and all the answer set explanations that cannot contain the negation of the question. Each context has three questions, and the input format is Context: ". Question 1:". Question 2:". Question 3:". You must generate answer labels and answer set explanations for each question. The output format is: The answer label of question 1 is:", The answer set explanations of question 1 is: explanation 1:''.,...,. Explanation n:''. The answer label of question 2 is:", The answer set explanations of question 2 is: Explanation 1:''.,...,. Explanation n:''. The answer label of question 3 is:", The answer set explanations of question 3 is: Explanation 1:''.,...,. Explanation n:''. Please read the context carefully and answer the questions. '
# Zero_Shot_Credulous_Instruction = 'You are an expert in non-monotonic reasoning and are asked to generate answer labels and answer set explanations for questions in a given context. The answers to the questions are labeled "True", "False" and "Unknown". The answer set explanations are all intermediate conclusions generated under a certain reasoning path based on context, where intermediate conclusions are the conclusions generated when applying rules for reasoning. The set of intermediate conclusions generated under a certain reasoning path cannot contradict each other. Since there may be many different paths of reasoning, there may be multiple answer set explanations. If the question can be inferred under a certain reasoning path based on the context, the answer label of the question is "True" and needs to generate all answer set explanations that contain the question; if the negation of the question can be inferred under a certain reasoning path based on the context, the answer label of the question is "False", and needs to generate all answer set explanations that contain the negation of question; If the question and the negation of the question both cannot be deduced under all reasoning path based on the context, the answer label of the question is "Unknown". It needs to generate all the answer set explanations that can not contain the question and all the answer set explanations that can not contain the negation of the question. Each context has three questions, and the input format is Context: ", question 1:", question 2:", question 3:". Please read the context carefully and answer the questions. You must generate answer labels and answer set explanations for each question. The output format is: The answer label of question 1 is:", The answer set explanations of question 1 is: Explanation 1:''.,...,. Explanation n:''. The answer label of question 2 is:". The answer set explanations of question 2 is: Explanation 1:''.,...,. Explanation n:''. The answer label of question 3 is:". The answer set explanations of question 3 is: Explanation 1:''.,...,. Explanation n:''.'

# 提示要求逐个回答问题。
Zero_Shot_Skeptical_Instruction = 'Given contexts and question, You need to generate answer labels for questions in a given context.\n If the question can be inferred under all reasoning paths based on the context, and the negation of the question cannot be inferred under all reasoning paths based on the context, the answer label of the question is: "True";\n if the negation of the question can be inferred under all reasoning path based on the context, and the question cannot be inferred under all reasoning path based on the context, the answer label of the question is: "False";\n If the question and the negation of the question cannot be deduced under a certain reasoning path based on the context, the answer label of the question is: "Unknown".\n  The input format is: The context are: ". The question is:". \n The output format is: The answer label of the question is:".\n Note that you only need to generate the answer label for the question without giving an explanation or justification. Please read the context carefully and answer the questions. '
Zero_Shot_Credulous_Instruction = 'Given contexts and question, You need to generate answer labels for questions in a given context. If the question can be inferred under a certain reasoning path based on the context, the answer label of the question is: "True"; \n if the negation of the question can be inferred under a certain reasoning path based on the context, the answer label of the question is: "False"; \n  If the question and the negation of the question both cannot be deduced under all reasoning path based on the context, the answer label of the question is: "Unknown". \n The input format is: The context are: ". The question is:". The output format is: The answer label of question is:". \n Note that you only need to generate the answer label for the question, without giving an explanation or justification. Please read the context carefully and answer the questions. '
Three_Few_Shot_Skeptical_Instruction = 'Given contexts and question, You need to generate answer labels for questions in a given context. The context contains facts and a default rule, The default rule format is: If A then B, unless C. The A is the prerequisite, the B is the conclusion, and the C is called the justifications. The "If A then B, unless C." means that If the preconditions A are in the facts, and the justifications C is not in the facts, then you can deduce the conclusion B. The answers to the questions are labeled "True", "False" and "Unknown". If the question can be inferred under all reasoning paths based on the context, and the negation of the question cannot be inferred under all reasoning paths based on the context, the answer label of the question is: "True"; if the negation of the question can be inferred under all reasoning path based on the context, and the question cannot be inferred under all reasoning path based on the context, the answer label of the question is: "False"; If the question and the negation of the question cannot be deduced under a certain reasoning path based on the context, the answer label of the question is: "Unknown". Each context has a question, and the input format is Context: ". Question:". You must generate answer labels for each question. The output format is: The answer label of the question is:". For example, Context: Grant is not impartial. Grant is not misty. Grant is not gentle. Grant is not lively. Grant is thankful.Grant is willing. Grant is red. Grant is medical. Grant is legal. Grant is not expensive. Grant is not crazy. If someoneA is not lively and not gentle then he is not adorable ,unless he is not annoying. If someoneA is thankful then he is critical ,unless he is not better. If someoneA is willing and not crazy then he is not aware ,unless he is not smoggy. If someoneA is legal then he is not annoying ,unless he is not adorable. If someoneA is not annoying then he is political,unless he is not alive or he is not adorable. If someoneA is not aware then he is not smoggy ,unless he is not aware. If someoneA is not misty then he is safe, unless he is not annoying. If someoneA is not expensive and not impartial then he is not mean, unless he is orange or he is safe.If someoneA is medical then he is not odd, unless he is optimistic or he is not smoggy. If someoneA is red then he is adventurous, unless he is not busy or he is not aware. If the Question is: Grant is adorable. Then the answer label for the question is: Unknown; If the question is: Grant is not critical. Then the answer label for the question is: False; If the question is: Grant is not odd. Then the answer label for the question is: True. For example, Context: Jessie is horrible. Jessie admire Marion. Jessie is right. Jessie is consistent. Jessie is not handsome. Jessie is not warm hearted.Jessie is not tame. Jessie is self disciplined. Jessie is imaginative.Jessie is long. Jessie is rude. Jessie is not available. Jessie is not busy. Jessie is not reserved. Jessie is not tired. If someoneA is long then he is clear, unless he is placid or he is not few.If someoneA is not busy and not clear then he is not competitive, unless he is mean or he is not beautiful. If someoneA is right and not tired then he is weary ,unless he is not dangerous. If someoneA is clear and not tame then he is not dangerous,unless he is weary or he is not informal. If someoneA admire someoneB and someoneA is not reserved then he is not few ,unless he is not unpleasant or he is not self disciplined.If someoneA is consistent and horrible then he is not informal ,unless he is not dangerous. If someoneA is not handsome then he is mean,unless he is not competitive. If someoneA is imaginative and not warm hearted then he is green,unless he is not informal. If someoneA is self disciplined and not available then he is not salty, unless he is not sane or he is triangular. If someoneA is rude and weary then he is not pleasant ,unless he is mean. If the Question is: Jessie is clear. Then the answer label for the question is: Unknown; If the question is: Jessie is few. Then the answer label for the question is: False; If the question is: Jessie is not informal. Then the answer label for the question is: True. For example, Context: Basil is not innocent. Basil is not wooden. Basil is discreet.Basil is not petite. Basil is comprehensive.Basil is nutty. Basil is historical. Basil is plastic.Basil is steep.Basil is not pleasant.Basil is not useful. Basil is long.Basil is better. Basil is not expensive. If someoneA is historical then he is red, unless he is not lively or he is not big. If someoneA is nutty and steep then he is miniscule, unless he is not weary or he is outstanding.If someoneA is not petite then he is brave, unless he is sticky or he is psychological. If someoneA is not wooden and miniscule then he is psychological, unless he is brave. If someoneA is not expensive and discreet then he is not legal, unless he is not ugly or he is psychological.If someoneA is plastic then he is sticky, unless he is brave.If someoneA is miniscule then he is not courageous,unless he is sticky or he is not eastern. If someoneA is not pleasant and better then he is ashamed, unless he is bloody. If someoneA is comprehensive and not useful then he is not disgusted,unless he is brave. If someoneA is long and not innocent then he is not compassionate, unless he is psychological or he is not smart. If the Question is: Basil is red. Then the answer label for the question is: True; If the question is: Basil is miniscule. Then the answer label for the question is: Unknown; If the question is: Basil is not ashamed. Then the answer label for the question is: False. Note that you only need to generate the answer label for the question, without giving an explanation or justification. Please read the context carefully and answer the questions.'
Three_Few_Shot_Credulous_Instruction = 'Given contexts and question, You need to generate answer labels for questions in a given context. The context contains facts and a default rule, The default rule format is: If A then B, unless C. The A is the prerequisite, the B is the conclusion, and the C is called the justifications. The "If A then B, unless C." means that If the preconditions A are in the facts, and the justifications C is not in the facts, then you can deduce the conclusion B. The answers to the questions are labeled "True", "False" and "Unknown".  If the question can be inferred under a certain reasoning path based on the context, the answer label of the question is: "True"; if the negation of the question can be inferred under a certain reasoning path based on the context, the answer label of the question is: "False"; If the question and the negation of the question both cannot be deduced under all reasoning path based on the context, the answer label of the question is: "Unknown". Each context has three questions, and the input format is Context: ". Question:". The output format is: The answer label of question is:". You must generate answer labels for each question. For example, Context: Brooke is not bad. Brooke is not famous. Brooke is bumpy. Brooke is not quiet. Brooke is hypocritical. Brooke is not agreeable.Brooke is not compassionate. Brooke is tan.Brooke is not annoying. Brooke is careful. Brooke is boring. Brooke is not versatile. Brooke is silly. Brooke is not alive. If someoneA is hypocritical and tan then he is not weary, unless he is not puzzled or he is not untidy. If someoneA is not quiet and boring then he is humorous ,unless he is not self confident. If someoneA is not versatile and not bad then he is self confident,unless he is cautious. If someoneA is not compassionate then he is unsightly ,unless he is busy. If someoneA is not annoying then he is not lonely, unless he is humorous or he is not zealous. If someoneA is not lonely and careful then he is purple, unless he is handsome. If someoneA is not famous and not agreeable then he is lucky, unless he is humorous or he is sweet. If someoneA is not alive and bumpy then he is not intellectual, unless he is perfect or he is attentive. If someoneA is silly then he is handsome, unless he is purple or he is misty.If someoneA is not intellectual then he is useful, unless he is cool or he is adventurous. If the question is: Brooke is not weary. Then the answer label for the question is: True; If the question is: Brooke is not humorous. Then the answer label for the question is: False; If the question is: Brooke is lonely. Then the answer label for the question is: Unknown. For example, Context: Kathie is not hilarious. Kathie is itchy. Kathie is sharp. Kathie is cloudy. Kathie is aware. Kathie is severe. Kathie is frail. Kathie contemn Stefan. Kathie is latter. Kathie is not thankful. Kathie is not powerful. Kathie is grotesque. Kathie is not disobedient. If someoneA is not hilarious then he is not nervous, unless he is not evil. If someoneA is not disobedient and severe then he is not tan, unless he is bloody or he is generous. If someoneA is not nervous then he is not splendid, unless he is not intellectual or he is not thoughtless. If someoneA is latter and itchy then he is not acceptable, unless he is not afraid or he is elegant. If someoneA is grotesque and frail then he is not puzzled, unless he is not famous or he is not exuberant. If someoneA is not nervous and not puzzled then he is generous, unless he is dynamic or he is not tan. If someoneA is sharp and aware then he is bloody, unless he is not tan. If someoneA contemn someoneB then he is dynamic, unless he is generous. If someoneA is not thankful and not powerful then he is not wet, unless he is generous. If someoneA is cloudy then he is not charming, unless he is thoughtless or he is massive. If the question is: Kathie is not nervous. Then the answer label for the question is: Unknown; If the question is: Kathie is tan. Then the answer label for the question is: False; If the question is: Kathie is not splendid. Then the answer label for the question is: True. For example, Context: Cecil is acceptable.Cecil is uptight.Cecil is not good tempered.Cecil is not severe.Cecil is not messy.Cecil is not self disciplined. Cecil is not logical.Cecil is not right.Cecil is careful.Cecil is not talented.Cecil is not curious.Cecil is not evil.Cecil is annoying. If someoneA is not evil and not good tempered then he is not good, unless he is not successful or he is not modern.If someoneA is not logical then he is not visible, unless he is not harsh. If someoneA is not messy and careful then he is not outstanding, unless he is not uptight. If someoneA is uptight and not severe then he is not successful, unless he is similar or he is not good. If someoneA is not visible then he is serious, unless he is not outstanding. If someoneA is not self disciplined then he is not fantastic, unless he is emotional or he is serious. If someoneA is not talented and acceptable then he is similar, unless he is not purple or he is not successful. If someoneA is not curious and annoying then he is typical, unless he is not self confident. If someoneA is not fantastic then he is not inquisitive, unless he is not outstanding or he is not tame. If someoneA is not right then he is emotional, unless he is not fantastic or he is not oak. If the question is: Cecil is good. Then the answer label for the question is: False; If the question is: Cecil is not visible. Then the answer label for the question is: Unknown; If the question is: Cecil is similar. Then the answer label for the question is: True. Note that you only need to generate the answer label for the question, without giving an explanation or justification. Please read the context carefully and answer the questions. '

Zero_Shot_COT_Extensions_Skeptical_Instruction = 'Task Description: \n Given contexts and question, and the context consists of facts and default rules. You need first to find all extensions based on the given context and then to answer the question according to the extensions. An extension is a set of non-contradictory conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to generate all the extensions. Next, the answer to the question is generated based on the generated extension.\n If the question can be inferred under all extensions, and the negation of the question cannot be inferred under all extensions, the answer label of the question is: "True"; \n If the negation of the question can be inferred under all extensions, and the question cannot be inferred under all extensions, the answer label of the question is: "False"; \n If the question and the negation of the question cannot be deduced under a certain extension, the answer label of the question is: "Unknown". \n  The input format is: The context are:''. \n The ouput format is: The answer of the question is:''. ### \n You must find all extensions and the answer of the question.  \n Please read the context carefully. Let\'s think step by step.'
Zero_Shot_COT_Extensions_Credulous_Instruction = 'Task Description: \n Given contexts and question, the context consists of facts and default rules. You first need to find all extensions based on the given context and then answer the question according to the extensions. An extension is a set of non-contradictory facts and conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to find all the extensions according to the above steps. Next, the answer to the question is generated based on the generated extension. \n If the question can be inferred under a certain extension, the answer label of the question is: "True"; \n If the negation of the question can be inferred under a certain extension, the answer label of the question is: "False"; \n If the question and the negation of the question both cannot be deduced under all extension, the answer label of the question is: "Unknown". \n  The input format is: The context are:''. The questions is:''. \n The output format is:  The answer of the question is:''. ###  \n You must generate all extensions and the answer of the question. \n Please read the context carefully. Let\'s think step by step.'
Few_Shot_COT_Extensions_Skeptical_Instruction = 'Task Description: \n Given contexts and question, and the context consists of facts and default rules. You need first to generate all extensions based on the given context and then to answer the question according to the extensions. An extension is a set of non-contradictory conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to generate all the extensions. Next, the answer to the question is generated based on the generated extension.\n If the question can be inferred under all extensions, and the negation of the question cannot be inferred under all extensions, the answer label of the question is: "True"; \n If the negation of the question can be inferred under all extensions, and the question cannot be inferred under all extensions, the answer label of the question is: "False"; \n If the question and the negation of the question cannot be deduced under a certain extension, the answer label of the question is: "Unknown". \n  The input format is: The context are:''. \n The ouput format is: The answer of the question is:''. ### \n The extensions are:''.### \n  For example: The context are: "Connor is not lovely.Connor is poor.Connor is not wonderful.Connor is not former.Connor is wicked.Connor is not comfortable.Connor is not oval.Connor is not cultural.Connor is old.Connor is not hungry.Connor does not honour Godfrey.Connor is awful.Connor is not long.If someoneA is not long then he is not immediate,unless he is not giant or he is sparkling.If someoneA is awful and not alert then he is not creative ,unless he is decent.If someoneA is not wonderful then he is civil,unless he is not substantial or he is not zany.If someoneA is not immediate and he does not honour someoneB then he is not giant ,unless he is not immediate.If someoneA is wicked then he is decent,unless he is not creative or he is significant.If someoneA is not comfortable and not giant then he is sparkling,unless he is not decent or he is not immediate.If someoneA is old and not lovely then he is not hollow,unless he is not giant or he is not crowded.If someoneA is not former and not hungry then he is not alert,unless he is hard or he is not immediate.If someoneA is not oval then he is cheap,unless he is not energetic or he is not technical.If someoneA is poor and not cultural then he is not crowded,unless he is oval or he is not hollow.". \n The question is:"Connor is civil.". ### \n The answer of the question is:"True". ### \n The extensions are:"[["Connor is civil.", "Connor is decent.", "Connor is cheap.", "Connor is not crowded.", "Connor is not immediate."], ["Connor is civil.", "Connor is decent.", "Connor is cheap.", "Connor is not hollow.", "Connor is not immediate."]]".### \n You must generate all extensions and the answer of the question.  \n Please read the context carefully. Let\'s think step by step.'
Few_Shot_COT_Extensions_Credulous_Instruction = 'Task Description: \n Given contexts and question, the context consists of facts and default rules. You first need to generate all extensions based on the given context and then answer the question according to the extensions. An extension is a set of non-contradictory facts and conclusions generated by rule-based reasoning. There may be multiple extensions in the context, and you need to find all the extensions according to the above steps. Next, the answer to the question is generated based on the generated extension. \n If the question can be inferred under a certain extension, the answer label of the question is: "True"; \n If the negation of the question can be inferred under a certain extension, the answer label of the question is: "False"; \n If the question and the negation of the question both cannot be deduced under all extension, the answer label of the question is: "Unknown". \n  The input format is: The context are:''. The questions is:''. \n The output format is: The answer of the question is:''. ### \n The extensions are:''. ### \n  For example, ### \n The context are: "Lancelot is significant.Lancelot is not attractive.Lancelot is teak.Lancelot does not embarrass Patricia.Lancelot is not fair.Lancelot is lovely.Lancelot is jolly.Lancelot is expensive.Lancelot is not anxious.Lancelot is dry.Lancelot is energetic.Lancelot is several.Lancelot does not mock Patricia.Lancelot is not octagonal. If someoneA is not anxious and not fair then he is persistent,unless he is old or he is soft.If someoneA is not attractive and not broad minded then he is not granite ,unless he is not wild.If someoneA is significant and not octagonal then he is melodic ,unless he is not shiny.If someoneA is dry then he is not shiny ,unless he is melodic.If someoneA is several and he does not embarrass someoneB then he is prickly ,unless he is technical or he is melodic.If someoneA is persistent then he is not wild,unless he is former or he is not granite.If someoneA does not mock someoneB and someoneA is energetic then he is technical ,unless he is oval or he is prickly.If someoneA is teak then he is not fat,unless he is not granite or he is not prickly.If someoneA is lovely then he is not broad minded ,unless he is not granite.If someoneA is jolly and expensive then he is not sparkling,unless he is not crowded or he is not granite." The questions is:"Lancelot is not persistent.". #### \n The answer of the question is:"False". ### \n The extensions are:"[["Lancelot is prickly.", "Lancelot is not sparkling.", "Lancelot is not fat.", "Lancelot is not broad minded.", "Lancelot is not shiny.", "Lancelot is not wild.", "Lancelot is persistent."], ["Lancelot is not sparkling.", "Lancelot is technical.", "Lancelot is not fat.", "Lancelot is not broad minded.", "Lancelot is not wild.", "Lancelot is melodic.", "Lancelot is persistent."], ["Lancelot is not sparkling.", "Lancelot is technical.", "Lancelot is not fat.", "Lancelot is not broad minded.", "Lancelot is not shiny.", "Lancelot is not wild.", "Lancelot is persistent."]]". ###\n  You must generate all extensions and the answer of the question. \n Please read the context carefully. Let\'s think step by step.'
Exact_Extensions_Pattern = "(?<=extensions are:).*?(?=Note|#|The answer label for the question|<end_of_turn>)"
Extract_Answer_Pattern = "(?<=the question is:).*?(?=Note|#|\.|extensions are|The explanation is|<end_of_turn>|\;|Step-by-step|```｜Instruction|1```1)"

Train_Dataset, Test_Datset = None, None
Label2Text = {'T': 'True', 'F': 'False', 'M': 'Unknown'}
Train_Instruction, Test_Instruction = '', ''
Train_Instruction = Zero_Shot_COT_Extensions_Skeptical_Instruction if Reasoning_Mode == 'skeptical' else Zero_Shot_COT_Extensions_Credulous_Instruction
Test_Instruction = Few_Shot_COT_Extensions_Skeptical_Instruction if Reasoning_Mode == 'skeptical' else Few_Shot_COT_Extensions_Credulous_Instruction


# 定义一个读取文件的函数
def Read_Train_Dataset(Train_Dev_Test_Flag):
    with open(Read_Train_Data_file, 'r', encoding='utf-8') as f0:
        All_Sample_List = []
        for line in f0:
            js = json.loads(line.strip())
            # 将数据集划分成训练/验证/测试
            NL_Origin_Facts = js['NL_Origin_Facts']
            NL_Defalut_Rules = js['NL_Defalut_Rules']
            NL_Origin_Question_Text = js['NL_Origin_Question_Text']
            Origin_Question_Label_Lists = js['Origin_Question_Label_Lists']
            NL_Origin_Question_proof_Text = js['NL_Origin_Question_proof_Text']
            # 在谨慎推理模式下，“M”标签的推理路径存储的是所有的回答集，而在怀疑推理模式下，“T”标签的推理路径存储的是所有的回答集
            Origin_Answer_Set_List = None
            if Reasoning_Mode == "credulous":
                for key in range(len(NL_Origin_Question_proof_Text)):
                    if "M" in NL_Origin_Question_proof_Text[key].keys():
                        Origin_Answer_Set_List = NL_Origin_Question_proof_Text[key]["M"]
                        break
            else:
                for key in range(len(NL_Origin_Question_proof_Text)):
                    if "T" in NL_Origin_Question_proof_Text[key].keys():
                        Origin_Answer_Set_List = NL_Origin_Question_proof_Text[key]["T"]
                        break
            Context = NL_Origin_Facts + NL_Defalut_Rules

            for question_key in range(len(NL_Origin_Question_Text)):
                sample_list01 = []
                sample_list01.append('### Instruction:' + Train_Instruction)
                sample_list01.append('### The context are:' + Context)
                sample_list01.append('### The question is:' + NL_Origin_Question_Text[question_key])
                sample_list01.append('\n ### Response: The answer label for the question is:' + Label2Text[
                    Origin_Question_Label_Lists[question_key][
                        0]])  # The extensions are:' + str(Origin_Answer_Set_List) + '
                All_Sample_List.append(sample_list01)
        df = pd.DataFrame(All_Sample_List, columns=['Instruction', 'Context', 'Question', 'Answer'])
    return df


def Train_Test_Dataset():
    # 获取训练数据集
    Train_dataset_df = Read_Train_Dataset(Train_Dev_Test_Flag='train')
    Train_data = Train_dataset_df[['Instruction', 'Context', 'Question', 'Answer']]
    Train_data = Train_data.reset_index(drop=True)
    Train_data = Dataset.from_pandas(Train_data.iloc[0:])
    print('len(train_data)=', len(Train_data))

    return Train_data


Train_model, Train_tokenizer = None, None


# 2. Load Gemma3 model 加载 Gemma3-27B
def Load_FineTune_Model():
    print('Loading model')
    Train_model, Train_tokenizer = FastModel.from_pretrained(

        model_name="/home/yeliangxiu/Projects/Pre_trained_Models/gemma3-27B",

        max_seq_length=2048,  # 设置模型支持的最大序列长度，按需调整
        load_in_4bit=True,  # 是否启用 4 位量化，使用 4 位量化加载模型，可以显著减少内存占用，但可能会略微牺牲精度
        load_in_8bit=False,  # 8 位量化相比 4 位更精确，但内存占用要翻番，如果需要更高精度且内存充足，可以设置为 True
        full_finetuning=False,  # 全参数微调
    )

    print('Model loaded successfully')

    # 进行模型参数设置和快速 LoRA 权重和训练
    Train_model = FastModel.get_peft_model(
        Train_model,
        finetune_vision_layers=False,  # 纯文本任务，关闭视觉层的微调，以节省资源
        finetune_language_layers=True,  # 微调模型中的语言相关层，语言层是文本任务的核心部分，要开
        finetune_attention_modules=True,  # 微调模型中的注意力模块
        finetune_mlp_modules=True,  # 微调模型中的MLP模块
        r=16,  # LoRA中的秩，秩越高，模型表达能力越强，训练越慢，也越容易过拟合
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                        "gate_proj", "up_proj", "down_proj", ],
        lora_alpha=16,  # LoRA中的缩放因子
        lora_dropout=0,  # LoRA中的dropout率
        bias="none",
        random_state=3407,  # 随机数种子，这个随便取
    )
    Train_tokenizer = get_chat_template(
        Train_tokenizer,
        chat_template="gemma-3",
    )
    return Train_model, Train_tokenizer


def apply_chat_template(samples):
    conversations = []
    for Instruction, Context, Question, Answer in zip(samples["Instruction"], samples["Context"], samples["Question"],
                                                      samples["Answer"]):

        # 构造最终对话格式
        # 判断samples中的各个字段是否为字符串类型
        if isinstance(Instruction, list) or isinstance(Context, list) or isinstance(Question, list) or isinstance(
                Answer, list):
            print(
                f"类型检查: Instruction类型={type(Instruction)}, Context类型={type(Context)}, Question类型={type(Question)}, Answer类型={type(Answer)}")
        conversation = (
                "<bos>\n"
                "<start_of_turn>user\n" + Instruction + '\n' + Context + Question + "\n<end_of_turn>\n"
                                                                                    "<start_of_turn>model\n" + Answer + "\n<end_of_turn>"
        )
        conversations.append(conversation)

    return {"text": conversations}


def tokenize_function(examples):
    return Train_tokenizer(examples["text"], padding=False)


print('Model prepared for training')


# 开始训练
def Train_llama3(Train_model, Train_tokenizer, train_data):
    if Train_model is None or Train_tokenizer is None or train_data is None:
        print("模型或数据集加载失败，无法进行训练")
        return

    print('Training model')
    # 标准化数据格式，确保所有训练数据符合模型所需的输入格式
    train_data = train_data.map(apply_chat_template, batched=True)
    print("处理后用于训练的一个样本实例:", train_data[0]["text"])

    # Manually preprocess and tokenize
    train_data = train_data.map(
        tokenize_function,
        batched=True,
        remove_columns=["text"],  # Remove original text column
        desc="Tokenizing dataset"
    )

    trainer = SFTTrainer(
        model=Train_model,
        tokenizer=Train_tokenizer,
        train_dataset=train_data,
        eval_dataset=None,  # 不进行评估，可以替换为具体数据集以启用评估
        args=SFTConfig(
            dataset_text_field="text",
            dataset_kwargs={"skip_prepare_dataset": True},
            per_device_train_batch_size=4,
            gradient_accumulation_steps=4,  # 梯度累积步数
            warmup_steps=10,
            max_steps=200,
            learning_rate=2e-4,  # 学习率
            logging_steps=1,
            # output_dir = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Saved_Models/' + LLMs_Models_Choise + '_FinedTune_result_on_' + Reasoning_Mode + '_multiNMR_'+ Dataset_Category+  '_' + str(Train_Number),
            optim="adamw_8bit",  # 优化器，是 AdamW 优化器的 8 位版本，节省内存且适合大模型。
            weight_decay=0.01,
            lr_scheduler_type="linear",
            seed=3407,
            report_to="none",  # 日志输出目标，这里表示不使用外部工具（如 WandB）记录日志
        ),
    )

    # trainer = train_on_responses_only(
    #     trainer,
    #     instruction_part = "<start_of_turn>user\n",
    #     response_part = "<start_of_turn>model\n",
    # )
    print('开始训练')
    trainer.train()
    print('训练完成')


# 保存模型
def Saved_Model(Train_model, Train_tokenizer):
    if Train_model is None or Train_tokenizer is None:
        print("模型未成功加载，无法保存")
        return

    print('Saving train model')
    save_path_lora = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Saved_Models/' + LLMs_Models_Choise + '_FinedTune_result_on_' + Reasoning_Mode + '_multiNMR_' + Dataset_Category + '_lora_model' + '_' + str(
        Train_Number)
    # save_path_merged = '/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Saved_Models/' + LLMs_Models_Choise + '_FinedTune_result_on_' + Reasoning_Mode + '_multiNMR_' + Dataset_Category + '_' + str(Train_Number)

    Train_model.save_pretrained(save_path_lora)
    # Train_model.save_pretrained_merged(save_path_merged, Train_tokenizer, save_method = "merged_16bit")
    print(f'Trained Model saved to {save_path_lora} ')


# 加载预训练好的模型进行测试
def Load_Test_Model():
    # 2. Load Llama3 model 加载 Llama-3-8B
    print('Loading Test model')
    Test_model, Test_tokenizer = FastModel.from_pretrained(
        model_name='/home/yeliangxiu/Projects/Automated_Construct_MultiNMR/Saved_Models/' + LLMs_Models_Choise + '_FinedTune_result_on_' + Reasoning_Mode + '_multiNMR_' + Dataset_Category + '_lora_model' + '_' + str(
            Train_Number),
        # +  '_' + str(Train_Number) # 指定 Unsloth 库中的确切模型。“Llama3”可能是型号名称，“8b”表示 80 亿个参数，“bnb”可能是指特定的架构，“4bit”表示使用内存效率高的格式。
        max_seq_length=max_seq_length,  # 设置最大序列长度（前面定义）以限制模型可以处理的输入长度。
        load_in_4bit=True,  # 是否启用 4 位量化，使用 4 位量化加载模型，可以显著减少内存占用，但可能会略微牺牲精度
        load_in_8bit=False,  # 8 位量化相比 4 位更精确，但内存占用要翻番，如果需要更高精度且内存充足，可以设置为 True
        full_finetuning=False,  # 全参数微调
    )
    FastModel.for_inference(Test_model)
    print('Test Model loaded')
    return Test_model, Test_tokenizer


from unsloth.chat_templates import get_chat_template

Max_new_tokens = 1000 if OOD_Flag == True else 500
def Test_Generate_Text(Test_model, Test_tokenizer, prompt):
    tokenizer = get_chat_template(
        Test_tokenizer,
        chat_template="gemma-3",
    )
    messages = [{
        "role": "user",
        "content": [{
            "type": "text",
            "text": prompt,
        }]
    }]
    text = tokenizer.apply_chat_template(
        messages,
        add_generation_prompt=True,  # Must add for generation
    )
    outputs = Test_model.generate(
        **tokenizer([text], return_tensors="pt").to("cuda"),
        max_new_tokens=Max_new_tokens,  # Increase for longer outputs!
        # Recommended Gemma-3 settings!
        temperature=0.5, top_p=0.95, top_k=64,
    )
    origin_output_text = tokenizer.batch_decode(outputs)
    return origin_output_text[0]


import ast


def Test_Model(Test_model, Test_tokenizer, Train_Dev_Test_Flag):
    with open(Read_Test_Data_file, 'r', encoding='utf-8') as f0, open(Write_file_path02, 'a', encoding='utf-8') as f1:
        Total_Question_label_List = []
        Total_LLMs_Generted_Label_List = []
        Total_count01 = 1
        Test_Extension_Example_Dict = {}
        Test_Extension_Example_Dict01 = {6: 0, 8: 0, 10: 0, 12: 0, 16: 0} if OOD_Flag == True else {2: 99, 1: 95, 4: 96, 3: 96, 5: 95}

        for line in f0:
            Write_Dict = {}  # 该字典用于存储需要写入的样本字典
            LLMs_Generted_Label_List = []
            LLMs_Generted_Answer_Set_Explanation_List = []
            js = json.loads(line.strip())
            # 将数据集划分成训练/验证/测试
            Sample_number = js['Sample_number']
            Origin_Facts = js['Origin_Facts']
            Facts_number = js['Facts_number']  # 计算缺省理论中事实的个数
            Defalut_Rules = js['Defalut_Rules']
            NL_Origin_Facts = js['NL_Origin_Facts']
            NL_Defalut_Rules = js['NL_Defalut_Rules']
            Origin_ASP_extension_number = js['Origin_ASP_extension_number']
            Origin_Question_Text_Lists = js['Origin_Question_Text_Lists']
            NL_Origin_Question_Text = js['NL_Origin_Question_Text']
            Origin_Question_Label_Lists = js['Origin_Question_Label_Lists']
            Origin_Question_proof_List = js['Origin_Question_proof_List']
            NL_Origin_Question_proof_Text = js['NL_Origin_Question_proof_Text']
            # 控制每个扩展数量的样本测试
            if Origin_ASP_extension_number not in Test_Extension_Example_Dict.keys():
                Test_Extension_Example_Dict[Origin_ASP_extension_number] = 1
                if Test_Extension_Example_Dict[Origin_ASP_extension_number] <= Test_Extension_Example_Dict01[Origin_ASP_extension_number]:
                    continue
            else:
                if Test_Extension_Example_Dict[Origin_ASP_extension_number] >= 100:
                    continue
                else:
                    Test_Extension_Example_Dict[Origin_ASP_extension_number] += 1
                    if Test_Extension_Example_Dict[Origin_ASP_extension_number] <= Test_Extension_Example_Dict01[
                        Origin_ASP_extension_number]:
                        continue

            NL_Noise_Facts_Strings, NL_Noise_Default_Rule_Strings = '', ''
            if Noise_Flag == True:
                NL_Noise_Facts_Lists = js['NL_Noise_Facts_Lists']
                NL_Noise_Default_Rule_Lists = js['NL_Noise_Default_Rule_Lists']

                for noise_fact_key in range(Noise_Length):
                    noise_fact = NL_Noise_Facts_Lists[noise_fact_key]
                    NL_Noise_Facts_Strings = NL_Noise_Facts_Strings + noise_fact

                for noise_rule_key in range(Noise_Length):
                    noise_rule = NL_Noise_Default_Rule_Lists[noise_rule_key]
                    NL_Noise_Default_Rule_Strings = NL_Noise_Default_Rule_Strings + noise_rule

            Answer_Set_List = []
            if Total_count01 <= -1:
                print('Test_Extension_Example_Dict={}'.format(Test_Extension_Example_Dict))
                Total_count01 = Total_count01 + 1
                continue

            Context_Text_String = NL_Origin_Facts + NL_Noise_Facts_Strings
            Context_Text_String = Context_Text_String + NL_Defalut_Rules + NL_Noise_Default_Rule_Strings
            Question_Text_String = ''
            LLMs_Generted_Label_List = []
            Generated_Answer_Set_List,Generated_Answer_Set_List_String = '',''
            Soft_Generated_Answer_Set_List,Soft_Generated_Answer_Set_List_String = '',''
            for question_key in range(len(NL_Origin_Question_Text)):
                question_text = NL_Origin_Question_Text[question_key]
                Question_Text_String = question_text
                question_label = Origin_Question_Label_Lists[question_key]
                Total_Question_label_List.extend(Label_Dict[question_label[0]])
                # 调用大模型预测
                Test_prompt = f"""### Instruction: {Test_Instruction} ### The context are: {Context_Text_String} ### The question is: {Question_Text_String}\n ### Response: """
                while_count01 = 0
                while True:
                    if while_count01 > 10:
                        extracted_answer_output = result_output
                        break
                    result_output = Test_Generate_Text(Test_model, Test_tokenizer, Test_prompt)
                    while_count01 = while_count01 + 1
                    result_output = result_output.replace('\n', ' ')
                    print('result_output={}.'.format(result_output))
                    if 'Response' in result_output:
                        result_output = result_output.split('Response')[-1]
                    else:
                        continue
                    extracted_answer_output = re.findall(Extract_Answer_Pattern, result_output)
                    extracted_extension_output = re.findall(Exact_Extensions_Pattern, result_output)
                    if len(extracted_answer_output) == 0:  # len(extracted_extension_output)==0:
                        print("抽取标签答案不成功！while_count01={}".format(while_count01))
                        continue
                    else:
                        extracted_answer_output = extracted_answer_output[0]
                        print("抽取标签答案成功！extracted_answer_output={},while_count01={}".format(extracted_answer_output,while_count01))
                    if len(extracted_extension_output)>=1 and len(Generated_Answer_Set_List_String)==0:
                        Generated_Answer_Set_List = extracted_extension_output[0].replace('.', '').replace('doesn\'t','does not').replace('won\'t','will not').replace('isn\'t','is not').replace('aren\'t','are not').replace('\'s', ' is')
                        Generated_Answer_Set_List = Generated_Answer_Set_List.replace('[ [', '[[').replace('] ]', ']]')
                        if len(Generated_Answer_Set_List)>10 and '[[' in Generated_Answer_Set_List and ']]' in Generated_Answer_Set_List:
                            Generated_Answer_Set_List = Generated_Answer_Set_List[:-2] if Generated_Answer_Set_List[-1] =='.' else Generated_Answer_Set_List
                            print('转换为列表之前的字符串Generated_Answer_Set_List={}'.format(Generated_Answer_Set_List))
                            try:
                                Generated_Answer_Set_List_String = ast.literal_eval(Generated_Answer_Set_List)
                                print("抽取回答集成功！Generated_Answer_Set_List={},while_count01={}".format(Generated_Answer_Set_List_String,while_count01))
                            except:
                                print('将字符列表转换成列表错误！硬匹配错误！')

                    if len(Generated_Answer_Set_List_String) == 0 and len(Soft_Generated_Answer_Set_List_String)==0:
                        # extracted_extension_output = extracted_extension_output[0]
                        if len(extracted_extension_output) == 0 and 'extensions are:' in result_output:
                            extracted_extension_output01 = result_output.split('extensions are:')[-1]
                            extracted_extension_output01 = extracted_extension_output01.replace('[   [', '[[')
                            # 截取最后一个']'之前的字符串
                            if '[' in extracted_extension_output01 and '[[' not in extracted_extension_output01:
                                extracted_extension_output01 = extracted_extension_output01.strip()
                                extracted_extension_output01 = '[' + extracted_extension_output01

                            try:
                                extracted_extension_output = extracted_extension_output01[:extracted_extension_output01.rfind(',') + 1]
                                extracted_extension_output = extracted_extension_output.strip().replace('doesn\'t',' does not').replace('won\'t','will not').replace('isn\'t','is not').replace('aren\'t','are not').replace('\'s', ' is')
                                extracted_extension_output = extracted_extension_output[:-1] if extracted_extension_output[-1] == ',' else extracted_extension_output
                                extracted_extension_output = extracted_extension_output + ']]'

                                extracted_extension_output = ast.literal_eval(extracted_extension_output)
                                if isinstance(extracted_extension_output, list):
                                    extracted_extension_list02 = copy.deepcopy(extracted_extension_output)
                                    # 对每个子列表进行去重
                                    for i in range(len(extracted_extension_list02)):
                                        extracted_extension_list02[i] = list(set(extracted_extension_list02[i]))
                                    # 对整个列表进行去重
                                    extracted_extension_list02 = [list(x) for x in set(tuple(sorted(x)) for x in extracted_extension_list02)]
                                    Soft_Generated_Answer_Set_List_String = extracted_extension_list02

                                    print("抽取回答集成功！Soft_Generated_Answer_Set_List_String={},while_count01={}".format(Soft_Generated_Answer_Set_List_String, while_count01))
                                else:
                                    print("抽取回答集失败！extracted_extension_output={},while_count01={}".format(extracted_extension_output, while_count01))
                            except:
                                print('抽取soft 回答集异常！')

                    if len(Generated_Answer_Set_List)!=0:
                        print('extracted_answer_output={}, Generated_Answer_Set_List={},result_output={}'.format(extracted_answer_output, Generated_Answer_Set_List_String, result_output))
                    else:
                        print('extracted_answer_output={}, Soft_Generated_Answer_Set_List={},result_output={}'.format(extracted_answer_output, Soft_Generated_Answer_Set_List_String, result_output))

                    if len(extracted_answer_output) != 0:
                        break

                # 对生成的结果进行分析
                predict_label = None
                if 'unknown' in extracted_answer_output or 'Unknown' in extracted_answer_output:
                    predict_label = 'M'
                elif 'true' in extracted_answer_output or 'True' in extracted_answer_output:
                    predict_label = 'T'
                elif 'false' in extracted_answer_output or 'False' in extracted_answer_output:
                    predict_label = 'F'
                else:
                    predict_label = 'M'
                LLMs_Generted_Label_List.append([predict_label])

                Total_LLMs_Generted_Label_List.extend(Label_Dict[predict_label])
            print('Total_count01={}, Total_LLMs_Generted_Label_List = {}, Origin_Question_Label_Lists: = {}'.format(str(Sample_number), LLMs_Generted_Label_List, Origin_Question_Label_Lists))

            Write_Dict['Sample_number'] = Sample_number  # 样本个数
            Write_Dict['Origin_ASP_extension_number'] = Origin_ASP_extension_number
            Write_Dict['NL_Origin_Question_Text'] = NL_Origin_Question_Text
            Write_Dict['Origin_Question_Label_Lists'] = Origin_Question_Label_Lists
            Write_Dict['LLMs_Generated_Question_Label_Lists'] = LLMs_Generted_Label_List

            Write_Dict['Origin_Question_proof_List'] = Origin_Question_proof_List
            Write_Dict['NL_Origin_Question_proof_Text'] = NL_Origin_Question_proof_Text
            Write_Dict['LLMs_Generated_Question_Explanation_Lists'] = ''
            Write_Dict['Answer_Set_List'] = Generated_Answer_Set_List_String if len(Generated_Answer_Set_List_String)!=0 else Soft_Generated_Answer_Set_List_String  # 在微调模式下，每个问题都生成了回答集，所以需要用字典来存储。

            Write_Dict = json.dumps(Write_Dict, ensure_ascii=False)
            f1.write(Write_Dict + '\n')
            Total_count01 = Total_count01 + 1

        accuracy = accuracy_score(Total_Question_label_List, Total_LLMs_Generted_Label_List)  # 计算准确率
        F1 = f1_score(Total_Question_label_List, Total_LLMs_Generted_Label_List, average='macro')
        print('accuracy={},F1={}'.format(accuracy, F1))


if __name__ == '__main__':
    # Train_data = Train_Test_Dataset()
    # Train_model, Train_tokenizer = Load_FineTune_Model()
    # Train_llama3(Train_model, Train_tokenizer, Train_data)
    # Saved_Model(Train_model, Train_tokenizer)
    # del Train_model
    # del Train_tokenizer
    Test_model, Test_tokenizer = Load_Test_Model()
    FastModel.for_inference(Test_model)
    Test_Model(Test_model, Test_tokenizer, Train_Dev_Test_Flag='test')

